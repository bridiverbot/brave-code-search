from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'lite/enum_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_enum_def = missing
    try:
        t_1 = environment.filters['lite_closure_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'lite_closure_type' found.")
    try:
        t_2 = environment.tests['none']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No test named 'none' found.")
    pass
    def macro(l_1_enum_spec_parent, l_1_enum_parent, l_1_enum):
        t_3 = []
        l_1_generate_closure_exports = resolve('generate_closure_exports')
        l_1_enum_name = missing
        if l_1_enum_spec_parent is missing:
            l_1_enum_spec_parent = undefined("parameter 'enum_spec_parent' was not provided", name='enum_spec_parent')
        if l_1_enum_parent is missing:
            l_1_enum_parent = undefined("parameter 'enum_parent' was not provided", name='enum_parent')
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_enum_name = t_1(l_1_enum)
        if (undefined(name='generate_closure_exports') if l_1_generate_closure_exports is missing else l_1_generate_closure_exports):
            pass
            t_3.extend((
                "goog.provide('",
                str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
                "');\ngoog.provide('",
                str(l_1_enum_spec_parent),
                '.',
                str(environment.getattr(l_1_enum, 'name')),
                "Spec');",
            ))
        t_3.extend((
            '\n/**\n * @const { {$: !mojo.internal.MojomType} }\n * @export\n */\n',
            str(l_1_enum_spec_parent),
            '.',
            str(environment.getattr(l_1_enum, 'name')),
            'Spec = { $: mojo.internal.Enum() };\n\n/**\n * @enum {number}\n * @export\n */\n',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' = {\n  ',
        ))
        for l_2_field in environment.getattr(l_1_enum, 'fields'):
            _loop_vars = {}
            pass
            t_3.extend((
                '\n  ',
                str(environment.getattr(l_2_field, 'name')),
                ': ',
                str(environment.getattr(l_2_field, 'numeric_value')),
                ',',
            ))
        l_2_field = missing
        if (not t_2(environment.getattr(l_1_enum, 'min_value'))):
            pass
            t_3.extend((
                '\n  MIN_VALUE: ',
                str(environment.getattr(l_1_enum, 'min_value')),
                ',',
            ))
        if (not t_2(environment.getattr(l_1_enum, 'max_value'))):
            pass
            t_3.extend((
                '\n  MAX_VALUE: ',
                str(environment.getattr(l_1_enum, 'max_value')),
                ',',
            ))
        t_3.append(
            '\n};',
        )
        return concat(t_3)
    context.exported_vars.add('enum_def')
    context.vars['enum_def'] = l_0_enum_def = Macro(environment, macro, 'enum_def', ('enum_spec_parent', 'enum_parent', 'enum'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=24&5=35&7=36&8=40&9=42&15=49&21=53&23=56&24=61&26=67&27=71&29=74&30=78'