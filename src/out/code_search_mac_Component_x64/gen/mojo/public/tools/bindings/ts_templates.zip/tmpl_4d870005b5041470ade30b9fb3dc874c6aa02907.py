from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'converter_interface_declarations.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_converter_imports = resolve('converter_imports')
    l_0_typemapped_structs = resolve('typemapped_structs')
    try:
        t_1 = environment.filters['is_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_value_kind_packed_field' found.")
    try:
        t_2 = environment.filters['is_primary_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'is_primary_nullable_value_kind_packed_field' found.")
    try:
        t_3 = environment.filters['sort']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'sort' found.")
    try:
        t_4 = environment.filters['ts_type_maybe_nullable']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'ts_type_maybe_nullable' found.")
    pass
    yield "// Copyright 2024 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.\nimport {mojo} from '//resources/mojo/mojo/public/js/bindings.js';\n\n"
    l_1_loop = missing
    for (l_1_path, l_1_types), l_1_loop in LoopContext(t_3(environment, context.call(environment.getattr((undefined(name='converter_imports') if l_0_converter_imports is missing else l_0_converter_imports), 'items'))), undefined):
        _loop_vars = {}
        pass
        yield 'import type {'
        l_2_loop = missing
        for l_2_type, l_2_loop in LoopContext(t_3(environment, l_1_types), undefined):
            _loop_vars = {}
            pass
            yield '\n  '
            yield str(l_2_type)
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_type = missing
        yield "\n} from '"
        yield str(l_1_path)
        yield "';\n"
    l_1_loop = l_1_path = l_1_types = missing
    l_1_loop = missing
    for l_1_struct, l_1_loop in LoopContext((undefined(name='typemapped_structs') if l_0_typemapped_structs is missing else l_0_typemapped_structs), undefined):
        _loop_vars = {}
        pass
        yield '\n\nexport class '
        yield str(environment.getattr(l_1_struct, 'name'))
        yield 'DataView {\n  private readonly decoder_: mojo.internal.Decoder;\n  private readonly version_: number;\n  private readonly fieldSpecs_: Array<mojo.internal.StructFieldSpec<any, any>>;\n\n  constructor(decoder: mojo.internal.Decoder,\n              version: number,\n              fieldSpecs: Array<mojo.internal.StructFieldSpec<any, any>>) {\n    this.decoder_ = decoder;\n    this.version_ = version;\n    this.fieldSpecs_ = fieldSpecs;\n  }'
        l_2_loop = missing
        for l_2_packed_field, l_2_loop in LoopContext(environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields_in_ordinal_order'), undefined):
            l_2_f = resolve('f')
            _loop_vars = {}
            pass
            if t_1(l_2_packed_field):
                pass
                yield '\n'
                if t_2(l_2_packed_field):
                    pass
                    yield '\n  get '
                    yield str(environment.getattr(environment.getattr(l_2_packed_field, 'original_field'), 'name'))
                    yield '(): '
                    yield str(t_4(environment.getattr(environment.getattr(l_2_packed_field, 'original_field'), 'kind')))
                    yield ' {\n    const flagField = this.fieldSpecs_['
                    yield str(environment.getattr(l_2_loop, 'index0'))
                    yield '];\n    return mojo.internal.decodeStructNullableValueField(this.decoder_, flagField!, this.fieldSpecs_, this.version_);\n  }'
            else:
                pass
                l_2_f = environment.getattr(l_2_packed_field, 'field')
                _loop_vars['f'] = l_2_f
                yield '\n  get '
                yield str(environment.getattr((undefined(name='f') if l_2_f is missing else l_2_f), 'name'))
                yield '(): '
                yield str(t_4(environment.getattr((undefined(name='f') if l_2_f is missing else l_2_f), 'kind')))
                yield ' {\n    const field = this.fieldSpecs_['
                yield str(environment.getattr(l_2_loop, 'index0'))
                yield '];\n    return mojo.internal.decodeStructField(this.decoder_, field!, this.version_);\n  }'
        l_2_loop = l_2_packed_field = l_2_f = missing
        yield '\n}\n\nexport interface '
        yield str(environment.getattr(l_1_struct, 'name'))
        yield 'TypeMapper<T> {\n  // Encoding:'
        for l_2_packed_field in environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields_in_ordinal_order'):
            l_2_f = resolve('f')
            _loop_vars = {}
            pass
            if t_1(l_2_packed_field):
                pass
                if t_2(l_2_packed_field):
                    pass
                    yield '\n  '
                    yield str(environment.getattr(environment.getattr(l_2_packed_field, 'original_field'), 'name'))
                    yield '(mappedTyped: T): '
                    yield str(t_4(environment.getattr(environment.getattr(l_2_packed_field, 'original_field'), 'kind')))
                    yield ';'
            else:
                pass
                l_2_f = environment.getattr(l_2_packed_field, 'field')
                _loop_vars['f'] = l_2_f
                yield '\n  '
                yield str(environment.getattr((undefined(name='f') if l_2_f is missing else l_2_f), 'name'))
                yield '(mappedTyped: T): '
                yield str(t_4(environment.getattr((undefined(name='f') if l_2_f is missing else l_2_f), 'kind')))
                yield ';'
        l_2_packed_field = l_2_f = missing
        yield '\n\n  // Decoding:\n  convert(dataView: '
        yield str(environment.getattr(l_1_struct, 'name'))
        yield 'DataView): T;\n}\n\n'
    l_1_loop = l_1_struct = missing

blocks = {}
debug_info = '6=39&8=44&9=48&10=49&12=54&15=58&17=62&29=65&30=69&32=72&33=75&34=79&39=83&40=86&41=90&48=94&50=96&51=100&52=102&53=105&56=111&57=114&62=120'