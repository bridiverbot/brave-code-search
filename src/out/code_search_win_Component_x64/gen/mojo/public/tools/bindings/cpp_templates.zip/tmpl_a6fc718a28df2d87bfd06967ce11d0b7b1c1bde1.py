from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'wrapper_union_class_template_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    try:
        t_1 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    pass
    yield 'template <typename UnionPtrType>\n'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'Ptr '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::Clone() const {\n  switch (tag_) {'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n    case Tag::k'
        yield str(t_1(environment.getattr(l_1_field, 'name')))
        yield ':\n      return New'
        yield str(t_1(environment.getattr(l_1_field, 'name')))
        yield '(\n          mojo::Clone(data_.'
        yield str(environment.getattr(l_1_field, 'name'))
        yield '));'
    l_1_field = missing
    yield '\n  }\n  return nullptr;\n}\n\ntemplate <typename T,\n          typename std::enable_if<std::is_same<\n              T, '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '>::value>::type*>\nbool '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::Equals(const T& other) const {\n  if (tag_ != other.which())\n    return false;\n\n  switch (tag_) {'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n    case Tag::k'
        yield str(t_1(environment.getattr(l_1_field, 'name')))
        yield ':\n      return mojo::Equals(data_.'
        yield str(environment.getattr(l_1_field, 'name'))
        yield ', other.data_.'
        yield str(environment.getattr(l_1_field, 'name'))
        yield ');'
    l_1_field = missing
    yield '\n  }\n\n  return false;\n}'

blocks = {}
debug_info = '2=19&4=23&5=27&6=29&7=31&15=35&16=37&21=39&22=43&23=45'