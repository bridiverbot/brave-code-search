from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'wrapper_union_class_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    try:
        t_1 = environment.filters['cpp_wrapper_param_type_new']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_param_type_new' found.")
    try:
        t_2 = environment.filters['cpp_wrapper_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_type' found.")
    try:
        t_3 = environment.filters['is_any_handle_or_interface_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_or_interface_kind' found.")
    try:
        t_4 = environment.filters['is_hashable']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_hashable' found.")
    try:
        t_5 = environment.filters['is_object_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_object_kind' found.")
    try:
        t_6 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    pass
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield 'Ptr\n'
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '::New'
        yield str(t_6(environment.getattr(l_1_field, 'name')))
        yield '(\n    '
        yield str(t_1(environment.getattr(l_1_field, 'kind')))
        yield ' value) {\n  return '
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield 'Ptr(\n      std::in_place,\n      std::in_place_index<static_cast<size_t>(Tag::k'
        yield str(t_6(environment.getattr(l_1_field, 'name')))
        yield ')>,\n      std::move(value));\n}\n'
    l_1_field = missing
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '::'
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '(\n    std::in_place_index_t<static_cast<size_t>(Tag::k'
        yield str(t_6(environment.getattr(l_1_field, 'name')))
        yield ')>,\n    '
        yield str(t_1(environment.getattr(l_1_field, 'kind')))
        yield ' value)\n    : tag_(Tag::k'
        yield str(t_6(environment.getattr(l_1_field, 'name')))
        yield '),\n      data_(std::in_place_index<static_cast<size_t>(Tag::k'
        yield str(t_6(environment.getattr(l_1_field, 'name')))
        yield ')>,\n            std::move(value)) {}\n'
    l_1_field = missing
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::~'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '() {\n  DestroyActive();\n}\n'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\nvoid '
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '::set_'
        yield str(environment.getattr(l_1_field, 'name'))
        yield '('
        yield str(t_1(environment.getattr(l_1_field, 'kind')))
        yield ' '
        yield str(environment.getattr(l_1_field, 'name'))
        yield ') {'
        if (t_5(environment.getattr(l_1_field, 'kind')) or t_3(environment.getattr(l_1_field, 'kind'))):
            pass
            yield '\n  if (tag_ == Tag::k'
            yield str(t_6(environment.getattr(l_1_field, 'name')))
            yield ') {\n    data_.'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ' = std::move('
            yield str(environment.getattr(l_1_field, 'name'))
            yield ');\n  } else {\n    DestroyActive();\n    tag_ = Tag::k'
            yield str(t_6(environment.getattr(l_1_field, 'name')))
            yield ';\n    new (&data_.'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ') '
            yield str(t_2(environment.getattr(l_1_field, 'kind')))
            yield '(\n        std::move('
            yield str(environment.getattr(l_1_field, 'name'))
            yield '));\n  }'
        else:
            pass
            yield '\n  if (tag_ != Tag::k'
            yield str(t_6(environment.getattr(l_1_field, 'name')))
            yield ') {\n    DestroyActive();\n    tag_ = Tag::k'
            yield str(t_6(environment.getattr(l_1_field, 'name')))
            yield ';\n  }\n  data_.'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ' = '
            yield str(environment.getattr(l_1_field, 'name'))
            yield ';'
        yield '\n}\n'
    l_1_field = missing
    yield '\n'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '::Union_::Union_(\n    std::in_place_index_t<static_cast<size_t>(Tag::k'
        yield str(t_6(environment.getattr(l_1_field, 'name')))
        yield ')>,\n    '
        yield str(t_1(environment.getattr(l_1_field, 'kind')))
        yield ' value)\n    : '
        yield str(environment.getattr(l_1_field, 'name'))
        yield '(std::move(value)) {}\n'
    l_1_field = missing
    yield '\nvoid '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::DestroyActive() {\n  switch (tag_) {\n'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n    case Tag::k'
        yield str(t_6(environment.getattr(l_1_field, 'name')))
        yield ':\n      std::destroy_at(&data_.'
        yield str(environment.getattr(l_1_field, 'name'))
        yield ');\n      break;'
    l_1_field = missing
    yield '\n  }\n}'
    if t_4((undefined(name='union') if l_0_union is missing else l_0_union)):
        pass
        yield '\nsize_t '
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '::Hash(size_t seed) const {\n  seed = mojo::internal::HashCombine(seed, static_cast<uint32_t>(tag_));\n  switch (tag_) {\n'
        for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
            l_1_for_blink = resolve('for_blink')
            _loop_vars = {}
            pass
            yield '\n    case Tag::k'
            yield str(t_6(environment.getattr(l_1_field, 'name')))
            yield ':'
            if (undefined(name='for_blink') if l_1_for_blink is missing else l_1_for_blink):
                pass
                yield '\n      return mojo::internal::WTFHash(seed, data_.'
                yield str(environment.getattr(l_1_field, 'name'))
                yield ');'
            else:
                pass
                yield '\n      return mojo::internal::Hash(seed, data_.'
                yield str(environment.getattr(l_1_field, 'name'))
                yield ');'
        l_1_field = l_1_for_blink = missing
        yield '\n    default:\n      NOTREACHED();\n  }\n}'
    yield '\n\nbool '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::Validate(\n    const void* data,\n    mojo::internal::ValidationContext* validation_context) {\n  return Data_::Validate(data, validation_context, false);\n}'

blocks = {}
debug_info = '1=48&2=52&3=54&4=58&5=60&7=62&12=65&13=69&14=73&15=75&16=77&17=79&21=82&24=86&25=90&26=98&28=101&29=103&32=107&33=109&34=113&37=118&39=120&41=122&45=129&46=133&47=135&48=137&49=139&51=143&53=145&54=149&55=151&61=155&62=158&65=160&66=165&67=167&68=170&70=175&79=180'