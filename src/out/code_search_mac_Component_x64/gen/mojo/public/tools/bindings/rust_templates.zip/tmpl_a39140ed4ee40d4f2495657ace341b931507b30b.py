from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_declare_struct = l_0_field_names = l_0_field_types = l_0_typed_fields = l_0_args_struct = l_0_response_struct = l_0_declare_interface = missing
    try:
        t_1 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_2 = environment.filters['join']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'join' found.")
    try:
        t_3 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_4 = environment.filters['map']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'map' found.")
    try:
        t_5 = environment.filters['to_rust_type']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'to_rust_type' found.")
    try:
        t_6 = environment.tests['none']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No test named 'none' found.")
    pass
    included_template = environment.get_template('struct.tmpl', 'interface.tmpl')._get_default_module(context)
    l_0_declare_struct = getattr(included_template, 'declare_struct', missing)
    if l_0_declare_struct is missing:
        l_0_declare_struct = undefined(f"the template {included_template.__name__!r} (imported on line 1 in 'interface.tmpl') does not export the requested name 'declare_struct'", name='declare_struct')
    context.vars['declare_struct'] = l_0_declare_struct
    context.exported_vars.discard('declare_struct')
    def macro(l_1_field_list):
        t_7 = []
        if l_1_field_list is missing:
            l_1_field_list = undefined("parameter 'field_list' was not provided", name='field_list')
        pass
        t_7.append(
            str(t_2(context.eval_ctx, t_4(context, l_1_field_list, attribute='name'), ', ')),
        )
        return concat(t_7)
    context.exported_vars.add('field_names')
    context.vars['field_names'] = l_0_field_names = Macro(environment, macro, 'field_names', ('field_list',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n\n'
    def macro(l_1_field_list):
        t_8 = []
        if l_1_field_list is missing:
            l_1_field_list = undefined("parameter 'field_list' was not provided", name='field_list')
        pass
        t_8.append(
            str(t_2(context.eval_ctx, t_4(context, t_4(context, l_1_field_list, attribute='kind'), 'to_rust_type'), ', ')),
        )
        return concat(t_8)
    context.exported_vars.add('field_types')
    context.vars['field_types'] = l_0_field_types = Macro(environment, macro, 'field_types', ('field_list',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n'
    def macro(l_1_field_list):
        t_9 = []
        if l_1_field_list is missing:
            l_1_field_list = undefined("parameter 'field_list' was not provided", name='field_list')
        pass
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(l_1_field_list, undefined):
            _loop_vars = {}
            pass
            t_9.extend((
                str(environment.getattr(l_2_field, 'name')),
                ': ',
                str(t_5(environment.getattr(l_2_field, 'kind'))),
                str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 14 in 'interface.tmpl' evaluated to false and no else section was defined."))),
            ))
        l_2_loop = l_2_field = missing
        return concat(t_9)
    context.exported_vars.add('typed_fields')
    context.vars['typed_fields'] = l_0_typed_fields = Macro(environment, macro, 'typed_fields', ('field_list',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n'
    def macro(l_1_method):
        t_10 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        t_10.append(
            str(environment.getattr(environment.getattr(l_1_method, 'param_struct'), 'name')),
        )
        return concat(t_10)
    context.exported_vars.add('args_struct')
    context.vars['args_struct'] = l_0_args_struct = Macro(environment, macro, 'args_struct', ('method',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n'
    def macro(l_1_method):
        t_11 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        t_11.append(
            str(environment.getattr(environment.getattr(l_1_method, 'response_param_struct'), 'name')),
        )
        return concat(t_11)
    context.exported_vars.add('response_struct')
    context.vars['response_struct'] = l_0_response_struct = Macro(environment, macro, 'response_struct', ('method',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n'
    def macro(l_1_interface):
        t_12 = []
        l_1_callback_ty_name = missing
        if l_1_interface is missing:
            l_1_interface = undefined("parameter 'interface' was not provided", name='interface')
        pass
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            _loop_vars = {}
            pass
            t_12.extend((
                str(context.call((undefined(name='declare_struct') if l_0_declare_struct is missing else l_0_declare_struct), context.call((undefined(name='args_struct') if l_0_args_struct is missing else l_0_args_struct), l_2_method, _loop_vars=_loop_vars), environment.getattr(l_2_method, 'param_struct'), True, _loop_vars=_loop_vars)),
                '\n\nimpl ',
                str(context.call((undefined(name='args_struct') if l_0_args_struct is missing else l_0_args_struct), l_2_method, _loop_vars=_loop_vars)),
                ' {\n  fn serialize_from_parts(registrar: &impl Registrar, ',
                str(context.call((undefined(name='typed_fields') if l_0_typed_fields is missing else l_0_typed_fields), environment.getattr(environment.getattr(l_2_method, 'param_struct'), 'fields'), _loop_vars=_loop_vars)),
                ')\n    -> bindings::message::MojomMessage\n  {\n    let (payload, handles, interface_ids_offset) =\n       mojom_value_parser::serialize(Self { ',
                str(context.call((undefined(name='field_names') if l_0_field_names is missing else l_0_field_names), environment.getattr(environment.getattr(l_2_method, 'param_struct'), 'fields'), _loop_vars=_loop_vars)),
                ' }, registrar);',
            ))
            if (not t_6(environment.getattr(l_2_method, 'response_parameters'))):
                pass
                t_12.append(
                    '\n    let flags = bindings::message_header::MessageHeaderFlags::EXPECTS_RESPONSE;',
                )
            else:
                pass
                t_12.append(
                    '\n    let flags = bindings::message_header::MessageHeaderFlags::empty();',
                )
            t_12.extend((
                '\n    bindings::message::MojomMessage {\n      header: bindings::message_header::MessageHeader::new(\n        0, ',
                str(environment.getattr(l_2_method, 'ordinal')),
                ', flags, 0, interface_ids_offset),\n      payload,\n      handles,\n      raw_message_handle: None,\n    }\n  }\n}',
            ))
            if (not t_6(environment.getattr(l_2_method, 'response_parameters'))):
                pass
                t_12.extend((
                    '\n',
                    str(context.call((undefined(name='declare_struct') if l_0_declare_struct is missing else l_0_declare_struct), context.call((undefined(name='response_struct') if l_0_response_struct is missing else l_0_response_struct), l_2_method, _loop_vars=_loop_vars), environment.getattr(l_2_method, 'response_param_struct'), True, _loop_vars=_loop_vars)),
                    '\n\nimpl ',
                    str(context.call((undefined(name='response_struct') if l_0_response_struct is missing else l_0_response_struct), l_2_method, _loop_vars=_loop_vars)),
                    ' {\n  fn serialize_from_parts(registrar: &impl Registrar, ',
                    str(context.call((undefined(name='typed_fields') if l_0_typed_fields is missing else l_0_typed_fields), environment.getattr(environment.getattr(l_2_method, 'response_param_struct'), 'fields'), _loop_vars=_loop_vars)),
                    ')\n    -> bindings::message::MojomMessage\n  {\n    let (payload, handles, interface_ids_offset) =\n      mojom_value_parser::serialize(Self { ',
                    str(context.call((undefined(name='field_names') if l_0_field_names is missing else l_0_field_names), environment.getattr(environment.getattr(l_2_method, 'response_param_struct'), 'fields'), _loop_vars=_loop_vars)),
                    ' }, registrar);\n    let flags = bindings::message_header::MessageHeaderFlags::IS_RESPONSE;\n    bindings::message::MojomMessage {\n      header: bindings::message_header::MessageHeader::new(\n        0, ',
                    str(environment.getattr(l_2_method, 'ordinal')),
                    ', flags, 0, interface_ids_offset\n      ),\n      payload,\n      handles,\n      raw_message_handle: None,\n    }\n  }\n}',
                ))
        l_2_method = missing
        t_12.extend((
            '\n\npub trait ',
            str(environment.getattr(l_1_interface, 'name')),
            ' : bindings::interface::internal::ImplementThisViaMacro {',
        ))
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            _loop_vars = {}
            pass
            t_12.extend((
                '\n  fn ',
                str(environment.getattr(l_2_method, 'name')),
                '(&mut self',
                str((', ' if environment.getattr(environment.getattr(l_2_method, 'param_struct'), 'fields') else cond_expr_undefined("the inline if-expression on line 80 in 'interface.tmpl' evaluated to false and no else section was defined."))),
                str(context.call((undefined(name='typed_fields') if l_0_typed_fields is missing else l_0_typed_fields), environment.getattr(environment.getattr(l_2_method, 'param_struct'), 'fields'), _loop_vars=_loop_vars)),
            ))
            if (not t_6(environment.getattr(l_2_method, 'response_parameters'))):
                pass
                t_12.extend((
                    ',\n    ',
                    str((' ' * (t_3(environment.getattr(l_2_method, 'name')) + 1))),
                    " response_callback: impl Send + 'static + FnOnce(",
                    str(context.call((undefined(name='field_types') if l_0_field_types is missing else l_0_field_types), environment.getattr(environment.getattr(l_2_method, 'response_param_struct'), 'fields'), _loop_vars=_loop_vars)),
                    ')',
                ))
            t_12.append(
                ') where Self: Sized;',
            )
        l_2_method = missing
        t_12.append(
            "\n\n  // Note to users: Do not override this function when implementing the trait\n  #[allow(unused_variables, unused_mut)] // If no messages send a response\n  fn handle_incoming_message(\n      &mut self,\n      mut message: bindings::message::MojomMessage,\n      sender: ResponseSender)\n    where Self: Sized\n  {\n    let request_id = message.header.request_id;\n    // We could also do this with std::mem::transmute due to the null-pointer optimization,\n    // but that's unsafe, and the compiler can figure it out anyway.\n    let mut handles = std::mem::take(&mut message.handles).into_iter().map(|h| Some(h)).collect::<Vec<_>>();\n    match message.header.name {",
        )
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            _loop_vars = {}
            pass
            t_12.extend((
                '\n      ',
                str(environment.getattr(l_2_method, 'ordinal')),
                " => {\n        // Check that this does/doesn't have the request flags set like the mojom file says it should.\n        if !message.header.flags.is_valid_request(",
                str(('true' if (not t_6(environment.getattr(l_2_method, 'response_parameters'))) else 'false')),
                ') {\n          let _ = message.report_bad_message("Message flags do not match the method signature");\n          return;\n        }\n        let ',
                str(('_' if (not environment.getattr(l_2_method, 'parameters')) else cond_expr_undefined("the inline if-expression on line 112 in 'interface.tmpl' evaluated to false and no else section was defined."))),
                'parsed: ',
                str(context.call((undefined(name='args_struct') if l_0_args_struct is missing else l_0_args_struct), l_2_method, _loop_vars=_loop_vars)),
                ' = match\n          mojom_value_parser::deserialize_exact(&message.payload, &mut handles, message.header.interface_ids_offset(), &sender)\n        {\n          Ok(parsed) => parsed,\n          Err(err) => {\n            let _ = message.report_bad_message(&err.to_string());\n            return;\n          }\n        };',
            ))
            if (not t_6(environment.getattr(l_2_method, 'response_parameters'))):
                pass
                t_12.extend((
                    '\n        let callback = move |',
                    str(context.call((undefined(name='typed_fields') if l_0_typed_fields is missing else l_0_typed_fields), environment.getattr(environment.getattr(l_2_method, 'response_param_struct'), 'fields'), _loop_vars=_loop_vars)),
                    '| {\n          let mut msg = ',
                    str(context.call((undefined(name='response_struct') if l_0_response_struct is missing else l_0_response_struct), l_2_method, _loop_vars=_loop_vars)),
                    '::serialize_from_parts(&sender, ',
                    str(context.call((undefined(name='field_names') if l_0_field_names is missing else l_0_field_names), environment.getattr(environment.getattr(l_2_method, 'response_param_struct'), 'fields'), _loop_vars=_loop_vars)),
                    ');\n          msg.header.request_id = request_id;\n          sender.send_message(msg);\n        };',
                ))
            t_12.extend((
                '\n        self.',
                str(environment.getattr(l_2_method, 'name')),
                '(',
            ))
            for l_3_field in environment.getattr(environment.getattr(l_2_method, 'param_struct'), 'fields'):
                _loop_vars = {}
                pass
                t_12.extend((
                    'parsed.',
                    str(environment.getattr(l_3_field, 'name')),
                    ',\n          ',
                ))
            l_3_field = missing
            if (not t_6(environment.getattr(l_2_method, 'response_parameters'))):
                pass
                t_12.append(
                    'callback',
                )
            t_12.append(
                ');\n      }',
            )
        l_2_method = missing
        t_12.append(
            '\n      _ => {\n        let _ = message.report_bad_message("Received a message with an unknown ordinal");\n      }\n    }\n  }\n}',
        )
        l_1_callback_ty_name = t_1('%sResponseCallback', environment.getattr(l_1_interface, 'name'))
        t_12.extend((
            '\n\npub enum ',
            str((undefined(name='callback_ty_name') if l_1_callback_ty_name is missing else l_1_callback_ty_name)),
            ' {',
        ))
        def t_13(fiter):
            for l_2_method in fiter:
                if (not t_6(environment.getattr(l_2_method, 'response_parameters'))):
                    yield l_2_method
        for l_2_method in t_13(environment.getattr(l_1_interface, 'methods')):
            _loop_vars = {}
            pass
            t_12.extend((
                '\n  ',
                str(environment.getattr(l_2_method, 'name')),
                "(Box<dyn Send + 'static + FnOnce(",
                str(context.call((undefined(name='field_types') if l_0_field_types is missing else l_0_field_types), environment.getattr(environment.getattr(l_2_method, 'response_param_struct'), 'fields'), _loop_vars=_loop_vars)),
                ')>),',
            ))
        l_2_method = missing
        t_12.extend((
            '\n}\n\nimpl bindings::interface::MojomInterface for dyn ',
            str(environment.getattr(l_1_interface, 'name')),
            ' {\n  type DynTy = dyn ',
            str(environment.getattr(l_1_interface, 'name')),
            ';\n\n  type ResponseCallbackTy = ',
            str((undefined(name='callback_ty_name') if l_1_callback_ty_name is missing else l_1_callback_ty_name)),
            ';\n\n  #[allow(unused_variables, unused_mut)] // If no messages take a response\n  fn handle_incoming_response(\n    mut message: bindings::message::MojomMessage,\n    sender: ResponseSender,\n    send_response: Self::ResponseCallbackTy)\n  {\n    // Responses are matched up by request ID alone, so check that this is\n    // actually a response before we treat it as one.\n    if !message.header.flags.is_valid_response() {\n      let _ = message.report_bad_message("Message flags do not mark this as a response");\n      return;\n    }\n    // We could also do this with std::mem::transmute due to the null-pointer optimization,\n    // but that\'s unsafe, and the compiler can figure it out anway.\n    let mut handles = std::mem::take(&mut message.handles).into_iter().map(|h| Some(h)).collect::<Vec<_>>();\n    match (message.header.name, send_response) {',
        ))
        def t_14(fiter):
            for l_2_method in fiter:
                if (not t_6(environment.getattr(l_2_method, 'response_parameters'))):
                    yield l_2_method
        l_2_loop = missing
        for l_2_method, l_2_loop in LoopContext(t_14(environment.getattr(l_1_interface, 'methods')), undefined):
            _loop_vars = {}
            pass
            t_12.extend((
                '\n      (',
                str(environment.getattr(l_2_method, 'ordinal')),
                ', ',
                str((undefined(name='callback_ty_name') if l_1_callback_ty_name is missing else l_1_callback_ty_name)),
                '::',
                str(environment.getattr(l_2_method, 'name')),
                '(callback)) => {\n        let parsed: ',
                str(context.call((undefined(name='response_struct') if l_0_response_struct is missing else l_0_response_struct), l_2_method, _loop_vars=_loop_vars)),
                ' = match\n          mojom_value_parser::deserialize_exact(&message.payload, &mut handles, message.header.interface_ids_offset(), &sender)\n        {\n          Ok(parsed) => parsed,\n          Err(err) => {\n            let _ = message.report_bad_message(&err.to_string());\n            return;\n          }\n        };\n        callback(',
            ))
            l_3_loop = missing
            for l_3_field, l_3_loop in LoopContext(environment.getattr(environment.getattr(l_2_method, 'response_param_struct'), 'fields'), undefined):
                _loop_vars = {}
                pass
                t_12.extend((
                    'parsed.',
                    str(environment.getattr(l_3_field, 'name')),
                    str((', ' if (not environment.getattr(l_3_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 185 in 'interface.tmpl' evaluated to false and no else section was defined."))),
                ))
            l_3_loop = l_3_field = missing
            t_12.append(
                ');\n      }',
            )
        l_2_loop = l_2_method = missing
        t_12.extend((
            '\n      _ => {\n        let _ = message.report_bad_message("Received a response with an unexpected ordinal");\n      }\n    }\n  }\n\n  fn handle_incoming_message(\n      &mut self,\n      _message: bindings::message::MojomMessage,\n      _sender: ResponseSender) {\n    unimplemented!("Call the appropriate trait method directly on the Remote object instead")\n  }\n}\n\nimpl bindings::interface::DynMojomInterface for dyn ',
            str(environment.getattr(l_1_interface, 'name')),
            ' {}\n\nimpl<Marker> ',
            str(environment.getattr(l_1_interface, 'name')),
            ' for bindings::remote::GenericRemote<dyn ',
            str(environment.getattr(l_1_interface, 'name')),
            ', Marker> {',
        ))
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            _loop_vars = {}
            pass
            t_12.extend((
                '\n  fn ',
                str(environment.getattr(l_2_method, 'name')),
                '(&mut self',
                str((', ' if environment.getattr(environment.getattr(l_2_method, 'param_struct'), 'fields') else cond_expr_undefined("the inline if-expression on line 208 in 'interface.tmpl' evaluated to false and no else section was defined."))),
                str(context.call((undefined(name='typed_fields') if l_0_typed_fields is missing else l_0_typed_fields), environment.getattr(environment.getattr(l_2_method, 'param_struct'), 'fields'), _loop_vars=_loop_vars)),
            ))
            if (not t_6(environment.getattr(l_2_method, 'response_parameters'))):
                pass
                t_12.extend((
                    ',\n    ',
                    str((' ' * (t_3(environment.getattr(l_2_method, 'name')) + 1))),
                    " response_callback: impl Send + 'static + FnOnce(",
                    str(context.call((undefined(name='field_types') if l_0_field_types is missing else l_0_field_types), environment.getattr(environment.getattr(l_2_method, 'response_param_struct'), 'fields'), _loop_vars=_loop_vars)),
                    ')',
                ))
            t_12.extend((
                ') {\n    let message = ',
                str(context.call((undefined(name='args_struct') if l_0_args_struct is missing else l_0_args_struct), l_2_method, _loop_vars=_loop_vars)),
                '::serialize_from_parts(self.as_registrar(), ',
                str(context.call((undefined(name='field_names') if l_0_field_names is missing else l_0_field_names), environment.getattr(environment.getattr(l_2_method, 'param_struct'), 'fields'), _loop_vars=_loop_vars)),
                ');',
            ))
            if (not t_6(environment.getattr(l_2_method, 'response_parameters'))):
                pass
                t_12.extend((
                    '\n    let callback = Some(',
                    str((undefined(name='callback_ty_name') if l_1_callback_ty_name is missing else l_1_callback_ty_name)),
                    '::',
                    str(environment.getattr(l_2_method, 'name')),
                    '(Box::new(response_callback)));',
                ))
            else:
                pass
                t_12.append(
                    '\n    let callback = None;',
                )
            t_12.append(
                '\n    self.send_message_internal(message, callback);\n  }\n',
            )
        l_2_method = missing
        t_12.append(
            '}',
        )
        return concat(t_12)
    context.exported_vars.add('declare_interface')
    context.vars['declare_interface'] = l_0_declare_interface = Macro(environment, macro, 'declare_interface', ('interface',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=48&3=54&4=60&8=66&9=72&12=78&13=84&14=88&18=98&19=104&22=110&23=116&26=122&29=128&31=132&33=134&34=136&38=138&39=141&46=153&54=156&55=160&57=162&58=164&62=166&66=168&77=174&79=177&80=182&81=185&82=187&85=191&86=193&105=203&106=208&108=210&112=212&121=217&122=221&123=223&128=230&129=233&130=238&132=242&143=254&145=257&146=260&147=269&151=277&152=279&154=281&172=284&173=294&174=300&184=304&185=309&204=319&206=321&207=326&208=331&209=334&210=336&213=340&214=342&219=347&220=352&221=356'