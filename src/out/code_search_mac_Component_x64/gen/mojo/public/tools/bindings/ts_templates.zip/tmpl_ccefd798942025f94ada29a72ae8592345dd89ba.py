from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'webui_browser_proxy_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_webui_factory = resolve('webui_factory')
    pass
    if environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'has_callback_router'):
        pass
        yield 'export type BrowserProxy = MojoBrowserProxy<'
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'handler_interface'))
        yield ', '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'router_router'))
        yield '>;\n\nexport const browserProxyFactory = new MojoBrowserProxyFactory<\n    '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'handler_interface'))
        yield ',\n    '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'router_remote'))
        yield ',\n    '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'handler_receiver'))
        yield ',\n    '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'router_receiver'))
        yield ',\n    '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'router_router'))
        yield ',\n    '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'handler_remote'))
        yield '>(\n    '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'handler_remote'))
        yield ',\n    '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'router_router'))
        yield ',\n    (remote: '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'router_remote'))
        yield ', receiver: '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'handler_receiver'))
        yield ') => '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'factory_interface'))
        yield '.getRemote().'
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'factory_method'))
        yield '(remote, receiver));'
    else:
        pass
        yield 'export type BrowserProxy = MojoHandlerProxy<'
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'handler_interface'))
        yield '>;\n\nexport const browserProxyFactory = new MojoHandlerProxyFactory<\n    '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'handler_interface'))
        yield ',\n    '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'handler_receiver'))
        yield ',\n    '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'handler_remote'))
        yield '>(\n    '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'handler_remote'))
        yield ',\n    (receiver: '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'handler_receiver'))
        yield ') => '
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'factory_interface'))
        yield '.getRemote().'
        yield str(environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'factory_method'))
        yield '(receiver));'

blocks = {}
debug_info = '1=12&2=15&5=19&6=21&7=23&8=25&9=27&10=29&11=31&12=33&13=35&15=46&18=48&19=50&20=52&21=54&22=56'