from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'struct.java.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_struct_def = missing
    pass
    included_template = environment.get_template('data_types_definition.tmpl', 'struct.java.tmpl')._get_default_module(context)
    l_0_struct_def = getattr(included_template, 'struct_def', missing)
    if l_0_struct_def is missing:
        l_0_struct_def = undefined(f"the template {included_template.__name__!r} (imported on line 1 in 'struct.java.tmpl') does not export the requested name 'struct_def'", name='struct_def')
    context.vars['struct_def'] = l_0_struct_def
    context.exported_vars.discard('struct_def')
    yield '\n'
    template = environment.get_template('header.java.tmpl', 'struct.java.tmpl')
    for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct_def': l_0_struct_def})):
        yield event
    yield '\n\n'
    yield str(context.call((undefined(name='struct_def') if l_0_struct_def is missing else l_0_struct_def), (undefined(name='struct') if l_0_struct is missing else l_0_struct)))

blocks = {}
debug_info = '1=13&2=20&4=24'