from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'lite/interface_definition_for_module.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface = resolve('interface')
    l_0_mojom_namespace = resolve('mojom_namespace')
    l_0_generateMethodAnnotation = l_0_enum_def = missing
    try:
        t_1 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_2 = environment.filters['sanitize_identifier']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'sanitize_identifier' found.")
    try:
        t_3 = environment.filters['type_in_js_module_with_nullability']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'type_in_js_module_with_nullability' found.")
    pass
    def macro(l_1_method):
        t_4 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        t_4.append(
            '\n  /**',
        )
        for l_2_param in environment.getattr(l_1_method, 'parameters'):
            _loop_vars = {}
            pass
            t_4.extend((
                '\n   * @param { ',
                str(t_3(environment.getattr(l_2_param, 'kind'))),
                ' } ',
                str(t_2(environment.getattr(l_2_param, 'name'))),
            ))
        l_2_param = missing
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            if (t_1(environment.getattr(l_1_method, 'response_parameters')) == 0):
                pass
                t_4.append(
                    '\n   * @return {!Promise}',
                )
            else:
                pass
                t_4.append(
                    '\n   * @return {!Promise<{',
                )
                for l_2_response_parameter in environment.getattr(l_1_method, 'response_parameters'):
                    _loop_vars = {}
                    pass
                    t_4.extend((
                        '\n        ',
                        str(environment.getattr(l_2_response_parameter, 'name')),
                        ': ',
                        str(t_3(environment.getattr(l_2_response_parameter, 'kind'))),
                        ',',
                    ))
                l_2_response_parameter = missing
                t_4.append(
                    '\n   *  }>}',
                )
        t_4.append(
            '\n   */\n',
        )
        return concat(t_4)
    context.exported_vars.add('generateMethodAnnotation')
    context.vars['generateMethodAnnotation'] = l_0_generateMethodAnnotation = Macro(environment, macro, 'generateMethodAnnotation', ('method',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n/**\n * @implements {mojo.internal.interfaceSupport.PendingReceiver}\n */\nexport class '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield "PendingReceiver {\n  /**\n   * @param {!MojoHandle|!mojo.internal.interfaceSupport.Endpoint} handle\n   */\n  constructor(handle) {\n    /** @public {!mojo.internal.interfaceSupport.Endpoint} */\n    this.handle = mojo.internal.interfaceSupport.getEndpointForReceiver(handle);\n  }\n\n  /** @param {string=} scope */\n  bindInBrowser(scope = 'context') {\n    mojo.internal.interfaceSupport.bind(\n        this.handle, '"
    yield str((undefined(name='mojom_namespace') if l_0_mojom_namespace is missing else l_0_mojom_namespace))
    yield '.'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield "', scope);\n  }\n}\n\n/** @interface */\nexport class "
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Interface {'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        _loop_vars = {}
        pass
        yield '\n  '
        yield str(context.call((undefined(name='generateMethodAnnotation') if l_0_generateMethodAnnotation is missing else l_0_generateMethodAnnotation), l_1_method, _loop_vars=_loop_vars))
        yield '\n  '
        yield str(environment.getattr(l_1_method, 'name'))
        yield '('
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            _loop_vars = {}
            pass
            yield str(t_2(environment.getattr(l_2_param, 'name')))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ', '
        l_2_loop = l_2_param = missing
        yield ') {}'
    l_1_loop = l_1_method = missing
    yield '\n}\n\n/**\n * @implements { '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Interface }\n */\nexport class '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote {\n  /** @param {MojoHandle|mojo.internal.interfaceSupport.Endpoint=} handle */\n  constructor(handle = undefined) {\n    /**\n     * @private {!mojo.internal.interfaceSupport.InterfaceRemoteBase<!'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>}\n     */\n    this.proxy =\n        new mojo.internal.interfaceSupport.InterfaceRemoteBase(\n          '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver,\n          handle);\n\n    /**\n     * @public {!mojo.internal.interfaceSupport.InterfaceRemoteBaseWrapper<!'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>}\n     */\n    this.$ = new mojo.internal.interfaceSupport.InterfaceRemoteBaseWrapper(this.proxy);\n\n    /** @public {!mojo.internal.interfaceSupport.ConnectionErrorEventRouter} */\n    this.onConnectionError = this.proxy.getConnectionErrorEventRouter();\n  }'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        l_1_interface_message_id = missing
        _loop_vars = {}
        pass
        l_1_interface_message_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        _loop_vars['interface_message_id'] = l_1_interface_message_id
        yield '\n\n  '
        yield str(context.call((undefined(name='generateMethodAnnotation') if l_0_generateMethodAnnotation is missing else l_0_generateMethodAnnotation), l_1_method, _loop_vars=_loop_vars))
        yield '\n  '
        yield str(environment.getattr(l_1_method, 'name'))
        yield '('
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            _loop_vars = {}
            pass
            yield '\n      '
            yield str(t_2(environment.getattr(l_2_param, 'name')))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_param = missing
        yield ') {'
        if ((environment.getattr(l_1_method, 'response_parameters') != None) or (environment.getattr(l_1_method, 'result_response') != None)):
            pass
            yield '\n    return this.proxy.sendMessage('
        else:
            pass
            yield '\n    this.proxy.sendMessage('
        yield '\n        '
        yield str(environment.getattr(l_1_method, 'ordinal'))
        yield ',\n        '
        yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
        yield '_ParamsSpec.$,'
        if ((environment.getattr(l_1_method, 'response_parameters') != None) or (environment.getattr(l_1_method, 'result_response') != None)):
            pass
            yield '\n        '
            yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
            yield '_ResponseParamsSpec.$,'
        else:
            pass
            yield '\n        null,'
        yield '\n        ['
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            _loop_vars = {}
            pass
            yield '\n          '
            yield str(t_2(environment.getattr(l_2_param, 'name')))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_param = missing
        yield '\n        ],\n        '
        yield str(('true' if (environment.getattr(l_1_method, 'result_response') != None) else 'false'))
        yield ');\n  }'
    l_1_loop = l_1_method = l_1_interface_message_id = missing
    yield '\n}\n\n/**\n * An object which receives request messages for the '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '\n * mojom interface. Must be constructed over an object which implements that\n * interface.\n */\nexport class '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Receiver {\n  /**\n   * @param {!'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Interface } impl\n   */\n  constructor(impl) {\n    /** @private {!mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal<!'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote>} */\n    this.helper_internal_ = new mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal(\n        '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote);\n\n    /**\n     * @public {!mojo.internal.interfaceSupport.InterfaceReceiverHelper<!'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote>}\n     */\n    this.$ = new mojo.internal.interfaceSupport.InterfaceReceiverHelper(this.helper_internal_);\n\n'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_interface_message_id = missing
        _loop_vars = {}
        pass
        l_1_interface_message_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        _loop_vars['interface_message_id'] = l_1_interface_message_id
        yield '\n    this.helper_internal_.registerHandler(\n        '
        yield str(environment.getattr(l_1_method, 'ordinal'))
        yield ',\n        '
        yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
        yield '_ParamsSpec.$,'
        if ((environment.getattr(l_1_method, 'response_parameters') != None) or (environment.getattr(l_1_method, 'result_response') != None)):
            pass
            yield '\n        '
            yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
            yield '_ResponseParamsSpec.$,'
        else:
            pass
            yield '\n        null,'
        yield '\n        impl.'
        yield str(environment.getattr(l_1_method, 'name'))
        yield '.bind(impl),\n        '
        yield str(('true' if (environment.getattr(l_1_method, 'result_response') != None) else 'false'))
        yield ');'
    l_1_method = l_1_interface_message_id = missing
    yield '\n    /** @public {!mojo.internal.interfaceSupport.ConnectionErrorEventRouter} */\n    this.onConnectionError = this.helper_internal_.getConnectionErrorEventRouter();\n  }\n}\n\nexport class '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield ' {\n  /**\n   * @return {!string}\n   */\n  static get $interfaceName() {\n    return "'
    yield str((undefined(name='mojom_namespace') if l_0_mojom_namespace is missing else l_0_mojom_namespace))
    yield '.'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '";\n  }\n\n  /**\n   * Returns a remote for this interface which sends messages to the browser.\n   * The browser must have an interface request binder registered for this\n   * interface and accessible to the calling document\'s frame.\n   *\n   * @return {!'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote}\n   */\n  static getRemote() {\n    let remote = new '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote;\n    remote.$.bindNewPipeAndPassReceiver().bindInBrowser();\n    return remote;\n  }\n}\n'
    included_template = environment.get_template('lite/enum_definition_for_module.tmpl', 'lite/interface_definition_for_module.tmpl').make_module(context.get_all(), True, {'enum_def': l_0_enum_def, 'generateMethodAnnotation': l_0_generateMethodAnnotation})
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined(f"the template {included_template.__name__!r} (imported on line 166 in 'lite/interface_definition_for_module.tmpl') does not export the requested name 'enum_def'", name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    for l_1_enum in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'enums'):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), l_1_enum, _loop_vars=_loop_vars))
    l_1_enum = missing
    yield '\n\n/**\n * An object which receives request messages for the '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '\n * mojom interface and dispatches them as callbacks. One callback receiver exists\n * on this object for each message defined in the mojom interface, and each\n * receiver can have any number of listeners added to it.\n */\nexport class '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'CallbackRouter {\n  constructor() {\n    this.helper_internal_ = new mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal(\n      '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote);\n\n    /**\n     * @public {!mojo.internal.interfaceSupport.InterfaceReceiverHelper<!'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote>}\n     */\n    this.$ = new mojo.internal.interfaceSupport.InterfaceReceiverHelper(this.helper_internal_);\n\n    this.router_ = new mojo.internal.interfaceSupport.CallbackRouter;\n'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_interface_message_id = missing
        _loop_vars = {}
        pass
        l_1_interface_message_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        _loop_vars['interface_message_id'] = l_1_interface_message_id
        yield '\n    /**\n     * @public {!mojo.internal.interfaceSupport.InterfaceCallbackReceiver}\n     */\n    this.'
        yield str(environment.getattr(l_1_method, 'name'))
        yield ' =\n        new mojo.internal.interfaceSupport.InterfaceCallbackReceiver(\n            this.router_);\n\n    this.helper_internal_.registerHandler(\n        '
        yield str(environment.getattr(l_1_method, 'ordinal'))
        yield ',\n        '
        yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
        yield '_ParamsSpec.$,'
        if ((environment.getattr(l_1_method, 'response_parameters') != None) or (environment.getattr(l_1_method, 'result_response') != None)):
            pass
            yield '\n        '
            yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
            yield '_ResponseParamsSpec.$,\n        this.'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '.createReceiverHandler(true /* expectsResponse */),\n        '
            yield str(('true' if (environment.getattr(l_1_method, 'result_response') != None) else 'false'))
            yield ');'
        else:
            pass
            yield '\n        null,\n        this.'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '.createReceiverHandler(false /* expectsResponse */),\n        false);'
    l_1_method = l_1_interface_message_id = missing
    yield '\n    /** @public {!mojo.internal.interfaceSupport.ConnectionErrorEventRouter} */\n    this.onConnectionError = this.helper_internal_.getConnectionErrorEventRouter();\n  }\n\n  /**\n   * @param {number} id An ID returned by a prior call to addListener.\n   * @return {boolean} True iff the identified listener was found and removed.\n   */\n  removeListener(id) {\n    return this.router_.removeListener(id);\n  }\n}'

blocks = {}
debug_info = '1=32&3=40&4=45&6=50&7=52&11=62&12=67&23=83&35=85&40=89&41=92&42=96&43=98&44=101&45=104&52=112&54=114&58=116&62=118&66=120&74=123&75=127&78=130&79=132&80=135&81=139&83=145&88=152&89=154&90=156&91=159&96=166&97=170&100=176&106=180&110=182&112=184&115=186&117=188&120=190&124=192&125=196&128=199&129=201&130=203&131=206&135=212&136=214&143=218&148=220&156=224&159=226&166=228&167=234&168=238&172=241&177=243&180=245&183=247&188=249&189=253&194=256&199=258&200=260&201=262&202=265&203=267&204=269&207=274'