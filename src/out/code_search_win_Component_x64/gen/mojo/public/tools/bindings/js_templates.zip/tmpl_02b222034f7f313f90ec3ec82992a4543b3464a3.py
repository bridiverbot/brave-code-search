from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'lite/struct_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_module = resolve('module')
    l_0_generate_struct_deserializers = resolve('generate_struct_deserializers')
    l_0_generate_closure_exports = resolve('generate_closure_exports')
    l_0_generate_fuzzing = resolve('generate_fuzzing')
    l_0_enum_def = l_0_fields = missing
    try:
        t_1 = environment.filters['constant_value']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'constant_value' found.")
    try:
        t_2 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_3 = environment.filters['is_bool_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_bool_kind' found.")
    try:
        t_4 = environment.filters['is_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_value_kind_packed_field' found.")
    try:
        t_5 = environment.filters['is_primary_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_primary_nullable_value_kind_packed_field' found.")
    try:
        t_6 = environment.filters['lite_closure_field_type']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'lite_closure_field_type' found.")
    try:
        t_7 = environment.filters['lite_closure_type_with_nullability']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'lite_closure_type_with_nullability' found.")
    try:
        t_8 = environment.filters['lite_default_value']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'lite_default_value' found.")
    try:
        t_9 = environment.filters['lite_js_type']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'lite_js_type' found.")
    try:
        t_10 = environment.filters['sanitize_identifier']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'sanitize_identifier' found.")
    pass
    for l_1_constant in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'constants'):
        _loop_vars = {}
        pass
        yield '\n/**\n * @const { '
        yield str(t_7(environment.getattr(l_1_constant, 'kind')))
        yield ' }\n * @export\n */\n'
        yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '_'
        yield str(environment.getattr(l_1_constant, 'name'))
        yield ' =\n    '
        yield str(t_1(l_1_constant))
        yield ';\n'
    l_1_constant = missing
    included_template = environment.get_template('lite/enum_definition.tmpl', 'lite/struct_definition.tmpl').make_module(context.get_all(), True, {'enum_def': l_0_enum_def, 'fields': l_0_fields})
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined(f"the template {included_template.__name__!r} (imported on line 10 in 'lite/struct_definition.tmpl') does not export the requested name 'enum_def'", name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    yield '\n'
    for l_1_enum in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'enums'):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), t_2('%s.%sSpec', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'), environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name')), t_2('%s.%s', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'), environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name')), l_1_enum, _loop_vars=_loop_vars))
        yield '\n'
    l_1_enum = missing
    yield '\n\nmojo.internal.Struct(\n    '
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield "Spec.$,\n    '"
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield "',\n    ["
    for l_1_packed_field in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields_in_ordinal_order'):
        l_1_name = resolve('name')
        l_1_isPrimary = resolve('isPrimary')
        _loop_vars = {}
        pass
        yield "\n      mojo.internal.StructField(\n        '"
        yield str(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'name'))
        yield "', "
        yield str(environment.getattr(l_1_packed_field, 'offset'))
        yield ',\n        '
        if t_3(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')):
            pass
            yield str(environment.getattr(l_1_packed_field, 'bit'))
        else:
            pass
            yield '0'
        yield ',\n        '
        yield str(t_9(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')))
        yield ',\n        '
        yield str(t_8(environment.getattr(l_1_packed_field, 'field')))
        yield ','
        if environment.getattr(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind'), 'is_nullable'):
            pass
            yield '\n        true, /* nullable */'
        else:
            pass
            yield '\n        false, /* nullable */'
        yield '\n        0 /* minVersion */,'
        if t_4(l_1_packed_field):
            pass
            l_1_name = environment.getattr(environment.getattr(l_1_packed_field, 'original_field'), 'name')
            _loop_vars['name'] = l_1_name
            l_1_isPrimary = t_5(l_1_packed_field)
            _loop_vars['isPrimary'] = l_1_isPrimary
            yield '\n        {'
            if (undefined(name='isPrimary') if l_1_isPrimary is missing else l_1_isPrimary):
                pass
                yield '\n          isPrimary: true,\n          linkedValueFieldName: "'
                yield str(environment.getattr(environment.getattr(environment.getattr(l_1_packed_field, 'linked_value_packed_field'), 'field'), 'name'))
                yield '",'
            else:
                pass
                yield '\n          isPrimary: false,'
            yield '\n          originalFieldName: "'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '",\n        }'
        yield '\n      ),'
    l_1_packed_field = l_1_name = l_1_isPrimary = missing
    yield '\n    ],\n    ['
    for l_1_info in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'):
        _loop_vars = {}
        pass
        yield '['
        yield str(environment.getattr(l_1_info, 'version'))
        yield ', '
        yield str(environment.getattr(l_1_info, 'num_bytes'))
        yield '],'
    l_1_info = missing
    yield ']);\n\n'
    if (undefined(name='generate_struct_deserializers') if l_0_generate_struct_deserializers is missing else l_0_generate_struct_deserializers):
        pass
        yield '\n'
        yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '_Deserialize =\n    mojo.internal.createStructDeserializer('
        yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield 'Spec.$);\n'
    yield '\n\n'
    if (undefined(name='generate_closure_exports') if l_0_generate_closure_exports is missing else l_0_generate_closure_exports):
        pass
        yield "goog.provide('"
        yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield "');"
    yield '\n\n/** @record */\n'
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield ' = class {'
    l_0_fields = []
    context.vars['fields'] = l_0_fields
    context.exported_vars.add('fields')
    for l_1_packed_field in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields_in_ordinal_order'):
        l_1_original_field = resolve('original_field')
        l_1__ = resolve('_')
        _loop_vars = {}
        pass
        if t_4(l_1_packed_field):
            pass
            if t_5(l_1_packed_field):
                pass
                l_1_original_field = environment.getattr(l_1_packed_field, 'original_field')
                _loop_vars['original_field'] = l_1_original_field
                l_1__ = context.call(environment.getattr((undefined(name='fields') if l_0_fields is missing else l_0_fields), 'append'), {'name': environment.getattr((undefined(name='original_field') if l_1_original_field is missing else l_1_original_field), 'name'), 'kind': environment.getattr((undefined(name='original_field') if l_1_original_field is missing else l_1_original_field), 'kind')}, _loop_vars=_loop_vars)
                _loop_vars['_'] = l_1__
        else:
            pass
            l_1__ = context.call(environment.getattr((undefined(name='fields') if l_0_fields is missing else l_0_fields), 'append'), {'name': environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'name'), 'kind': environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')}, _loop_vars=_loop_vars)
            _loop_vars['_'] = l_1__
    l_1_packed_field = l_1_original_field = l_1__ = missing
    if (undefined(name='generate_fuzzing') if l_0_generate_fuzzing is missing else l_0_generate_fuzzing):
        pass
        yield '\n  constructor('
        l_1_loop = missing
        for l_1_param, l_1_loop in LoopContext((undefined(name='fields') if l_0_fields is missing else l_0_fields), undefined):
            _loop_vars = {}
            pass
            yield '\n    '
            yield str(t_10(environment.getattr(l_1_param, 'name')))
            if (not environment.getattr(l_1_loop, 'last')):
                pass
                yield ','
        l_1_loop = l_1_param = missing
        yield ') {'
        for l_1_param in (undefined(name='fields') if l_0_fields is missing else l_0_fields):
            _loop_vars = {}
            pass
            yield '\n    /** @export { '
            yield str(t_6(environment.getattr(l_1_param, 'kind')))
            yield ' } */\n    this.'
            yield str(environment.getattr(l_1_param, 'name'))
            yield ' = '
            yield str(t_10(environment.getattr(l_1_param, 'name')))
            yield ';'
        l_1_param = missing
        yield '}'
    else:
        pass
        yield '\n  constructor() {'
        for l_1_param in (undefined(name='fields') if l_0_fields is missing else l_0_fields):
            _loop_vars = {}
            pass
            yield '\n    /** @export { '
            yield str(t_6(environment.getattr(l_1_param, 'kind')))
            yield ' } */\n    this.'
            yield str(environment.getattr(l_1_param, 'name'))
            yield ';'
        l_1_param = missing
        yield '}'
    yield '\n};'

blocks = {}
debug_info = '1=77&3=81&6=83&7=89&10=92&11=99&12=103&17=107&18=111&20=113&22=119&23=123&25=130&26=132&27=134&33=141&34=143&35=145&37=148&39=151&43=157&49=162&50=166&54=172&55=175&56=179&59=184&60=187&64=192&65=196&66=199&67=204&68=206&69=208&70=210&73=214&77=217&79=221&80=225&82=231&83=235&84=237&89=246&90=250&91=252'