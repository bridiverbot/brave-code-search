from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'enum.java.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_enum = resolve('enum')
    l_0_enum_def = missing
    pass
    included_template = environment.get_template('enum_definition.tmpl', 'enum.java.tmpl')._get_default_module(context)
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined(f"the template {included_template.__name__!r} (imported on line 1 in 'enum.java.tmpl') does not export the requested name 'enum_def'", name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    yield '\n'
    template = environment.get_template('header.java.tmpl', 'enum.java.tmpl')
    for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_def': l_0_enum_def})):
        yield event
    yield '\n\n'
    yield str(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), (undefined(name='enum') if l_0_enum is missing else l_0_enum), True))

blocks = {}
debug_info = '1=13&2=20&4=24'