from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'wrapper_union_class_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module_prefix = resolve('module_prefix')
    l_0_union = resolve('union')
    l_0_kythe_annotation = resolve('kythe_annotation')
    l_0_export_attribute = resolve('export_attribute')
    l_0_union_prefix = missing
    try:
        t_1 = environment.filters['cpp_union_getter_return_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_union_getter_return_type' found.")
    try:
        t_2 = environment.filters['cpp_wrapper_param_type_new']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_param_type_new' found.")
    try:
        t_3 = environment.filters['cpp_wrapper_type']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_type' found.")
    try:
        t_4 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_5 = environment.filters['is_double_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_double_kind' found.")
    try:
        t_6 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_7 = environment.filters['is_float_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_float_kind' found.")
    try:
        t_8 = environment.filters['is_hashable']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'is_hashable' found.")
    try:
        t_9 = environment.filters['is_integral_kind']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_integral_kind' found.")
    try:
        t_10 = environment.filters['should_inline_union']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'should_inline_union' found.")
    try:
        t_11 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    pass
    l_0_union_prefix = t_4('%s.%s', (undefined(name='module_prefix') if l_0_module_prefix is missing else l_0_module_prefix), environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    context.vars['union_prefix'] = l_0_union_prefix
    context.exported_vars.add('union_prefix')
    yield '\n\n'
    yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), (undefined(name='union_prefix') if l_0_union_prefix is missing else l_0_union_prefix)))
    yield '\nclass '
    yield str((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield ' {\n public:\n  using DataView = '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'DataView;\n  using Data_ = internal::'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '_Data;\n  using Tag = Data_::'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '_Tag;\n\n  template <typename... Args>\n  static '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'Ptr New(Args&&... args) {\n    static_assert(\n        sizeof...(args) < 0,\n        "Do not use Union::New(); to create a union of a given subtype, use "\n        "New<SubType>(), not New() followed by set_<sub_type>(). To represent "\n        "an empty union, mark the field or parameter as nullable in the mojom "\n        "definition.");\n    return nullptr;\n  }\n'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n  // Construct an instance holding |'
        yield str(environment.getattr(l_1_field, 'name'))
        yield '|.\n  static '
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield 'Ptr New'
        yield str(t_11(environment.getattr(l_1_field, 'name')))
        yield '(\n      '
        yield str(t_2(environment.getattr(l_1_field, 'kind')))
        yield ' value);'
    l_1_field = missing
    yield '\n\n  template <typename U>\n  static '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'Ptr From(const U& u) {\n    return mojo::TypeConverter<'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'Ptr, U>::Convert(u);\n  }\n\n  template <typename U>\n  U To() const {\n    return mojo::TypeConverter<U, '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '>::Convert(*this);\n  }\n  ~'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '();\n'
    if (not t_10((undefined(name='union') if l_0_union is missing else l_0_union))):
        pass
        yield '\n  // Delete the copy constructor and copy assignment operators because `data_`\n  // contains raw pointers that must not be copied.\n  '
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '(const '
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '& other) = delete;\n  '
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '& operator=(const '
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '& other) = delete;'
    yield '\n\n  // Clone() is a template so it is only instantiated if it is used. Thus, the\n  // bindings generator does not need to know whether Clone() or copy\n  // constructor/assignment are available for members.\n  template <typename UnionPtrType = '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'Ptr>\n  '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'Ptr Clone() const;\n\n  // Equals() is a template so it is only instantiated if it is used. Thus, the\n  // bindings generator does not need to know whether Equals() or == operator\n  // are available for members.\n  template <typename T,\n            typename std::enable_if<std::is_same<\n                T, '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '>::value>::type* = nullptr>\n  bool Equals(const T& other) const;\n\n  template <typename T,\n            typename std::enable_if<std::is_same<\n                T, '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '>::value>::type* = nullptr>\n  bool operator==(const T& rhs) const { return Equals(rhs); }'
    if t_8((undefined(name='union') if l_0_union is missing else l_0_union)):
        pass
        yield '\n  size_t Hash(size_t seed) const;'
    yield '\n\n  Tag which() const {\n    return tag_;\n  }\n'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_4('%s.%s', (undefined(name='union_prefix') if l_0_union_prefix is missing else l_0_union_prefix), environment.getattr(l_1_field, 'name')), _loop_vars=_loop_vars))
        yield '\n  bool is_'
        yield str(environment.getattr(l_1_field, 'name'))
        yield '() const { return tag_ == Tag::k'
        yield str(t_11(environment.getattr(l_1_field, 'name')))
        yield '; }'
        if (((t_5(environment.getattr(l_1_field, 'kind')) or t_6(environment.getattr(l_1_field, 'kind'))) or t_7(environment.getattr(l_1_field, 'kind'))) or t_9(environment.getattr(l_1_field, 'kind'))):
            pass
            yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_4('%s.%s', (undefined(name='union_prefix') if l_0_union_prefix is missing else l_0_union_prefix), environment.getattr(l_1_field, 'name')), _loop_vars=_loop_vars))
            yield '\n  '
            yield str(t_1(environment.getattr(l_1_field, 'kind')))
            yield ' get_'
            yield str(environment.getattr(l_1_field, 'name'))
            yield '() const {\n    CHECK(tag_ == Tag::k'
            yield str(t_11(environment.getattr(l_1_field, 'name')))
            yield ');\n    return data_.'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ';\n  }'
        else:
            pass
            yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_4('%s.%s', (undefined(name='union_prefix') if l_0_union_prefix is missing else l_0_union_prefix), environment.getattr(l_1_field, 'name')), _loop_vars=_loop_vars))
            yield '\n  const '
            yield str(t_1(environment.getattr(l_1_field, 'kind')))
            yield ' get_'
            yield str(environment.getattr(l_1_field, 'name'))
            yield '() const {\n    CHECK(tag_ == Tag::k'
            yield str(t_11(environment.getattr(l_1_field, 'name')))
            yield ');\n    return data_.'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ';\n  }'
            yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_4('%s.%s', (undefined(name='union_prefix') if l_0_union_prefix is missing else l_0_union_prefix), environment.getattr(l_1_field, 'name')), _loop_vars=_loop_vars))
            yield '\n  '
            yield str(t_1(environment.getattr(l_1_field, 'kind')))
            yield ' get_'
            yield str(environment.getattr(l_1_field, 'name'))
            yield '() {\n    CHECK(tag_ == Tag::k'
            yield str(t_11(environment.getattr(l_1_field, 'name')))
            yield ');\n    return data_.'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ';\n  }'
        yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_4('%s.%s', (undefined(name='union_prefix') if l_0_union_prefix is missing else l_0_union_prefix), environment.getattr(l_1_field, 'name')), _loop_vars=_loop_vars))
        yield '\n  void set_'
        yield str(environment.getattr(l_1_field, 'name'))
        yield '('
        yield str(t_2(environment.getattr(l_1_field, 'kind')))
        yield ' '
        yield str(environment.getattr(l_1_field, 'name'))
        yield ');\n'
    l_1_field = missing
    yield '\n  template <typename UserType>\n  static mojo::Message SerializeAsMessage(UserType* input) {\n    return mojo::internal::SerializeAsMessageImpl<\n        '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::DataView>(input);\n  }\n\n  template <typename UserType>\n  static bool DeserializeFromMessage(mojo::Message input,\n                                     UserType* output) {\n    return mojo::internal::DeserializeImpl<'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::DataView>(\n        input, input.payload(), input.payload_num_bytes(), output, Validate);\n  }\n\n private:\n  template <typename T>\n  friend class ::mojo::InlinedStructPtr;\n  template <typename T>\n  friend class ::mojo::StructPtr;\n\n  union Union_ {'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n    Union_(\n        std::in_place_index_t<static_cast<size_t>(Tag::k'
        yield str(t_11(environment.getattr(l_1_field, 'name')))
        yield ')>,\n        '
        yield str(t_2(environment.getattr(l_1_field, 'kind')))
        yield ' value);'
    l_1_field = missing
    yield '\n    // The contents of the union are explicitly destroyed by `DestroyActive()`.\n    ~Union_() {}\n'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n    '
        yield str(t_3(environment.getattr(l_1_field, 'kind')))
        yield ' '
        yield str(environment.getattr(l_1_field, 'name'))
        yield ';'
    l_1_field = missing
    yield '\n  };\n'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n  '
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '(\n      std::in_place_index_t<static_cast<size_t>(Tag::k'
        yield str(t_11(environment.getattr(l_1_field, 'name')))
        yield ')>,\n      '
        yield str(t_2(environment.getattr(l_1_field, 'kind')))
        yield ' value);'
    l_1_field = missing
    yield '\n\n  static bool Validate(const void* data,\n                       mojo::internal::ValidationContext* validation_context);\n\n  void DestroyActive();\n  Tag tag_;\n  Union_ data_;\n};'

blocks = {}
debug_info = '1=82&3=86&4=88&6=92&7=94&8=96&11=98&20=100&21=104&22=106&23=110&27=114&28=116&33=118&35=120&36=122&39=125&40=129&46=134&47=136&54=138&59=140&62=142&69=146&70=149&71=151&72=155&73=157&74=159&75=163&76=165&79=169&80=171&81=175&82=177&84=179&85=181&86=185&87=187&90=189&91=191&96=199&102=201&113=203&115=207&116=209&120=213&121=217&124=223&125=227&126=229&127=231'