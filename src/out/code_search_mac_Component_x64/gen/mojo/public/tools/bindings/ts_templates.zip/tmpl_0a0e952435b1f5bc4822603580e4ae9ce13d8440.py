from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'struct_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_typemapped_structs = resolve('typemapped_structs')
    l_0_typemap = resolve('typemap')
    l_0_generate_struct_deserializers = resolve('generate_struct_deserializers')
    l_0_enum_def = l_0_struct_type = missing
    try:
        t_1 = environment.filters['constant_value']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'constant_value' found.")
    try:
        t_2 = environment.filters['default_ts_value']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'default_ts_value' found.")
    try:
        t_3 = environment.filters['is_bool_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_bool_kind' found.")
    try:
        t_4 = environment.filters['is_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_value_kind_packed_field' found.")
    try:
        t_5 = environment.filters['is_primary_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_primary_nullable_value_kind_packed_field' found.")
    try:
        t_6 = environment.filters['spec_type']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'spec_type' found.")
    try:
        t_7 = environment.filters['ts_type']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'ts_type' found.")
    try:
        t_8 = environment.filters['ts_type_maybe_nullable']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'ts_type_maybe_nullable' found.")
    pass
    for l_1_constant in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'constants'):
        _loop_vars = {}
        pass
        yield '\nexport const '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '_'
        yield str(environment.getattr(l_1_constant, 'name'))
        yield ': '
        yield str(t_8(environment.getattr(l_1_constant, 'kind')))
        yield ' =\n    '
        yield str(t_1(l_1_constant))
        yield ';\n'
    l_1_constant = missing
    included_template = environment.get_template('enum_definition.tmpl', 'struct_definition.tmpl').make_module(context.get_all(), True, {'enum_def': l_0_enum_def, 'struct_type': l_0_struct_type, 'typemap': l_0_typemap})
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined(f"the template {included_template.__name__!r} (imported on line 6 in 'struct_definition.tmpl') does not export the requested name 'enum_def'", name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    yield '\n'
    for l_1_enum in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'enums'):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), l_1_enum, _loop_vars=_loop_vars))
        yield '\n'
    l_1_enum = missing
    yield '\n\nexport declare interface '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'MojoType {'
    for l_1_packed_field in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields'):
        l_1_original_field = resolve('original_field')
        l_1_name = resolve('name')
        l_1_kind = resolve('kind')
        l_1_f = resolve('f')
        _loop_vars = {}
        pass
        if t_4(l_1_packed_field):
            pass
            if t_5(l_1_packed_field):
                pass
                l_1_original_field = environment.getattr(l_1_packed_field, 'original_field')
                _loop_vars['original_field'] = l_1_original_field
                l_1_name = environment.getattr((undefined(name='original_field') if l_1_original_field is missing else l_1_original_field), 'name')
                _loop_vars['name'] = l_1_name
                l_1_kind = environment.getattr((undefined(name='original_field') if l_1_original_field is missing else l_1_original_field), 'kind')
                _loop_vars['kind'] = l_1_kind
                yield '\n  '
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ': '
                yield str(t_8((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield ';'
        else:
            pass
            yield '\n  '
            l_1_f = environment.getattr(l_1_packed_field, 'field')
            _loop_vars['f'] = l_1_f
            yield str(environment.getattr((undefined(name='f') if l_1_f is missing else l_1_f), 'name'))
            yield ': '
            yield str(t_8(environment.getattr((undefined(name='f') if l_1_f is missing else l_1_f), 'kind')))
            yield ';'
    l_1_packed_field = l_1_original_field = l_1_name = l_1_kind = l_1_f = missing
    yield '\n}\n\n'
    if ((undefined(name='struct') if l_0_struct is missing else l_0_struct) in (undefined(name='typemapped_structs') if l_0_typemapped_structs is missing else l_0_typemapped_structs)):
        pass
        yield 'export type '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield ' = '
        yield str(environment.getattr(environment.getitem((undefined(name='typemapped_structs') if l_0_typemapped_structs is missing else l_0_typemapped_structs), (undefined(name='struct') if l_0_struct is missing else l_0_struct)), 'typename'))
        yield ';'
    else:
        pass
        yield '\nexport type '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield ' = '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield 'MojoType;'
    l_0_struct_type = (environment.getattr(environment.getitem((undefined(name='typemapped_structs') if l_0_typemapped_structs is missing else l_0_typemapped_structs), (undefined(name='struct') if l_0_struct is missing else l_0_struct)), 'typename') if ((undefined(name='struct') if l_0_struct is missing else l_0_struct) in (undefined(name='typemapped_structs') if l_0_typemapped_structs is missing else l_0_typemapped_structs)) else (environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name') + 'MojoType'))
    context.vars['struct_type'] = l_0_struct_type
    context.exported_vars.add('struct_type')
    if ((undefined(name='struct') if l_0_struct is missing else l_0_struct) in (undefined(name='typemapped_structs') if l_0_typemapped_structs is missing else l_0_typemapped_structs)):
        pass
        yield '\n'
        l_0_typemap = environment.getitem((undefined(name='typemapped_structs') if l_0_typemapped_structs is missing else l_0_typemapped_structs), (undefined(name='struct') if l_0_struct is missing else l_0_struct))
        context.vars['typemap'] = l_0_typemap
        context.exported_vars.add('typemap')
        yield '\nconst converterFor'
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield ': '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield 'TypeMapper<'
        yield str(environment.getattr((undefined(name='typemap') if l_0_typemap is missing else l_0_typemap), 'typename'))
        yield '>\n    = new '
        yield str(environment.getattr((undefined(name='typemap') if l_0_typemap is missing else l_0_typemap), 'converter'))
        yield '();\n\nmojo.internal.TypemappedStruct<'
        yield str((undefined(name='struct_type') if l_0_struct_type is missing else l_0_struct_type))
        yield ', '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield 'MojoType> ('
    else:
        pass
        yield '\nmojo.internal.Struct<'
        yield str((undefined(name='struct_type') if l_0_struct_type is missing else l_0_struct_type))
        yield '>('
    yield '\n    '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield "Spec.$,\n    '"
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield "',"
    if ((undefined(name='struct') if l_0_struct is missing else l_0_struct) in (undefined(name='typemapped_structs') if l_0_typemapped_structs is missing else l_0_typemapped_structs)):
        pass
        yield '\n    '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield 'DataView,\n    converterFor'
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield ','
    yield '\n    ['
    for l_1_packed_field in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields_in_ordinal_order'):
        l_1_name = resolve('name')
        l_1_is_primary = resolve('is_primary')
        l_1_typemap = l_0_typemap
        l_1_original_name = resolve('original_name')
        l_1_field_type = missing
        _loop_vars = {}
        pass
        l_1_field_type = t_7(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind'))
        _loop_vars['field_type'] = l_1_field_type
        yield '\n      mojo.internal.StructField<'
        yield str((undefined(name='struct_type') if l_0_struct_type is missing else l_0_struct_type))
        yield ', '
        yield str((undefined(name='field_type') if l_1_field_type is missing else l_1_field_type))
        yield ">(\n        '"
        yield str(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'name'))
        yield "', "
        yield str(environment.getattr(l_1_packed_field, 'offset'))
        yield ',\n        '
        if t_3(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')):
            pass
            yield str(environment.getattr(l_1_packed_field, 'bit'))
        else:
            pass
            yield '0'
        yield ',\n        '
        yield str(t_6(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')))
        yield ',\n        '
        yield str(t_2(environment.getattr(l_1_packed_field, 'field')))
        yield ','
        if environment.getattr(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind'), 'is_nullable'):
            pass
            yield '\n        true /* nullable */,'
        else:
            pass
            yield '\n        false /* nullable */,'
        yield '\n        '
        yield str((environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'min_version') or 0))
        yield ','
        if t_4(l_1_packed_field):
            pass
            l_1_name = environment.getattr(environment.getattr(l_1_packed_field, 'original_field'), 'name')
            _loop_vars['name'] = l_1_name
            l_1_is_primary = t_5(l_1_packed_field)
            _loop_vars['is_primary'] = l_1_is_primary
            yield '\n        {'
            if (undefined(name='is_primary') if l_1_is_primary is missing else l_1_is_primary):
                pass
                yield '\n          isPrimary: true,\n          linkedValueFieldName: "'
                yield str(environment.getattr(environment.getattr(environment.getattr(l_1_packed_field, 'linked_value_packed_field'), 'field'), 'name'))
                yield '",'
            else:
                pass
                yield '\n          isPrimary: false,'
            yield '\n          originalFieldName: "'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '",\n        },'
        else:
            pass
            yield '\n        undefined,'
        if ((undefined(name='struct') if l_0_struct is missing else l_0_struct) in (undefined(name='typemapped_structs') if l_0_typemapped_structs is missing else l_0_typemapped_structs)):
            pass
            l_1_typemap = environment.getitem((undefined(name='typemapped_structs') if l_0_typemapped_structs is missing else l_0_typemapped_structs), (undefined(name='struct') if l_0_struct is missing else l_0_struct))
            _loop_vars['typemap'] = l_1_typemap
            if t_4(l_1_packed_field):
                pass
                l_1_original_name = environment.getattr(environment.getattr(l_1_packed_field, 'original_field'), 'name')
                _loop_vars['original_name'] = l_1_original_name
                if t_5(l_1_packed_field):
                    pass
                    yield '\n        ((value: '
                    yield str(environment.getattr((undefined(name='typemap') if l_1_typemap is missing else l_1_typemap), 'typename'))
                    yield ') => converterFor'
                    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
                    yield '.'
                    yield str((undefined(name='original_name') if l_1_original_name is missing else l_1_original_name))
                    yield '(value) !== null),'
                else:
                    pass
                    yield '\n\n        ((value: '
                    yield str(environment.getattr((undefined(name='typemap') if l_1_typemap is missing else l_1_typemap), 'typename'))
                    yield ') => converterFor'
                    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
                    yield '.'
                    yield str((undefined(name='original_name') if l_1_original_name is missing else l_1_original_name))
                    yield '(value)),'
            else:
                pass
                yield '\n        ((value: '
                yield str(environment.getattr((undefined(name='typemap') if l_1_typemap is missing else l_1_typemap), 'typename'))
                yield ') => converterFor'
                yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
                yield '.'
                yield str(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'name'))
                yield '(value)),'
        else:
            pass
            yield '\n        undefined,'
        yield '\n    ),'
    l_1_packed_field = l_1_field_type = l_1_name = l_1_is_primary = l_1_typemap = l_1_original_name = missing
    yield '\n    ],\n    ['
    for l_1_info in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'):
        _loop_vars = {}
        pass
        yield '['
        yield str(environment.getattr(l_1_info, 'version'))
        yield ', '
        yield str(environment.getattr(l_1_info, 'num_bytes'))
        yield '],'
    l_1_info = missing
    yield ']);\n\n'
    if (undefined(name='generate_struct_deserializers') if l_0_generate_struct_deserializers is missing else l_0_generate_struct_deserializers):
        pass
        yield '\nexport const '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '_Deserialize =\n    mojo.internal.createStructDeserializer('
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield 'Spec.$);\n'

blocks = {}
debug_info = '1=64&2=68&3=74&6=77&7=84&8=88&11=92&12=94&13=101&14=103&15=105&16=107&17=109&18=112&21=119&22=121&27=127&28=130&30=137&33=141&34=144&35=147&36=151&37=157&39=159&41=166&43=169&44=171&45=173&46=176&47=178&50=181&52=189&53=192&54=196&55=200&57=207&58=209&59=211&64=218&65=220&66=222&67=224&69=227&71=230&75=236&80=241&81=243&82=245&83=247&84=249&85=252&88=261&91=270&100=282&101=286&105=292&106=295&107=297'