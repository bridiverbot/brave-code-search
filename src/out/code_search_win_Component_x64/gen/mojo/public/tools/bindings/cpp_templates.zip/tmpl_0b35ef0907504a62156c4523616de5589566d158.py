from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module-send-validation.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_variant = resolve('variant')
    l_0_imports = resolve('imports')
    l_0_interfaces = resolve('interfaces')
    l_0_enums = resolve('enums')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_namespace_begin = l_0_namespace_end = l_0_include_guard = l_0_enum_forward = l_0_header_guard = l_0_struct_macros = l_0_union_macros = missing
    try:
        t_1 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_2 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_3 = environment.filters['is_native_only_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_native_only_kind' found.")
    try:
        t_4 = environment.filters['use_custom_serializer']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'use_custom_serializer' found.")
    pass
    yield '// Copyright 2025 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    included_template = environment.get_template('cpp_macros.tmpl', 'module-send-validation.h.tmpl')._get_default_module(context)
    l_0_namespace_begin = getattr(included_template, 'namespace_begin', missing)
    if l_0_namespace_begin is missing:
        l_0_namespace_begin = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-send-validation.h.tmpl') does not export the requested name 'namespace_begin'", name='namespace_begin')
    l_0_namespace_end = getattr(included_template, 'namespace_end', missing)
    if l_0_namespace_end is missing:
        l_0_namespace_end = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-send-validation.h.tmpl') does not export the requested name 'namespace_end'", name='namespace_end')
    l_0_include_guard = getattr(included_template, 'include_guard', missing)
    if l_0_include_guard is missing:
        l_0_include_guard = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-send-validation.h.tmpl') does not export the requested name 'include_guard'", name='include_guard')
    context.vars.update({'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'include_guard': l_0_include_guard})
    context.exported_vars.difference_update(('namespace_begin', 'namespace_end', 'include_guard'))
    included_template = environment.get_template('enum_macros.tmpl', 'module-send-validation.h.tmpl')._get_default_module(context)
    l_0_enum_forward = getattr(included_template, 'enum_forward', missing)
    if l_0_enum_forward is missing:
        l_0_enum_forward = undefined(f"the template {included_template.__name__!r} (imported on line 7 in 'module-send-validation.h.tmpl') does not export the requested name 'enum_forward'", name='enum_forward')
    context.vars['enum_forward'] = l_0_enum_forward
    context.exported_vars.discard('enum_forward')
    l_0_header_guard = context.call((undefined(name='include_guard') if l_0_include_guard is missing else l_0_include_guard), '', str_join((environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), '_send_validation', )), (undefined(name='variant') if l_0_variant is missing else l_0_variant))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    yield '\n\n#ifndef '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n#include "'
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-shared-internal.h"'
    for l_1_import in (undefined(name='imports') if l_0_imports is missing else l_0_imports):
        _loop_vars = {}
        pass
        yield '\n#include "'
        yield str(environment.getattr(l_1_import, 'path'))
        yield '-shared.h"'
    l_1_import = missing
    yield '\n\n#include "'
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-data-view.h"\n\n#include "mojo/public/cpp/bindings/lib/send_validation_type.h"\n#include "mojo/public/cpp/bindings/lib/send_validation.h"'
    if (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        yield '\n#include "mojo/public/cpp/bindings/lib/interface_serialization_send_validation.h"'
    if (undefined(name='enums') if l_0_enums is missing else l_0_enums):
        pass
        yield '\n#include "mojo/public/cpp/bindings/lib/has_send_validation_helper.h"'
    yield '\n\nnamespace mojo::internal {'
    for l_1_enum in (undefined(name='enums') if l_0_enums is missing else l_0_enums):
        l_1_mojom_type = resolve('mojom_type')
        _loop_vars = {}
        pass
        if (not t_3(l_1_enum)):
            pass
            l_1_mojom_type = t_1(l_1_enum, flatten_nested_kind=True)
            _loop_vars['mojom_type'] = l_1_mojom_type
            yield '\ntemplate <typename MaybeConstUserType>\nstruct HasSendValidationSerialize<'
            yield str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
            yield ', MaybeConstUserType>\n    : std::false_type {};'
    l_1_enum = l_1_mojom_type = missing
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'module-send-validation.h.tmpl')._get_default_module(context)
    context.exported_vars.discard('struct_macros')
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        l_1_data_view = resolve('data_view')
        l_1_data_type = resolve('data_type')
        _loop_vars = {}
        pass
        if (not t_4(l_1_struct)):
            pass
            l_1_data_view = str_join((t_1(l_1_struct), 'DataView', ))
            _loop_vars['data_view'] = l_1_data_view
            l_1_data_type = t_1(l_1_struct, internal=True)
            _loop_vars['data_type'] = l_1_data_type
            yield '\n\ntemplate <typename MaybeConstUserType, mojo::internal::SendValidation send_validation>\nstruct SendValidationSerializer<'
            yield str((undefined(name='data_view') if l_1_data_view is missing else l_1_data_view))
            yield ', MaybeConstUserType, send_validation> {\n  using UserType = typename std::remove_const<MaybeConstUserType>::type;\n  using Traits = StructTraits<'
            yield str((undefined(name='data_view') if l_1_data_view is missing else l_1_data_view))
            yield ', UserType>;\n  static void Serialize(\n      MaybeConstUserType& input,\n      mojo::internal::MessageFragment<'
            yield str((undefined(name='data_type') if l_1_data_type is missing else l_1_data_type))
            yield '>& fragment) {\n    if (CallIsNullIfExists<Traits>(input))\n      return;\n    '
            yield str(t_2(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'serialize'), l_1_struct, str_join((environment.getattr(l_1_struct, 'name'), ' struct', )), 'Traits::%s(input)', 'fragment', 'template', True, _loop_vars=_loop_vars), 4))
            yield '\n  }\n};'
    l_1_struct = l_1_data_view = l_1_data_type = missing
    l_0_union_macros = context.vars['union_macros'] = environment.get_template('union_macros.tmpl', 'module-send-validation.h.tmpl')._get_default_module(context)
    context.exported_vars.discard('union_macros')
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        l_1_data_view = l_1_data_type = missing
        _loop_vars = {}
        pass
        l_1_data_view = str_join((t_1(l_1_union), 'DataView', ))
        _loop_vars['data_view'] = l_1_data_view
        l_1_data_type = t_1(l_1_union, internal=True)
        _loop_vars['data_type'] = l_1_data_type
        yield '\ntemplate <typename MaybeConstUserType, SendValidation send_validation>\nstruct SendValidationSerializer<'
        yield str((undefined(name='data_view') if l_1_data_view is missing else l_1_data_view))
        yield ', MaybeConstUserType, send_validation> {\n  using UserType = typename std::remove_const<MaybeConstUserType>::type;\n  using Traits = UnionTraits<'
        yield str((undefined(name='data_view') if l_1_data_view is missing else l_1_data_view))
        yield ', UserType>;\n  static void Serialize(MaybeConstUserType& input,\n                        MessageFragment<'
        yield str((undefined(name='data_type') if l_1_data_type is missing else l_1_data_type))
        yield '>& fragment,\n                        bool inlined) {\n    '
        yield str(context.call(environment.getattr((undefined(name='union_macros') if l_0_union_macros is missing else l_0_union_macros), 'serialize'), l_1_union, 'template', _loop_vars=_loop_vars))
        yield '\n  }\n};'
    l_1_union = l_1_data_view = l_1_data_type = missing
    yield '\n\n}  // namespace mojo::internal\n\n#endif  // '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=44&7=56&9=62&11=66&12=68&14=70&15=72&16=76&19=80&24=82&28=85&35=89&36=93&37=95&39=98&45=101&46=103&47=108&48=110&49=112&52=115&54=117&57=119&62=121&69=124&70=126&71=130&72=132&74=135&76=137&78=139&80=141&87=145'