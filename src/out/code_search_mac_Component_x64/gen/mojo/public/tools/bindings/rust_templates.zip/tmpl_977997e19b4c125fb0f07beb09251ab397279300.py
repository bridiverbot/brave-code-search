from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'union.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_declare_union = missing
    try:
        t_1 = environment.filters['derivable_traits']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'derivable_traits' found.")
    try:
        t_2 = environment.filters['get_parse_as_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'get_parse_as_type' found.")
    try:
        t_3 = environment.filters['join']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'join' found.")
    try:
        t_4 = environment.filters['to_rust_type']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'to_rust_type' found.")
    pass
    def macro(l_1_name, l_1_union):
        t_5 = []
        l_1_traits = missing
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        pass
        l_1_traits = t_1(l_1_union)
        t_5.append(
            '#[derive(Debug, MojomParse)]',
        )
        if (undefined(name='traits') if l_1_traits is missing else l_1_traits):
            pass
            t_5.extend((
                '\n#[derive(',
                str(t_3(context.eval_ctx, (undefined(name='traits') if l_1_traits is missing else l_1_traits), ', ')),
                ')]',
            ))
        t_5.extend((
            '\npub enum ',
            str(l_1_name),
            ' {',
        ))
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            l_2_parse_as = missing
            _loop_vars = {}
            pass
            l_2_parse_as = t_2(environment.getattr(l_2_field, 'kind'))
            _loop_vars['parse_as'] = l_2_parse_as
            if (undefined(name='parse_as') if l_2_parse_as is missing else l_2_parse_as):
                pass
                t_5.extend((
                    '\n  #[mojom(parse_as = "',
                    str((undefined(name='parse_as') if l_2_parse_as is missing else l_2_parse_as)),
                    '")]',
                ))
            t_5.extend((
                '\n  ',
                str(environment.getattr(l_2_field, 'name')),
                '(',
                str(t_4(environment.getattr(l_2_field, 'kind'))),
                '),',
            ))
        l_2_field = l_2_parse_as = missing
        t_5.append(
            '\n}',
        )
        return concat(t_5)
    context.exported_vars.add('declare_union')
    context.vars['declare_union'] = l_0_declare_union = Macro(environment, macro, 'declare_union', ('name', 'union'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=36&3=44&7=48&8=52&10=57&11=60&12=64&13=66&14=70&16=75'