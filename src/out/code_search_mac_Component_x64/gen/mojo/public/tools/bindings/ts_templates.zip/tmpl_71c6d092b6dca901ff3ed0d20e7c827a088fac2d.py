from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface = resolve('interface')
    l_0_mojom_namespace = resolve('mojom_namespace')
    l_0_generate_return_type = l_0_generate_listener_cb_type = l_0_enum_def = missing
    try:
        t_1 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_2 = environment.filters['sanitize_identifier']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'sanitize_identifier' found.")
    try:
        t_3 = environment.filters['ts_type']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'ts_type' found.")
    try:
        t_4 = environment.filters['ts_type_maybe_nullable']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'ts_type_maybe_nullable' found.")
    pass
    def macro(l_1_method):
        t_5 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            if (t_1(environment.getattr(l_1_method, 'response_parameters')) == 0):
                pass
                t_5.append(
                    'Promise<void>',
                )
            elif (environment.getattr(l_1_method, 'result_response') != None):
                pass
                t_5.extend((
                    'Promise<',
                    str(t_3(environment.getattr(environment.getattr(l_1_method, 'result_response'), 'success_kind'))),
                    '>',
                ))
            else:
                pass
                t_5.append(
                    'Promise<{',
                )
                for l_2_response_parameter in environment.getattr(l_1_method, 'response_parameters'):
                    _loop_vars = {}
                    pass
                    t_5.extend((
                        '\n        ',
                        str(environment.getattr(l_2_response_parameter, 'name')),
                        ': ',
                        str(t_4(environment.getattr(l_2_response_parameter, 'kind'))),
                        ',',
                    ))
                l_2_response_parameter = missing
                t_5.append(
                    ' }>',
                )
        else:
            pass
            t_5.append(
                'void',
            )
        return concat(t_5)
    context.exported_vars.add('generate_return_type')
    context.vars['generate_return_type'] = l_0_generate_return_type = Macro(environment, macro, 'generate_return_type', ('method',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_method):
        t_6 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        t_6.append(
            '\n    (',
        )
        for l_2_param in environment.getattr(l_1_method, 'parameters'):
            _loop_vars = {}
            pass
            t_6.extend((
                str(environment.getattr(l_2_param, 'name')),
                ': ',
                str(t_4(environment.getattr(l_2_param, 'kind'))),
                ',',
            ))
        l_2_param = missing
        t_6.append(
            ') => any',
        )
        return concat(t_6)
    context.exported_vars.add('generate_listener_cb_type')
    context.vars['generate_listener_cb_type'] = l_0_generate_listener_cb_type = Macro(environment, macro, 'generate_listener_cb_type', ('method',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\nexport type '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiverEndpoint =\n  mojo.internal.interfaceSupport.Endpoint<'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>;\n\nexport class '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver implements\n    mojo.internal.interfaceSupport.PendingReceiver<'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '> {\n\n  handle: mojo.internal.interfaceSupport.Endpoint<'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>;\n  constructor(handle: MojoHandle|'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield "PendingReceiverEndpoint) {\n    this.handle = mojo.internal.interfaceSupport.getEndpointForReceiver(handle);\n  }\n\n  bindInBrowser(scope: string = 'context') {\n    mojo.internal.interfaceSupport.bind(\n        this.handle,\n        '"
    yield str((undefined(name='mojom_namespace') if l_0_mojom_namespace is missing else l_0_mojom_namespace))
    yield '.'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield "',\n        scope);\n  }\n}\n\nexport interface "
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Interface {'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        _loop_vars = {}
        pass
        yield '\n  '
        yield str(environment.getattr(l_1_method, 'name'))
        yield '('
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            _loop_vars = {}
            pass
            yield str(t_2(environment.getattr(l_2_param, 'name')))
            yield ': '
            yield str(t_4(environment.getattr(l_2_param, 'kind')))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ', '
        l_2_loop = l_2_param = missing
        yield '): '
        yield str(context.call((undefined(name='generate_return_type') if l_0_generate_return_type is missing else l_0_generate_return_type), l_1_method, _loop_vars=_loop_vars))
        yield ';'
    l_1_loop = l_1_method = missing
    yield '\n}\n\nexport class '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote implements '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Interface,\n    mojo.internal.interfaceSupport.InterfaceRemote<'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver> {\n  private proxy: mojo.internal.interfaceSupport.InterfaceRemoteBase<'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>;\n  $: mojo.internal.interfaceSupport.InterfaceRemoteBaseWrapper<'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>;\n  onConnectionError: mojo.internal.interfaceSupport.ConnectionErrorEventRouter;\n\n  constructor(\n      handle?: MojoHandle|'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiverEndpoint) {\n    this.proxy =\n        new mojo.internal.interfaceSupport.InterfaceRemoteBase(\n          '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver, handle);\n\n    this.$ = new mojo.internal.interfaceSupport.InterfaceRemoteBaseWrapper(this.proxy);\n\n    this.onConnectionError = this.proxy.getConnectionErrorEventRouter();\n  }'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        l_1_interface_message_id = missing
        _loop_vars = {}
        pass
        l_1_interface_message_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        _loop_vars['interface_message_id'] = l_1_interface_message_id
        yield '\n\n  '
        yield str(environment.getattr(l_1_method, 'name'))
        yield '('
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            _loop_vars = {}
            pass
            yield '\n      '
            yield str(environment.getattr(l_2_param, 'name'))
            yield ': '
            yield str(t_4(environment.getattr(l_2_param, 'kind')))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_param = missing
        yield '): '
        yield str(context.call((undefined(name='generate_return_type') if l_0_generate_return_type is missing else l_0_generate_return_type), l_1_method, _loop_vars=_loop_vars))
        yield ' {'
        if ((environment.getattr(l_1_method, 'response_parameters') != None) or (environment.getattr(l_1_method, 'result_response') != None)):
            pass
            yield '\n    return this.proxy.sendMessage('
        else:
            pass
            yield '\n    this.proxy.sendMessage('
        yield '\n        '
        yield str(environment.getattr(l_1_method, 'ordinal'))
        yield ',\n        '
        yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
        yield '_ParamsSpec.$,'
        if ((environment.getattr(l_1_method, 'response_parameters') != None) or (environment.getattr(l_1_method, 'result_response') != None)):
            pass
            yield '\n        '
            yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
            yield '_ResponseParamsSpec.$,'
        else:
            pass
            yield '\n        null,'
        yield '\n        ['
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            _loop_vars = {}
            pass
            yield '\n          '
            yield str(environment.getattr(l_2_param, 'name'))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_param = missing
        yield '\n        ],\n        '
        yield str(('true' if (environment.getattr(l_1_method, 'result_response') != None) else 'false'))
        yield ');\n  }'
    l_1_loop = l_1_method = l_1_interface_message_id = missing
    yield '\n};\n\n/**\n * An object which receives request messages for the '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '\n * mojom interface. Must be constructed over an object which implements that\n * interface.\n */\nexport class '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Receiver implements\n    mojo.internal.interfaceSupport.InterfaceReceiver<\n        '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote, '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver> {\n  private helper_internal_: mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal<\n    '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote, '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>;\n\n  $: mojo.internal.interfaceSupport.InterfaceReceiverHelper<\n    '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote, '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>;\n\n  onConnectionError: mojo.internal.interfaceSupport.ConnectionErrorEventRouter;\n\n'
    if t_1(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods')):
        pass
        yield '\n  constructor(impl: '
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Interface) {\n'
    else:
        pass
        yield '\n  constructor(_impl: '
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Interface) {'
    yield '\n    this.helper_internal_ = new mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal(\n        '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote);\n\n    this.$ = new mojo.internal.interfaceSupport.InterfaceReceiverHelper(this.helper_internal_);\n\n'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_interface_message_id = missing
        _loop_vars = {}
        pass
        l_1_interface_message_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        _loop_vars['interface_message_id'] = l_1_interface_message_id
        yield '\n    this.helper_internal_.registerHandler(\n        '
        yield str(environment.getattr(l_1_method, 'ordinal'))
        yield ',\n        '
        yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
        yield '_ParamsSpec.$,'
        if ((environment.getattr(l_1_method, 'response_parameters') != None) or (environment.getattr(l_1_method, 'result_response') != None)):
            pass
            yield '\n        '
            yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
            yield '_ResponseParamsSpec.$,'
        else:
            pass
            yield '\n        null,'
        yield '\n        impl.'
        yield str(environment.getattr(l_1_method, 'name'))
        yield '.bind(impl),\n        '
        yield str(('true' if (environment.getattr(l_1_method, 'result_response') != None) else 'false'))
        yield ');'
    l_1_method = l_1_interface_message_id = missing
    yield '\n    this.onConnectionError = this.helper_internal_.getConnectionErrorEventRouter();\n  }\n}\n\nexport class '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield ' {\n  static get $interfaceName(): string {\n    return "'
    yield str((undefined(name='mojom_namespace') if l_0_mojom_namespace is missing else l_0_mojom_namespace))
    yield '.'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '";\n  }\n\n  /**\n   * Returns a remote for this interface which sends messages to the browser.\n   * The browser must have an interface request binder registered for this\n   * interface and accessible to the calling document\'s frame.\n   */\n  static getRemote(): '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote {\n    let remote = new '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote;\n    remote.$.bindNewPipeAndPassReceiver().bindInBrowser();\n    return remote;\n  }\n}'
    included_template = environment.get_template('enum_definition.tmpl', 'interface_definition.tmpl').make_module(context.get_all(), True, {'enum_def': l_0_enum_def, 'generate_listener_cb_type': l_0_generate_listener_cb_type, 'generate_return_type': l_0_generate_return_type})
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined(f"the template {included_template.__name__!r} (imported on line 160 in 'interface_definition.tmpl') does not export the requested name 'enum_def'", name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    for l_1_enum in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'enums'):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), l_1_enum, _loop_vars=_loop_vars))
    l_1_enum = missing
    yield '\n\n/**\n * An object which receives request messages for the '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '\n * mojom interface and dispatches them as callbacks. One callback receiver exists\n * on this object for each message defined in the mojom interface, and each\n * receiver can have any number of listeners added to it.\n */\nexport class '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'CallbackRouter implements\n    mojo.internal.interfaceSupport.InterfaceCallbackRouter<\n        '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote, '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver> {\n  private helper_internal_: mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal<\n    '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote, '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>;\n  $: mojo.internal.interfaceSupport.InterfaceReceiverHelper<\n    '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote, '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>;\n  router_: mojo.internal.interfaceSupport.CallbackRouter;\n'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_interface_message_id = missing
        _loop_vars = {}
        pass
        l_1_interface_message_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        _loop_vars['interface_message_id'] = l_1_interface_message_id
        yield '\n  '
        yield str(environment.getattr(l_1_method, 'name'))
        yield ': mojo.internal.interfaceSupport.InterfaceCallbackReceiver<'
        yield str(context.call((undefined(name='generate_listener_cb_type') if l_0_generate_listener_cb_type is missing else l_0_generate_listener_cb_type), l_1_method, _loop_vars=_loop_vars))
        yield '>;'
    l_1_method = l_1_interface_message_id = missing
    yield '\n  onConnectionError: mojo.internal.interfaceSupport.ConnectionErrorEventRouter;\n\n  constructor() {\n    this.helper_internal_ = new mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal(\n      '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote);\n\n    this.$ = new mojo.internal.interfaceSupport.InterfaceReceiverHelper(this.helper_internal_);\n\n    this.router_ = new mojo.internal.interfaceSupport.CallbackRouter;\n'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_interface_message_id = missing
        _loop_vars = {}
        pass
        l_1_interface_message_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        _loop_vars['interface_message_id'] = l_1_interface_message_id
        yield '\n    this.'
        yield str(environment.getattr(l_1_method, 'name'))
        yield ' =\n        new mojo.internal.interfaceSupport.InterfaceCallbackReceiver(\n            this.router_);\n\n    this.helper_internal_.registerHandler(\n        '
        yield str(environment.getattr(l_1_method, 'ordinal'))
        yield ',\n        '
        yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
        yield '_ParamsSpec.$,'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n        '
            yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
            yield '_ResponseParamsSpec.$,\n        this.'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '.createReceiverHandler(true /* expectsResponse */),\n        '
            yield str(('true' if (environment.getattr(l_1_method, 'result_response') != None) else 'false'))
            yield ');'
        else:
            pass
            yield '\n        null,\n        this.'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '.createReceiverHandler(false /* expectsResponse */),\n        false);'
    l_1_method = l_1_interface_message_id = missing
    yield '\n    this.onConnectionError = this.helper_internal_.getConnectionErrorEventRouter();\n  }\n\n  /**\n   * @param id An ID returned by a prior call to addListener.\n   * @return True iff the identified listener was found and removed.\n   */\n  removeListener(id: number): boolean {\n    return this.router_.removeListener(id);\n  }\n}'

blocks = {}
debug_info = '1=38&2=43&3=45&4=50&5=54&7=62&8=67&15=84&17=92&18=96&23=109&24=111&26=113&27=115&29=117&30=119&37=121&42=125&43=128&44=132&45=135&46=138&47=146&51=150&52=154&53=156&54=158&58=160&61=162&68=165&69=169&72=172&73=175&74=179&75=187&76=189&81=196&82=198&83=200&84=203&89=210&90=214&93=220&99=224&103=226&105=228&107=232&110=236&114=240&115=243&117=248&120=251&124=253&125=257&128=260&129=262&130=264&131=267&135=273&136=275&142=279&144=281&152=285&153=287&160=289&161=295&162=299&166=302&171=304&173=306&175=310&177=314&179=318&180=322&182=325&188=331&193=333&194=337&196=340&201=342&202=344&203=346&204=349&205=351&206=353&209=358'