from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'send_validation_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_get_serialize_call = l_0_get_validation_check = missing
    pass
    def macro(l_1_compiler_setting, l_1_type, l_1_args, l_1_declaration):
        t_1 = []
        if l_1_compiler_setting is missing:
            l_1_compiler_setting = undefined("parameter 'compiler_setting' was not provided", name='compiler_setting')
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_args is missing:
            l_1_args = undefined("parameter 'args' was not provided", name='args')
        if l_1_declaration is missing:
            l_1_declaration = 'send_validation'
        pass
        if (l_1_compiler_setting == 'runtime'):
            pass
            t_1.extend((
                '\nmojo::internal::SerializeWithSendValidation<',
                str(l_1_type),
                '>(',
                str(l_1_declaration),
                ',',
            ))
        elif (l_1_compiler_setting == 'template'):
            pass
            t_1.extend((
                '\nmojo::internal::Serialize<',
                str(l_1_type),
                ', ',
                str(l_1_declaration),
                '>(',
            ))
        else:
            pass
            t_1.extend((
                '\nmojo::internal::Serialize<',
                str(l_1_type),
                '>(',
            ))
        l_2_loop = missing
        for l_2_arg, l_2_loop in LoopContext(l_1_args, undefined):
            _loop_vars = {}
            pass
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_1.extend((
                    '\n  ',
                    str(l_2_arg),
                    ',',
                ))
            else:
                pass
                t_1.extend((
                    '\n  ',
                    str(l_2_arg),
                    ');',
                ))
        l_2_loop = l_2_arg = missing
        return concat(t_1)
    context.exported_vars.add('get_serialize_call')
    context.vars['get_serialize_call'] = l_0_get_serialize_call = Macro(environment, macro, 'get_serialize_call', ('compiler_setting', 'type', 'args', 'declaration'), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n'
    def macro(l_1_compiler_setting, l_1_check, l_1_error_code, l_1_description, l_1_declaration):
        t_2 = []
        if l_1_compiler_setting is missing:
            l_1_compiler_setting = undefined("parameter 'compiler_setting' was not provided", name='compiler_setting')
        if l_1_check is missing:
            l_1_check = undefined("parameter 'check' was not provided", name='check')
        if l_1_error_code is missing:
            l_1_error_code = undefined("parameter 'error_code' was not provided", name='error_code')
        if l_1_description is missing:
            l_1_description = undefined("parameter 'description' was not provided", name='description')
        if l_1_declaration is missing:
            l_1_declaration = 'send_validation'
        pass
        if (l_1_compiler_setting == 'runtime'):
            pass
            t_2.extend((
                '\nRUNTIME_MOJO_INTERNAL_CHECK_SERIALIZATION(\n  ',
                str(l_1_declaration),
                ',',
            ))
        elif (l_1_compiler_setting == 'template'):
            pass
            t_2.extend((
                '\nMOJO_INTERNAL_CHECK_SERIALIZATION(\n  ',
                str(l_1_declaration),
                ',',
            ))
        else:
            pass
            t_2.append(
                '\nMOJO_INTERNAL_CHECK_SERIALIZATION(\n  mojo::internal::SendValidation::kDefault,',
            )
        t_2.extend((
            '\n  !(',
            str(l_1_check),
            '),\n  ',
            str(l_1_error_code),
            ',\n  "',
            str(l_1_description),
            '");',
        ))
        return concat(t_2)
    context.exported_vars.add('get_validation_check')
    context.vars['get_validation_check'] = l_0_get_validation_check = Macro(environment, macro, 'get_validation_check', ('compiler_setting', 'check', 'error_code', 'description', 'declaration'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '9=12&10=23&11=27&12=32&13=36&15=45&17=49&18=52&19=56&21=63&35=71&36=84&38=88&39=91&41=95&46=105&47=107&48=109'