from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct_macros = l_0_declare_params = l_0_declare_callback = l_0_declare_result_callback = l_0_result_response_to_expected = l_0_declare_request_params = l_0_trace_event = l_0_declare_sync_method_params = l_0_build_message_flags = l_0_build_serialized_message = missing
    try:
        t_1 = environment.filters['cpp_wrapper_call_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_call_type' found.")
    try:
        t_2 = environment.filters['cpp_wrapper_param_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_param_type' found.")
    try:
        t_3 = environment.filters['cpp_wrapper_type']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_type' found.")
    try:
        t_4 = environment.filters['get_qualified_name_for_feature']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_feature' found.")
    try:
        t_5 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    pass
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'interface_macros.tmpl')._get_default_module(context)
    context.exported_vars.discard('struct_macros')
    def macro(l_1_prefix, l_1_parameters, l_1_allow_non_const_ref):
        t_6 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_parameters is missing:
            l_1_parameters = undefined("parameter 'parameters' was not provided", name='parameters')
        if l_1_allow_non_const_ref is missing:
            l_1_allow_non_const_ref = False
        pass
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(l_1_parameters, undefined):
            _loop_vars = {}
            pass
            t_6.extend((
                str(t_2(environment.getattr(l_2_param, 'kind'), allow_non_const_ref=l_1_allow_non_const_ref)),
                ' ',
                str(l_1_prefix),
                str(environment.getattr(l_2_param, 'name')),
            ))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_6.append(
                    ', ',
                )
        l_2_loop = l_2_param = missing
        return concat(t_6)
    context.exported_vars.add('declare_params')
    context.vars['declare_params'] = l_0_declare_params = Macro(environment, macro, 'declare_params', ('prefix', 'parameters', 'allow_non_const_ref'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_method, l_1_for_blink):
        t_7 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        if l_1_for_blink is missing:
            l_1_for_blink = undefined("parameter 'for_blink' was not provided", name='for_blink')
        pass
        t_7.append(
            'base::OnceCallback<void(',
        )
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'response_parameters'), undefined):
            _loop_vars = {}
            pass
            t_7.append(
                str(t_2(environment.getattr(l_2_param, 'kind'))),
            )
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_7.append(
                    ', ',
                )
        l_2_loop = l_2_param = missing
        t_7.append(
            ')>',
        )
        return concat(t_7)
    context.exported_vars.add('declare_callback')
    context.vars['declare_callback'] = l_0_declare_callback = Macro(environment, macro, 'declare_callback', ('method', 'for_blink'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_method):
        t_8 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        t_8.extend((
            'base::OnceCallback<void(',
            str(context.call((undefined(name='result_response_to_expected') if l_0_result_response_to_expected is missing else l_0_result_response_to_expected), environment.getattr(l_1_method, 'result_response'))),
            ')>',
        ))
        return concat(t_8)
    context.exported_vars.add('declare_result_callback')
    context.vars['declare_result_callback'] = l_0_declare_result_callback = Macro(environment, macro, 'declare_result_callback', ('method',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_result_response):
        t_9 = []
        if l_1_result_response is missing:
            l_1_result_response = undefined("parameter 'result_response' was not provided", name='result_response')
        pass
        t_9.extend((
            'base::expected<\n  ',
            str(t_3(environment.getattr(l_1_result_response, 'success_kind'))),
            ',\n  ',
            str(t_3(environment.getattr(l_1_result_response, 'failure_kind'))),
            '>',
        ))
        return concat(t_9)
    context.exported_vars.add('result_response_to_expected')
    context.vars['result_response_to_expected'] = l_0_result_response_to_expected = Macro(environment, macro, 'result_response_to_expected', ('result_response',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_prefix, l_1_method, l_1_allow_non_const_ref):
        t_10 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        if l_1_allow_non_const_ref is missing:
            l_1_allow_non_const_ref = False
        pass
        t_10.append(
            str(context.call((undefined(name='declare_params') if l_0_declare_params is missing else l_0_declare_params), l_1_prefix, environment.getattr(l_1_method, 'parameters'), allow_non_const_ref=l_1_allow_non_const_ref)),
        )
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            if environment.getattr(l_1_method, 'parameters'):
                pass
                t_10.append(
                    ', ',
                )
            t_10.extend((
                str(environment.getattr(l_1_method, 'name')),
                'Callback callback',
            ))
        return concat(t_10)
    context.exported_vars.add('declare_request_params')
    context.vars['declare_request_params'] = l_0_declare_request_params = Macro(environment, macro, 'declare_request_params', ('prefix', 'method', 'allow_non_const_ref'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_prefix, l_1_method_parameters, l_1_method_name, l_1_parameter_group, l_1_trace_event_type, l_1_dereference_parameters):
        t_11 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_method_parameters is missing:
            l_1_method_parameters = undefined("parameter 'method_parameters' was not provided", name='method_parameters')
        if l_1_method_name is missing:
            l_1_method_name = undefined("parameter 'method_name' was not provided", name='method_name')
        if l_1_parameter_group is missing:
            l_1_parameter_group = undefined("parameter 'parameter_group' was not provided", name='parameter_group')
        if l_1_trace_event_type is missing:
            l_1_trace_event_type = ''
        if l_1_dereference_parameters is missing:
            l_1_dereference_parameters = False
        pass
        if l_1_method_parameters:
            pass
            t_11.extend((
                'TRACE_EVENT',
                str(l_1_trace_event_type),
                '1(\n    "mojom", "',
                str(l_1_method_name),
                '", "',
                str(l_1_parameter_group),
                '",\n    [&](perfetto::TracedValue context){\n      auto dict = std::move(context).WriteDictionary();',
            ))
            for l_2_param in l_1_method_parameters:
                _loop_vars = {}
                pass
                t_11.extend((
                    '\n      perfetto::WriteIntoTracedValueWithFallback(\n           dict.AddItem("',
                    str(environment.getattr(l_2_param, 'name')),
                    '"), ',
                    str((l_1_prefix + environment.getattr(l_2_param, 'name'))),
                    ',\n                        "<value of type ',
                    str(t_2(environment.getattr(l_2_param, 'kind'))),
                    '>");',
                ))
            l_2_param = missing
            t_11.append(
                '\n   });',
            )
        else:
            pass
            t_11.extend((
                'TRACE_EVENT',
                str(l_1_trace_event_type),
                '0("mojom", "',
                str(l_1_method_name),
                '");',
            ))
        return concat(t_11)
    context.exported_vars.add('trace_event')
    context.vars['trace_event'] = l_0_trace_event = Macro(environment, macro, 'trace_event', ('prefix', 'method_parameters', 'method_name', 'parameter_group', 'trace_event_type', 'dereference_parameters'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_prefix, l_1_method):
        t_12 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        t_12.append(
            str(context.call((undefined(name='declare_params') if l_0_declare_params is missing else l_0_declare_params), l_1_prefix, environment.getattr(l_1_method, 'parameters'))),
        )
        if (environment.getattr(l_1_method, 'result_response') != None):
            pass
            if environment.getattr(l_1_method, 'parameters'):
                pass
                t_12.append(
                    ',',
                )
            t_12.extend((
                '\n',
                str(context.call((undefined(name='result_response_to_expected') if l_0_result_response_to_expected is missing else l_0_result_response_to_expected), environment.getattr(l_1_method, 'result_response'))),
                '* out_',
                str(l_1_prefix),
                str(environment.getattr(environment.getitem(environment.getattr(l_1_method, 'response_parameters'), 0), 'name')),
            ))
        else:
            pass
            if environment.getattr(l_1_method, 'response_parameters'):
                pass
                if environment.getattr(l_1_method, 'parameters'):
                    pass
                    t_12.append(
                        ', ',
                    )
                l_2_loop = missing
                for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'response_parameters'), undefined):
                    _loop_vars = {}
                    pass
                    t_12.extend((
                        str(t_1(environment.getattr(l_2_param, 'kind'))),
                        '* out_',
                        str(l_1_prefix),
                        str(environment.getattr(l_2_param, 'name')),
                    ))
                    if (not environment.getattr(l_2_loop, 'last')):
                        pass
                        t_12.append(
                            ', ',
                        )
                l_2_loop = l_2_param = missing
        return concat(t_12)
    context.exported_vars.add('declare_sync_method_params')
    context.vars['declare_sync_method_params'] = l_0_declare_sync_method_params = Macro(environment, macro, 'declare_sync_method_params', ('prefix', 'method'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_is_response, l_1_is_sync_text, l_1_allow_interrupt_text, l_1_is_urgent_text, l_1_expects_response_text, l_1_flags_name):
        t_13 = []
        if l_1_is_response is missing:
            l_1_is_response = undefined("parameter 'is_response' was not provided", name='is_response')
        if l_1_is_sync_text is missing:
            l_1_is_sync_text = undefined("parameter 'is_sync_text' was not provided", name='is_sync_text')
        if l_1_allow_interrupt_text is missing:
            l_1_allow_interrupt_text = undefined("parameter 'allow_interrupt_text' was not provided", name='allow_interrupt_text')
        if l_1_is_urgent_text is missing:
            l_1_is_urgent_text = undefined("parameter 'is_urgent_text' was not provided", name='is_urgent_text')
        if l_1_expects_response_text is missing:
            l_1_expects_response_text = undefined("parameter 'expects_response_text' was not provided", name='expects_response_text')
        if l_1_flags_name is missing:
            l_1_flags_name = undefined("parameter 'flags_name' was not provided", name='flags_name')
        pass
        if l_1_is_response:
            pass
            t_13.extend((
                '\n  const uint32_t kFlags = mojo::Message::kFlagIsResponse |\n      ((',
                str(l_1_is_sync_text),
                ') ? mojo::Message::kFlagIsSync : 0) |\n      ((',
                str(l_1_allow_interrupt_text),
                ') ? 0 : mojo::Message::kFlagNoInterrupt) |\n      ((',
                str(l_1_is_urgent_text),
                ') ? mojo::Message::kFlagIsUrgent : 0);',
            ))
        else:
            pass
            t_13.extend((
                '\n  const uint32_t kFlags =\n      ((',
                str(l_1_expects_response_text),
                ') ? mojo::Message::kFlagExpectsResponse : 0) |\n      ((',
                str(l_1_is_sync_text),
                ') ? mojo::Message::kFlagIsSync : 0) |\n      ((',
                str(l_1_allow_interrupt_text),
                ') ? 0 : mojo::Message::kFlagNoInterrupt) |\n      ((',
                str(l_1_is_urgent_text),
                ') ? mojo::Message::kFlagIsUrgent : 0);',
            ))
        return concat(t_13)
    context.exported_vars.add('build_message_flags')
    context.vars['build_message_flags'] = l_0_build_message_flags = Macro(environment, macro, 'build_message_flags', ('is_response', 'is_sync_text', 'allow_interrupt_text', 'is_urgent_text', 'expects_response_text', 'flags_name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_message_name, l_1_method, l_1_param_name_prefix, l_1_params_struct, l_1_params_description, l_1_flags_text, l_1_message_object_name, l_1_send_validation, l_1_has_size_estimator):
        t_14 = []
        l_1_feature_cpp = resolve('feature_cpp')
        l_1_send_validation_compiler_setting = missing
        if l_1_message_name is missing:
            l_1_message_name = undefined("parameter 'message_name' was not provided", name='message_name')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        if l_1_param_name_prefix is missing:
            l_1_param_name_prefix = undefined("parameter 'param_name_prefix' was not provided", name='param_name_prefix')
        if l_1_params_struct is missing:
            l_1_params_struct = undefined("parameter 'params_struct' was not provided", name='params_struct')
        if l_1_params_description is missing:
            l_1_params_description = undefined("parameter 'params_description' was not provided", name='params_description')
        if l_1_flags_text is missing:
            l_1_flags_text = undefined("parameter 'flags_text' was not provided", name='flags_text')
        if l_1_message_object_name is missing:
            l_1_message_object_name = undefined("parameter 'message_object_name' was not provided", name='message_object_name')
        if l_1_send_validation is missing:
            l_1_send_validation = undefined("parameter 'send_validation' was not provided", name='send_validation')
        if l_1_has_size_estimator is missing:
            l_1_has_size_estimator = False
        pass
        t_14.append(
            '\n  const size_t estimated_payload_size =',
        )
        if (l_1_has_size_estimator and environment.getattr(l_1_method, 'estimate_message_size')):
            pass
            t_14.extend((
                '\n    size_estimator_.EstimatePayloadSize(',
                str(l_1_message_name),
                ');',
            ))
        else:
            pass
            t_14.append(
                '\n    0;',
            )
        if environment.getattr(l_1_method, 'unlimited_message_size'):
            pass
            t_14.extend((
                '\n  mojo::Message ',
                str(l_1_message_object_name),
                '(\n      ',
                str(l_1_message_name),
                ', ',
                str(l_1_flags_text),
                ',\n      MOJO_CREATE_MESSAGE_FLAG_UNLIMITED_SIZE,\n      estimated_payload_size);',
            ))
        else:
            pass
            t_14.extend((
                '\n  mojo::Message ',
                str(l_1_message_object_name),
                '(\n      ',
                str(l_1_message_name),
                ', ',
                str(l_1_flags_text),
                ', estimated_payload_size);',
            ))
        t_14.extend((
            '\n  mojo::internal::MessageFragment<\n      ',
            str(t_5(l_1_params_struct, internal=True)),
            '> params(\n          ',
            str(l_1_message_object_name),
            ');',
        ))
        l_1_send_validation_compiler_setting = ('runtime' if l_1_send_validation else 'default')
        if l_1_send_validation:
            pass
            l_1_feature_cpp = t_4(environment.getattr(l_1_method, 'send_validation'))
            t_14.extend((
                '\n  mojo::internal::SendValidation send_validation =\n      (base::FeatureList::IsEnabled(',
                str((undefined(name='feature_cpp') if l_1_feature_cpp is missing else l_1_feature_cpp)),
                ')) ?\n        mojo::internal::SendValidation::kFatal :\n        mojo::internal::SendValidation::kWarning;',
            ))
        t_14.extend((
            '\n  ',
            str(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'serialize'), l_1_params_struct, l_1_params_description, l_1_param_name_prefix, 'params', (undefined(name='send_validation_compiler_setting') if l_1_send_validation_compiler_setting is missing else l_1_send_validation_compiler_setting))),
        ))
        return concat(t_14)
    context.exported_vars.add('build_serialized_message')
    context.vars['build_serialized_message'] = l_0_build_serialized_message = Macro(environment, macro, 'build_serialized_message', ('message_name', 'method', 'param_name_prefix', 'params_struct', 'params_description', 'flags_text', 'message_object_name', 'send_validation', 'has_size_estimator'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=42&3=44&4=54&5=58&6=63&10=72&12=83&13=87&14=89&19=101&20=108&23=114&25=121&26=123&29=129&30=139&31=141&32=143&33=149&37=155&51=170&52=174&53=176&56=181&58=186&59=190&63=201&67=209&68=217&69=219&70=221&71=228&73=235&74=237&75=243&76=247&77=252&83=261&85=276&87=280&88=282&89=284&92=291&93=293&94=295&95=297&99=303&105=329&106=333&111=341&112=345&113=347&117=356&118=358&121=365&122=367&123=370&125=371&126=373&128=376&132=381'