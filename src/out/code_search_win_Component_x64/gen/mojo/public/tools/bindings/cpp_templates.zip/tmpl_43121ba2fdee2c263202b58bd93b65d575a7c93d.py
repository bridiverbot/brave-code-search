from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module-shared.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_imports = resolve('imports')
    l_0_disallow_interfaces = resolve('disallow_interfaces')
    l_0_uses_interfaces = resolve('uses_interfaces')
    l_0_disallow_native_types = resolve('disallow_native_types')
    l_0_uses_native_types = resolve('uses_native_types')
    l_0_send_validation_modules = resolve('send_validation_modules')
    l_0_export_header = resolve('export_header')
    l_0_enable_kythe_annotations = resolve('enable_kythe_annotations')
    l_0_all_enums = resolve('all_enums')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_namespace_begin = l_0_namespace_end = l_0_include_guard = l_0_header_guard = l_0_enum_hash = l_0_enum_trace_format_traits_decl = missing
    try:
        t_1 = environment.filters['is_native_only_kind']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'is_native_only_kind' found.")
    try:
        t_2 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    pass
    yield '// Copyright 2016 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    included_template = environment.get_template('cpp_macros.tmpl', 'module-shared.h.tmpl')._get_default_module(context)
    l_0_namespace_begin = getattr(included_template, 'namespace_begin', missing)
    if l_0_namespace_begin is missing:
        l_0_namespace_begin = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-shared.h.tmpl') does not export the requested name 'namespace_begin'", name='namespace_begin')
    l_0_namespace_end = getattr(included_template, 'namespace_end', missing)
    if l_0_namespace_end is missing:
        l_0_namespace_end = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-shared.h.tmpl') does not export the requested name 'namespace_end'", name='namespace_end')
    l_0_include_guard = getattr(included_template, 'include_guard', missing)
    if l_0_include_guard is missing:
        l_0_include_guard = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-shared.h.tmpl') does not export the requested name 'include_guard'", name='include_guard')
    context.vars.update({'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'include_guard': l_0_include_guard})
    context.exported_vars.difference_update(('namespace_begin', 'namespace_end', 'include_guard'))
    l_0_header_guard = context.call((undefined(name='include_guard') if l_0_include_guard is missing else l_0_include_guard), 'SHARED', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    yield '\n\n#ifndef '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n#include <stdint.h>\n\n#include <functional>\n#include <iosfwd>\n#include <type_traits>\n#include <utility>'
    if (t_2((undefined(name='structs') if l_0_structs is missing else l_0_structs)) or t_2((undefined(name='unions') if l_0_unions is missing else l_0_unions))):
        pass
        yield '\n#include "mojo/public/cpp/bindings/array_data_view.h"\n#include "mojo/public/cpp/bindings/map_data_view.h"\n#include "mojo/public/cpp/bindings/string_data_view.h"\n#include "mojo/public/cpp/system/message_pipe.h"'
    yield '\n\n#include "third_party/perfetto/include/perfetto/tracing/traced_value_forward.h"\n\n#include "'
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-shared-internal.h"'
    for l_1_import in (undefined(name='imports') if l_0_imports is missing else l_0_imports):
        _loop_vars = {}
        pass
        yield '\n#include "'
        yield str(environment.getattr(l_1_import, 'path'))
        yield '-shared.h"'
    l_1_import = missing
    yield '\n'
    if ((not (undefined(name='disallow_interfaces') if l_0_disallow_interfaces is missing else l_0_disallow_interfaces)) and (undefined(name='uses_interfaces') if l_0_uses_interfaces is missing else l_0_uses_interfaces)):
        pass
        yield '#include "mojo/public/cpp/bindings/lib/interface_serialization.h"\n#include "mojo/public/cpp/system/data_pipe.h"'
    yield '\n\n'
    if ((not (undefined(name='disallow_native_types') if l_0_disallow_native_types is missing else l_0_disallow_native_types)) and (undefined(name='uses_native_types') if l_0_uses_native_types is missing else l_0_uses_native_types)):
        pass
        yield '\n#include "mojo/public/cpp/bindings/native_enum.h"\n#include "mojo/public/cpp/bindings/lib/native_struct_serialization.h"'
    yield '\n\n#include "'
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-data-view.h"  // IWYU pragma: export'
    for l_1_send_validation_module in (undefined(name='send_validation_modules') if l_0_send_validation_modules is missing else l_0_send_validation_modules):
        _loop_vars = {}
        pass
        yield '\n#include "'
        yield str(environment.getattr(l_1_send_validation_module, 'path'))
        yield '-send-validation.h"'
    l_1_send_validation_module = missing
    if (undefined(name='export_header') if l_0_export_header is missing else l_0_export_header):
        pass
        yield '\n#include "'
        yield str((undefined(name='export_header') if l_0_export_header is missing else l_0_export_header))
        yield '"'
    yield '\n\n'
    if (undefined(name='enable_kythe_annotations') if l_0_enable_kythe_annotations is missing else l_0_enable_kythe_annotations):
        pass
        yield '#ifdef KYTHE_IS_RUNNING\n#pragma kythe_inline_metadata "Metadata comment"\n#endif'
    yield '\n\n\nnamespace std {'
    included_template = environment.get_template('enum_macros.tmpl', 'module-shared.h.tmpl')._get_default_module(context)
    l_0_enum_hash = getattr(included_template, 'enum_hash', missing)
    if l_0_enum_hash is missing:
        l_0_enum_hash = undefined(f"the template {included_template.__name__!r} (imported on line 65 in 'module-shared.h.tmpl') does not export the requested name 'enum_hash'", name='enum_hash')
    context.vars['enum_hash'] = l_0_enum_hash
    context.exported_vars.discard('enum_hash')
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        _loop_vars = {}
        pass
        if (not t_1(l_1_enum)):
            pass
            yield '\n'
            yield str(context.call((undefined(name='enum_hash') if l_0_enum_hash is missing else l_0_enum_hash), l_1_enum, _loop_vars=_loop_vars))
    l_1_enum = missing
    yield '\n\n}  // namespace std\n\nnamespace mojo {'
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        _loop_vars = {}
        pass
        if (not t_1(l_1_enum)):
            pass
            yield '\n'
            template = environment.get_template('enum_serialization_declaration.tmpl', 'module-shared.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum': l_1_enum, 'enum_hash': l_0_enum_hash, 'enum_trace_format_traits_decl': l_0_enum_trace_format_traits_decl, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
                yield event
    l_1_enum = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        if (not t_1(l_1_struct)):
            pass
            yield '\n'
            template = environment.get_template('struct_serialization_declaration.tmpl', 'module-shared.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'enum_hash': l_0_enum_hash, 'enum_trace_format_traits_decl': l_0_enum_trace_format_traits_decl, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
                yield event
    l_1_struct = missing
    if (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
            _loop_vars = {}
            pass
            yield '\n'
            template = environment.get_template('union_serialization_declaration.tmpl', 'module-shared.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'union': l_1_union, 'enum_hash': l_0_enum_hash, 'enum_trace_format_traits_decl': l_0_enum_trace_format_traits_decl, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
                yield event
        l_1_union = missing
    yield '\n\n}  // namespace mojo\n\n'
    yield str(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        if (not t_1(l_1_struct)):
            pass
            yield '\n'
            template = environment.get_template('struct_data_view_definition.tmpl', 'module-shared.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'enum_hash': l_0_enum_hash, 'enum_trace_format_traits_decl': l_0_enum_trace_format_traits_decl, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
                yield event
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('union_data_view_definition.tmpl', 'module-shared.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'union': l_1_union, 'enum_hash': l_0_enum_hash, 'enum_trace_format_traits_decl': l_0_enum_trace_format_traits_decl, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
            yield event
    l_1_union = missing
    yield '\n\n'
    yield str(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
    yield '\n\n// Declare TraceFormatTraits for enums, which should be defined in ::perfetto\n// namespace.'
    included_template = environment.get_template('enum_macros.tmpl', 'module-shared.h.tmpl').make_module(context.get_all(), True, {'enum_hash': l_0_enum_hash, 'enum_trace_format_traits_decl': l_0_enum_trace_format_traits_decl, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})
    l_0_enum_trace_format_traits_decl = getattr(included_template, 'enum_trace_format_traits_decl', missing)
    if l_0_enum_trace_format_traits_decl is missing:
        l_0_enum_trace_format_traits_decl = undefined(f"the template {included_template.__name__!r} (imported on line 115 in 'module-shared.h.tmpl') does not export the requested name 'enum_trace_format_traits_decl'", name='enum_trace_format_traits_decl')
    context.vars['enum_trace_format_traits_decl'] = l_0_enum_trace_format_traits_decl
    context.exported_vars.discard('enum_trace_format_traits_decl')
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        l_1_export_attribute = resolve('export_attribute')
        _loop_vars = {}
        pass
        if (not t_1(l_1_enum)):
            pass
            yield '\n'
            yield str(context.call((undefined(name='enum_trace_format_traits_decl') if l_0_enum_trace_format_traits_decl is missing else l_0_enum_trace_format_traits_decl), l_1_enum, (undefined(name='export_attribute') if l_1_export_attribute is missing else l_1_export_attribute), _loop_vars=_loop_vars))
    l_1_enum = l_1_export_attribute = missing
    yield '\n\n#endif  // '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=38&8=50&10=54&11=56&20=58&29=62&30=64&31=68&35=72&40=76&45=80&48=82&49=86&52=89&53=92&56=95&65=99&66=105&67=108&68=111&77=114&78=117&79=120&84=124&85=127&86=130&91=134&92=136&93=140&99=145&101=146&102=149&103=152&107=156&108=160&111=165&115=167&116=173&117=177&118=180&122=183'