from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'enum.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_declare_enum = missing
    try:
        t_1 = environment.filters['get_canonical_enum_fields']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'get_canonical_enum_fields' found.")
    try:
        t_2 = environment.filters['get_duplicate_enum_fields']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'get_duplicate_enum_fields' found.")
    pass
    def macro(l_1_name, l_1_enum):
        t_3 = []
        l_1_duplicates = missing
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        t_3.extend((
            '#[derive(Debug, PartialEq, Clone, PrimitiveEnum, Hash, Eq, PartialOrd, Ord)]\npub enum ',
            str(l_1_name),
            ' {',
        ))
        for l_2_field in t_1(l_1_enum):
            _loop_vars = {}
            pass
            t_3.extend((
                '\n  ',
                str(environment.getattr(l_2_field, 'name')),
                ' = ',
                str(environment.getattr(l_2_field, 'numeric_value')),
                ',',
            ))
        l_2_field = missing
        t_3.append(
            '\n}',
        )
        l_1_duplicates = t_2(l_1_enum)
        if (undefined(name='duplicates') if l_1_duplicates is missing else l_1_duplicates):
            pass
            t_3.extend((
                '\n\nimpl ',
                str(l_1_name),
                ' {',
            ))
            for l_2_dup in (undefined(name='duplicates') if l_1_duplicates is missing else l_1_duplicates):
                _loop_vars = {}
                pass
                t_3.extend((
                    '\n  pub const ',
                    str(environment.getattr(l_2_dup, 'name')),
                    ': Self = Self::',
                    str(environment.getattr(l_2_dup, 'canonical_name')),
                    ';',
                ))
            l_2_dup = missing
            t_3.append(
                '\n}',
            )
        return concat(t_3)
    context.exported_vars.add('declare_enum')
    context.vars['declare_enum'] = l_0_declare_enum = Macro(environment, macro, 'declare_enum', ('name', 'enum'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=24&5=34&6=37&7=42&10=51&11=52&13=56&14=59&15=64'