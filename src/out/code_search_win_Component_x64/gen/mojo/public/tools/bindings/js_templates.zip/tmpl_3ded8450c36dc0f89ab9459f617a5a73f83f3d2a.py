from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module.amd.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_imports = resolve('imports')
    try:
        t_1 = environment.filters['get_relative_url']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'get_relative_url' found.")
    pass
    yield "// Copyright 2014 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.\n\n'use strict';\n\n(function() {\n  var mojomId = '"
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield "';\n  if (mojo.internal.isMojomLoaded(mojomId)) {\n    console.warn('The following mojom is loaded multiple times: ' + mojomId);\n    return;\n  }\n  mojo.internal.markMojomLoaded(mojomId);\n  var bindings = mojo;\n  var associatedBindings = mojo;\n  var codec = mojo.internal;\n  var validator = mojo.internal;\n\n  var exports = mojo.internal.exposeNamespace('"
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield "');"
    for l_1_import in (undefined(name='imports') if l_0_imports is missing else l_0_imports):
        _loop_vars = {}
        pass
        yield '\n  var '
        yield str(environment.getattr(l_1_import, 'unique_name'))
        yield " =\n      mojo.internal.exposeNamespace('"
        yield str(environment.getattr(l_1_import, 'namespace'))
        yield "');\n  if (mojo.config.autoLoadMojomDeps) {\n    mojo.internal.loadMojomIfNecessary(\n        '"
        yield str(environment.getattr(l_1_import, 'path'))
        yield "', '"
        yield str(t_1(l_1_import, (undefined(name='module') if l_0_module is missing else l_0_module)))
        yield ".js');\n  }"
    l_1_import = missing
    yield '\n\n'
    template = environment.get_template('module_definition.tmpl', 'module.amd.tmpl')
    for event in template.root_render_func(template.new_context(context.get_all(), True, {})):
        yield event
    yield '\n})();'

blocks = {}
debug_info = '8=20&22=22&24=24&25=28&26=30&29=32&33=38'