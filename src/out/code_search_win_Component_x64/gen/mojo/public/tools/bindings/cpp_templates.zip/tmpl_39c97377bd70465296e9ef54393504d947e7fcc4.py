from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module-forward.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_variant = resolve('variant')
    l_0_all_enums = resolve('all_enums')
    l_0_uses_stdint_types = resolve('uses_stdint_types')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_disallow_interfaces = resolve('disallow_interfaces')
    l_0_interfaces = resolve('interfaces')
    l_0_disallow_native_types = resolve('disallow_native_types')
    l_0_export_header = resolve('export_header')
    l_0_enable_kythe_annotations = resolve('enable_kythe_annotations')
    l_0_uses_native_types = resolve('uses_native_types')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_enum_forward = resolve('enum_forward')
    l_0_enum = resolve('enum')
    l_0_enums = resolve('enums')
    l_0_include_guard = l_0_namespace_begin = l_0_namespace_end = l_0_header_guard = l_0_kythe_annotation = l_0_module_prefix = missing
    try:
        t_1 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_2 = environment.filters['format_constant_declaration']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'format_constant_declaration' found.")
    try:
        t_3 = environment.filters['get_name_for_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'get_name_for_kind' found.")
    try:
        t_4 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_5 = environment.filters['is_native_only_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_native_only_kind' found.")
    try:
        t_6 = environment.filters['join']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'join' found.")
    try:
        t_7 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_8 = environment.filters['should_inline']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'should_inline' found.")
    try:
        t_9 = environment.filters['should_inline_union']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'should_inline_union' found.")
    pass
    yield '// Copyright 2019 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    included_template = environment.get_template('cpp_macros.tmpl', 'module-forward.h.tmpl')._get_default_module(context)
    l_0_include_guard = getattr(included_template, 'include_guard', missing)
    if l_0_include_guard is missing:
        l_0_include_guard = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-forward.h.tmpl') does not export the requested name 'include_guard'", name='include_guard')
    l_0_namespace_begin = getattr(included_template, 'namespace_begin', missing)
    if l_0_namespace_begin is missing:
        l_0_namespace_begin = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-forward.h.tmpl') does not export the requested name 'namespace_begin'", name='namespace_begin')
    l_0_namespace_end = getattr(included_template, 'namespace_end', missing)
    if l_0_namespace_end is missing:
        l_0_namespace_end = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-forward.h.tmpl') does not export the requested name 'namespace_end'", name='namespace_end')
    context.vars.update({'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})
    context.exported_vars.difference_update(('include_guard', 'namespace_begin', 'namespace_end'))
    l_0_header_guard = context.call((undefined(name='include_guard') if l_0_include_guard is missing else l_0_include_guard), 'FORWARD', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    def macro(l_1_name):
        t_10 = []
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (undefined(name='enable_kythe_annotations') if l_0_enable_kythe_annotations is missing else l_0_enable_kythe_annotations):
            pass
            t_10.extend((
                '\n// @generated_from: ',
                str(l_1_name),
            ))
        return concat(t_10)
    context.exported_vars.add('kythe_annotation')
    context.vars['kythe_annotation'] = l_0_kythe_annotation = Macro(environment, macro, 'kythe_annotation', ('name',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n#ifndef '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n'
    if (t_7((undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums)) or (undefined(name='uses_stdint_types') if l_0_uses_stdint_types is missing else l_0_uses_stdint_types)):
        pass
        yield '#include <stdint.h>'
    yield '\n\n'
    if (t_7((undefined(name='structs') if l_0_structs is missing else l_0_structs)) or t_7((undefined(name='unions') if l_0_unions is missing else l_0_unions))):
        pass
        yield '#include "mojo/public/cpp/bindings/struct_forward.h"'
    yield '\n\n'
    if ((not (undefined(name='disallow_interfaces') if l_0_disallow_interfaces is missing else l_0_disallow_interfaces)) and t_7((undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces))):
        pass
        yield '#include "mojo/public/cpp/bindings/deprecated_interface_types_forward.h"'
    yield '\n\n'
    if ((not (undefined(name='disallow_native_types') if l_0_disallow_native_types is missing else l_0_disallow_native_types)) and t_7((undefined(name='structs') if l_0_structs is missing else l_0_structs))):
        pass
        yield '\n#include "mojo/public/interfaces/bindings/native_struct.mojom-forward.h"'
    if ((undefined(name='export_header') if l_0_export_header is missing else l_0_export_header) and t_7(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'constants'))):
        pass
        yield '\n#include "'
        yield str((undefined(name='export_header') if l_0_export_header is missing else l_0_export_header))
        yield '"'
    yield '\n\n'
    if (undefined(name='enable_kythe_annotations') if l_0_enable_kythe_annotations is missing else l_0_enable_kythe_annotations):
        pass
        yield '#ifdef KYTHE_IS_RUNNING\n#pragma kythe_inline_metadata "Metadata comment"\n#endif'
    yield '\n\n'
    if (((not (undefined(name='disallow_native_types') if l_0_disallow_native_types is missing else l_0_disallow_native_types)) and (undefined(name='uses_native_types') if l_0_uses_native_types is missing else l_0_uses_native_types)) and t_7((undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums))):
        pass
        yield 'namespace mojo {\nenum class NativeEnum;\n}  // namespace mojo'
    if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
        pass
        yield '\n'
        yield str(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
        included_template = environment.get_template('enum_macros.tmpl', 'module-forward.h.tmpl')._get_default_module(context)
        l_0_enum_forward = getattr(included_template, 'enum_forward', missing)
        if l_0_enum_forward is missing:
            l_0_enum_forward = undefined(f"the template {included_template.__name__!r} (imported on line 54 in 'module-forward.h.tmpl') does not export the requested name 'enum_forward'", name='enum_forward')
        context.vars['enum_forward'] = l_0_enum_forward
        context.exported_vars.discard('enum_forward')
        for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
            _loop_vars = {}
            pass
            if t_5(l_1_enum):
                pass
                yield '\nusing '
                yield str(t_3(l_1_enum, flatten_nested_kind=True))
                yield ' = mojo::NativeEnum;'
            else:
                pass
                yield '\n'
                yield str(context.call((undefined(name='enum_forward') if l_0_enum_forward is missing else l_0_enum_forward), l_1_enum, _loop_vars=_loop_vars))
        l_1_enum = missing
        for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
            _loop_vars = {}
            pass
            yield '\nclass '
            yield str(environment.getattr(l_1_interface, 'name'))
            yield 'InterfaceBase;'
        l_1_interface = missing
        yield '\n\n'
        yield str(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
    yield '\n\n'
    yield str(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
    l_0_module_prefix = t_1('%s', t_6(context.eval_ctx, (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), '.'))
    context.vars['module_prefix'] = l_0_module_prefix
    context.exported_vars.add('module_prefix')
    if (not (undefined(name='variant') if l_0_variant is missing else l_0_variant)):
        pass
        for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
            _loop_vars = {}
            pass
            if t_5(l_1_struct):
                pass
                yield '\nusing '
                yield str(environment.getattr(l_1_struct, 'name'))
                yield 'DataView = mojo::native::NativeStructDataView;'
            else:
                pass
                yield '\nclass '
                yield str(environment.getattr(l_1_struct, 'name'))
                yield 'DataView;'
            yield '\n'
        l_1_struct = missing
        for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
            _loop_vars = {}
            pass
            yield '\nclass '
            yield str(environment.getattr(l_1_union, 'name'))
            yield 'DataView;'
        l_1_union = missing
        included_template = environment.get_template('enum_macros.tmpl', 'module-forward.h.tmpl')._get_default_module(context)
        l_0_enum_forward = getattr(included_template, 'enum_forward', missing)
        if l_0_enum_forward is missing:
            l_0_enum_forward = undefined(f"the template {included_template.__name__!r} (imported on line 92 in 'module-forward.h.tmpl') does not export the requested name 'enum_forward'", name='enum_forward')
        context.vars['enum_forward'] = l_0_enum_forward
        context.exported_vars.discard('enum_forward')
        for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
            _loop_vars = {}
            pass
            if t_5(l_1_enum):
                pass
                yield '\nusing '
                yield str(t_3(l_1_enum, flatten_nested_kind=True))
                yield ' = mojo::NativeEnum;'
            else:
                pass
                yield '\n'
                yield str(context.call((undefined(name='enum_forward') if l_0_enum_forward is missing else l_0_enum_forward), l_1_enum, _loop_vars=_loop_vars))
        l_1_enum = missing
    if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
        pass
        if ((undefined(name='enum') if l_0_enum is missing else l_0_enum) or (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces)):
            pass
            yield '\n// Aliases for definition in the parent namespace.'
        for l_1_enum in (undefined(name='enums') if l_0_enums is missing else l_0_enums):
            _loop_vars = {}
            pass
            yield '\nusing '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield ' = '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield ';'
        l_1_enum = missing
        for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
            _loop_vars = {}
            pass
            yield '\nusing '
            yield str(environment.getattr(l_1_interface, 'name'))
            yield 'InterfaceBase = '
            yield str(environment.getattr(l_1_interface, 'name'))
            yield 'InterfaceBase;'
        l_1_interface = missing
    for l_1_constant in environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'constants'):
        _loop_vars = {}
        pass
        if (not t_4(environment.getattr(l_1_constant, 'kind'))):
            pass
            yield '\n'
            yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_1('%s.%s', (undefined(name='module_prefix') if l_0_module_prefix is missing else l_0_module_prefix), environment.getattr(l_1_constant, 'name')), _loop_vars=_loop_vars))
            yield '\n'
            yield str(t_2(l_1_constant))
            yield ';'
    l_1_constant = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        if t_5(l_1_struct):
            pass
            yield '\nusing '
            yield str(environment.getattr(l_1_struct, 'name'))
            yield ' = mojo::native::NativeStruct;\nusing '
            yield str(environment.getattr(l_1_struct, 'name'))
            yield 'Ptr = mojo::native::NativeStructPtr;'
        else:
            pass
            yield '\nclass '
            yield str(environment.getattr(l_1_struct, 'name'))
            yield ';'
            if t_8(l_1_struct):
                pass
                yield '\nusing '
                yield str(environment.getattr(l_1_struct, 'name'))
                yield 'Ptr = mojo::InlinedStructPtr<'
                yield str(environment.getattr(l_1_struct, 'name'))
                yield '>;'
            else:
                pass
                yield '\nusing '
                yield str(environment.getattr(l_1_struct, 'name'))
                yield 'Ptr = mojo::StructPtr<'
                yield str(environment.getattr(l_1_struct, 'name'))
                yield '>;'
        yield '\n'
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        yield '\nclass '
        yield str(environment.getattr(l_1_union, 'name'))
        yield ';\n'
        if t_9(l_1_union):
            pass
            yield '\nusing '
            yield str(environment.getattr(l_1_union, 'name'))
            yield 'Ptr = mojo::InlinedStructPtr<'
            yield str(environment.getattr(l_1_union, 'name'))
            yield '>;\n'
        else:
            pass
            yield '\nusing '
            yield str(environment.getattr(l_1_union, 'name'))
            yield 'Ptr = mojo::StructPtr<'
            yield str(environment.getattr(l_1_union, 'name'))
            yield '>;\n'
    l_1_union = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        yield '\nclass '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield ';\n'
    l_1_interface = missing
    yield '\n\n\n'
    yield str(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
    yield '\n\n#endif  // '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=83&8=95&10=98&11=103&12=107&16=113&17=115&19=117&23=121&27=125&31=129&35=132&36=135&39=138&45=142&51=145&52=148&54=149&55=155&56=158&57=161&59=166&63=168&64=172&67=176&70=178&72=179&75=182&78=184&79=187&80=190&82=195&87=199&88=203&92=206&93=212&94=215&95=218&97=223&104=225&105=227&108=230&109=234&111=239&112=243&117=248&118=251&119=254&120=256&125=259&126=262&127=265&128=267&130=272&131=274&132=277&134=284&140=290&141=294&142=296&143=299&145=306&151=311&152=315&156=319&160=321'