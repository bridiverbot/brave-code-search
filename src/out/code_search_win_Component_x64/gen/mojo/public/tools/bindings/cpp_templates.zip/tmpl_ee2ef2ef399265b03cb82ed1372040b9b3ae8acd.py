from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'union_serialization_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    l_0_union_macros = l_0_data_view = l_0_data_type = missing
    try:
        t_1 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    pass
    l_0_union_macros = context.vars['union_macros'] = environment.get_template('union_macros.tmpl', 'union_serialization_declaration.tmpl')._get_default_module(context)
    context.exported_vars.discard('union_macros')
    l_0_data_view = str_join((t_1((undefined(name='union') if l_0_union is missing else l_0_union)), 'DataView', ))
    context.vars['data_view'] = l_0_data_view
    context.exported_vars.add('data_view')
    l_0_data_type = t_1((undefined(name='union') if l_0_union is missing else l_0_union), internal=True)
    context.vars['data_type'] = l_0_data_type
    context.exported_vars.add('data_type')
    yield '\n\nnamespace internal {\n\ntemplate <typename MaybeConstUserType>\nstruct Serializer<'
    yield str((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
    yield ', MaybeConstUserType> {\n  using UserType = typename std::remove_const<MaybeConstUserType>::type;\n  using Traits = UnionTraits<'
    yield str((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
    yield ', UserType>;\n\n  static void Serialize(MaybeConstUserType& input,\n                        MessageFragment<'
    yield str((undefined(name='data_type') if l_0_data_type is missing else l_0_data_type))
    yield '>& fragment,\n                        bool inlined) {\n    '
    yield str(context.call(environment.getattr((undefined(name='union_macros') if l_0_union_macros is missing else l_0_union_macros), 'serialize'), (undefined(name='union') if l_0_union is missing else l_0_union), 'default'))
    yield '\n  }\n\n  static bool Deserialize('
    yield str((undefined(name='data_type') if l_0_data_type is missing else l_0_data_type))
    yield '* input,\n                          UserType* output,\n                          Message* message) {\n    if (!input || input->is_null())\n      return CallSetToNullIfExists<Traits>(output);\n\n    '
    yield str((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
    yield ' data_view(input, message);\n    return CallTraitsRead<Traits>(data_view, output);\n  }\n};\n\n}  // namespace internal'

blocks = {}
debug_info = '1=19&3=21&4=24&9=28&11=30&14=32&16=34&19=36&25=38'