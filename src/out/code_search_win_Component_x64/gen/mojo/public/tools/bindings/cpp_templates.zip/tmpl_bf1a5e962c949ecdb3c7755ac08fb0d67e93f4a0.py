from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_direct_return_stub_with_bridge.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface = resolve('interface')
    l_0_interface_macros = missing
    try:
        t_1 = environment.filters['should_use_cb_pattern']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'should_use_cb_pattern' found.")
    pass
    l_0_interface_macros = context.vars['interface_macros'] = environment.get_template('interface_macros.tmpl', 'interface_direct_return_stub_with_bridge.tmpl')._get_default_module(context)
    context.exported_vars.discard('interface_macros')
    yield '\n\n\n\n\nclass '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'DirectReturnStub {\n public:\n   virtual ~'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'DirectReturnStub() = default;\n\n'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        _loop_vars = {}
        pass
        yield '\n   using '
        yield str(environment.getattr(l_1_method, 'name'))
        yield 'Result = '
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield '::'
        yield str(environment.getattr(l_1_method, 'name'))
        yield 'Result;'
        if t_1(l_1_method):
            pass
            yield '\n   using '
            yield str(environment.getattr(l_1_method, 'name'))
            yield 'Callback = '
            yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '::'
            yield str(environment.getattr(l_1_method, 'name'))
            yield 'Callback;\n   virtual void '
            yield str(environment.getattr(l_1_method, 'name'))
            yield '('
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_request_params'), '', l_1_method, _loop_vars=_loop_vars))
            yield ') = 0;\n'
        else:
            pass
            yield '\n   virtual '
            yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '::'
            yield str(environment.getattr(l_1_method, 'name'))
            yield 'Result '
            yield str(environment.getattr(l_1_method, 'name'))
            yield '('
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_params'), '', environment.getattr(l_1_method, 'parameters'), _loop_vars=_loop_vars))
            yield ') = 0;\n'
    l_1_method = missing
    yield '\n};\n\nclass '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Bridge : public '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield ' {\n public:\n   // The bridge owns the direct return stub. Use the bridge to manage the\n   // lifetime of the service, as if it was a normal mojo service impl.\n   '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Bridge('
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'DirectReturnStub* stub);\n   '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Bridge(const '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Bridge&) = delete;\n   '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Bridge operator=(const '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Bridge&) = delete;\n   ~'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Bridge() override;\n\n'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        _loop_vars = {}
        pass
        yield '\n   void '
        yield str(environment.getattr(l_1_method, 'name'))
        yield '('
        yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_request_params'), '', l_1_method, _loop_vars=_loop_vars))
        yield ') override;'
    l_1_method = missing
    yield '\n\n private:\n   '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'DirectReturnStub* stub_;\n};'

blocks = {}
debug_info = '1=19&6=22&8=24&10=26&11=30&12=36&13=39&14=45&16=52&21=62&25=66&26=70&27=74&28=78&30=80&31=84&35=90'