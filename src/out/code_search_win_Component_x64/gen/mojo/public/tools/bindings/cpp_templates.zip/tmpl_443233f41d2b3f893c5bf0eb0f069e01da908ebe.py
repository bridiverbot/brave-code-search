from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module.cc.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_contains_only_enums = resolve('contains_only_enums')
    l_0_namespace_begin = resolve('namespace_begin')
    l_0_namespace_end = resolve('namespace_end')
    l_0_variant_path = resolve('variant_path')
    l_0_module = resolve('module')
    l_0_variant = resolve('variant')
    l_0_interfaces = resolve('interfaces')
    l_0_unions = resolve('unions')
    l_0_for_blink = resolve('for_blink')
    l_0_extra_traits_headers = resolve('extra_traits_headers')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_structs = resolve('structs')
    l_0_interface_macros = resolve('interface_macros')
    try:
        t_1 = environment.filters['cpp_pod_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_pod_type' found.")
    try:
        t_2 = environment.filters['cpp_wrapper_call_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_call_type' found.")
    try:
        t_3 = environment.filters['cpp_wrapper_param_type']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_param_type' found.")
    try:
        t_4 = environment.filters['is_default_constructible']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_default_constructible' found.")
    try:
        t_5 = environment.filters['is_native_only_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_native_only_kind' found.")
    try:
        t_6 = environment.filters['is_non_const_ref_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_non_const_ref_kind' found.")
    try:
        t_7 = environment.filters['is_string_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_string_kind' found.")
    try:
        t_8 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_9 = environment.filters['should_generate_direct_return_stub']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'should_generate_direct_return_stub' found.")
    pass
    yield '// Copyright 2013 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    if (not (undefined(name='contains_only_enums') if l_0_contains_only_enums is missing else l_0_contains_only_enums)):
        pass
        included_template = environment.get_template('cpp_macros.tmpl', 'module.cc.tmpl')._get_default_module(context)
        l_0_namespace_begin = getattr(included_template, 'namespace_begin', missing)
        if l_0_namespace_begin is missing:
            l_0_namespace_begin = undefined(f"the template {included_template.__name__!r} (imported on line 6 in 'module.cc.tmpl') does not export the requested name 'namespace_begin'", name='namespace_begin')
        l_0_namespace_end = getattr(included_template, 'namespace_end', missing)
        if l_0_namespace_end is missing:
            l_0_namespace_end = undefined(f"the template {included_template.__name__!r} (imported on line 6 in 'module.cc.tmpl') does not export the requested name 'namespace_end'", name='namespace_end')
        l_0_variant_path = getattr(included_template, 'variant_path', missing)
        if l_0_variant_path is missing:
            l_0_variant_path = undefined(f"the template {included_template.__name__!r} (imported on line 6 in 'module.cc.tmpl') does not export the requested name 'variant_path'", name='variant_path')
        context.vars.update({'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})
        context.exported_vars.difference_update(('namespace_begin', 'namespace_end', 'variant_path'))
        yield '\n\n#if defined(__clang__)\n#pragma clang diagnostic push\n#pragma clang diagnostic ignored "-Wunused-private-field"\n#endif\n\n#include "'
        yield str(context.call((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path), environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
        yield '.h"'
        if (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
            pass
            yield '\n#include <math.h>'
        yield '\n#include <stdint.h>\n#include <utility>'
        if (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
            pass
            yield '\n#include "base/debug/alias.h"'
        if ((undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces) or (undefined(name='unions') if l_0_unions is missing else l_0_unions)):
            pass
            yield '\n#include "base/notreached.h"'
        if (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
            pass
            yield '\n#include "base/run_loop.h"\n#include "base/strings/string_number_conversions.h"\n#include "base/task/thread_pool/thread_pool_instance.h"\n#include "base/trace_event/trace_event.h"\n#include "base/trace_event/typed_macros.h"'
        yield '\n#include "mojo/public/cpp/bindings/lib/default_construct_tag_internal.h"'
        if (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
            pass
            yield '\n#include "mojo/public/cpp/bindings/lib/generated_code_util.h"\n#include "mojo/public/cpp/bindings/lib/message_internal.h"\n#include "mojo/public/cpp/bindings/lib/proxy_to_responder.h"\n#include "mojo/public/cpp/bindings/lib/send_message_helper.h"'
        yield '\n#include "mojo/public/cpp/bindings/lib/serialization.h"\n#include "mojo/public/cpp/bindings/lib/validate_params.h"\n#include "mojo/public/cpp/bindings/lib/validation_errors.h"\n#include "mojo/public/cpp/bindings/mojo_buildflags.h"'
        if (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
            pass
            yield '\n#include "mojo/public/cpp/bindings/urgent_message_scope.h"\n#include "mojo/public/interfaces/bindings/interface_control_messages.mojom.h"'
        yield '\n#include "third_party/perfetto/include/perfetto/tracing/traced_value.h"\n\n#include "'
        yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
        yield '-params-data.h"\n#include "'
        yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
        yield '-shared-message-ids.h"\n\n#include "'
        yield str(context.call((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path), environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
        yield '-import-headers.h"\n#include "'
        yield str(context.call((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path), environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
        yield '-test-utils.h"'
        if (undefined(name='for_blink') if l_0_for_blink is missing else l_0_for_blink):
            pass
            yield '\n#include "mojo/public/cpp/bindings/lib/wtf_serialization.h"'
        for l_1_header in (undefined(name='extra_traits_headers') if l_0_extra_traits_headers is missing else l_0_extra_traits_headers):
            _loop_vars = {}
            pass
            yield '\n#include "'
            yield str(l_1_header)
            yield '"'
        l_1_header = missing
        yield '\n\n'
        yield str(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
        for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
            _loop_vars = {}
            pass
            for l_2_constant in environment.getattr(l_1_struct, 'constants'):
                _loop_vars = {}
                pass
                if (not t_7(environment.getattr(l_2_constant, 'kind'))):
                    pass
                    yield '\nconstexpr '
                    yield str(t_1(environment.getattr(l_2_constant, 'kind')))
                    yield ' '
                    yield str(environment.getattr(l_1_struct, 'name'))
                    yield '::'
                    yield str(environment.getattr(l_2_constant, 'name'))
                    yield ';'
            l_2_constant = missing
        l_1_struct = missing
        for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
            _loop_vars = {}
            pass
            if (not t_5(l_1_struct)):
                pass
                template = environment.get_template('wrapper_class_definition.tmpl', 'module.cc.tmpl')
                for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'interface_macros': l_0_interface_macros, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
                    yield event
        l_1_struct = missing
        for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
            _loop_vars = {}
            pass
            template = environment.get_template('wrapper_union_class_definition.tmpl', 'module.cc.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'union': l_1_union, 'interface_macros': l_0_interface_macros, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
                yield event
        l_1_union = missing
        for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
            _loop_vars = {}
            pass
            template = environment.get_template('interface_definition.tmpl', 'module.cc.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'interface': l_1_interface, 'interface_macros': l_0_interface_macros, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
                yield event
            if t_9(l_1_interface):
                pass
                template = environment.get_template('interface_direct_return_stub_bridge_definition.tmpl', 'module.cc.tmpl')
                for event in template.root_render_func(template.new_context(context.get_all(), True, {'interface': l_1_interface, 'interface_macros': l_0_interface_macros, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
                    yield event
        l_1_interface = missing
        yield '\n\n'
        yield str(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
        yield '\n\n\nnamespace mojo {'
        for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
            _loop_vars = {}
            pass
            if (not t_5(l_1_struct)):
                pass
                yield '\n'
                template = environment.get_template('struct_traits_definition.tmpl', 'module.cc.tmpl')
                for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'interface_macros': l_0_interface_macros, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
                    yield event
        l_1_struct = missing
        for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
            _loop_vars = {}
            pass
            template = environment.get_template('union_traits_definition.tmpl', 'module.cc.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'union': l_1_union, 'interface_macros': l_0_interface_macros, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
                yield event
        l_1_union = missing
        yield '\n\n}  // namespace mojo\n\n\n// Symbols declared in the -test-utils.h header are defined here instead of a\n// separate .cc file to save compile time.\n\n'
        yield str(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
        l_0_interface_macros = context.vars['interface_macros'] = environment.get_template('interface_macros.tmpl', 'module.cc.tmpl')._get_default_module(context)
        context.exported_vars.discard('interface_macros')
        yield '\n\n'
        l_1_loop = missing
        for l_1_interface, l_1_loop in LoopContext((undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces), undefined):
            _loop_vars = {}
            pass
            l_2_loop = missing
            for l_2_method, l_2_loop in LoopContext(environment.getattr(l_1_interface, 'methods'), undefined):
                _loop_vars = {}
                pass
                yield '\nvoid '
                yield str(environment.getattr(l_1_interface, 'name'))
                yield 'InterceptorForTesting::'
                yield str(environment.getattr(l_2_method, 'name'))
                yield '('
                yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_request_params'), '', l_2_method, _loop_vars=_loop_vars))
                yield ') {\n  GetForwardingInterface()->'
                yield str(environment.getattr(l_2_method, 'name'))
                yield '('
                l_3_loop = missing
                for l_3_param, l_3_loop in LoopContext(environment.getattr(l_2_method, 'parameters'), undefined):
                    _loop_vars = {}
                    pass
                    if t_6(environment.getattr(l_3_param, 'kind')):
                        pass
                        yield '\n    '
                        yield str(environment.getattr(l_3_param, 'name'))
                    else:
                        pass
                        yield '\n    std::move('
                        yield str(environment.getattr(l_3_param, 'name'))
                        yield ')\n    '
                    if (not environment.getattr(l_3_loop, 'last')):
                        pass
                        yield ', '
                l_3_loop = l_3_param = missing
                if (environment.getattr(l_2_method, 'response_parameters') != None):
                    pass
                    if environment.getattr(l_2_method, 'parameters'):
                        pass
                        yield ', '
                    yield 'std::move(callback)'
                yield ');\n}'
            l_2_loop = l_2_method = missing
            yield '\n'
            yield str(environment.getattr(l_1_interface, 'name'))
            yield 'AsyncWaiter::'
            yield str(environment.getattr(l_1_interface, 'name'))
            yield 'AsyncWaiter(\n    '
            yield str(environment.getattr(l_1_interface, 'name'))
            yield '* proxy) : proxy_(proxy) {}\n\n'
            yield str(environment.getattr(l_1_interface, 'name'))
            yield 'AsyncWaiter::~'
            yield str(environment.getattr(l_1_interface, 'name'))
            yield 'AsyncWaiter() = default;\n\n\n'
            def t_10(fiter):
                for l_2_method in fiter:
                    if ((environment.getattr(l_2_method, 'response_parameters') != None) and (environment.getattr(l_2_method, 'result_response') == None)):
                        yield l_2_method
            for l_2_method in t_10(environment.getattr(l_1_interface, 'methods')):
                l_2_response_kind = resolve('response_kind')
                l_2_response_type = resolve('response_type')
                _loop_vars = {}
                pass
                yield 'void '
                yield str(environment.getattr(l_1_interface, 'name'))
                yield 'AsyncWaiter::'
                yield str(environment.getattr(l_2_method, 'name'))
                yield '(\n    '
                yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_sync_method_params'), '', l_2_method, _loop_vars=_loop_vars))
                yield ') {\n  base::RunLoop loop;\n  proxy_->'
                yield str(environment.getattr(l_2_method, 'name'))
                yield '('
                for l_3_param in environment.getattr(l_2_method, 'parameters'):
                    _loop_vars = {}
                    pass
                    if t_6(environment.getattr(l_3_param, 'kind')):
                        pass
                        yield '\n      '
                        yield str(environment.getattr(l_3_param, 'name'))
                        yield ','
                    else:
                        pass
                        yield '\n      std::move('
                        yield str(environment.getattr(l_3_param, 'name'))
                        yield '),'
                l_3_param = missing
                yield '\n      base::BindOnce(\n          [](base::RunLoop* loop'
                for l_3_param in environment.getattr(l_2_method, 'response_parameters'):
                    _loop_vars = {}
                    pass
                    yield ',\n             '
                    yield str(t_2(environment.getattr(l_3_param, 'kind')))
                    yield '* out_'
                    yield str(environment.getattr(l_3_param, 'name'))
                    yield '\n'
                l_3_param = missing
                for l_3_param in environment.getattr(l_2_method, 'response_parameters'):
                    _loop_vars = {}
                    pass
                    yield ',\n             '
                    yield str(t_3(environment.getattr(l_3_param, 'kind')))
                    yield ' '
                    yield str(environment.getattr(l_3_param, 'name'))
                l_3_param = missing
                yield ') {'
                for l_3_param in environment.getattr(l_2_method, 'response_parameters'):
                    _loop_vars = {}
                    pass
                    yield '*out_'
                    yield str(environment.getattr(l_3_param, 'name'))
                    yield ' = std::move('
                    yield str(environment.getattr(l_3_param, 'name'))
                    yield ');'
                l_3_param = missing
                yield '\n            loop->Quit();\n          },\n          &loop'
                for l_3_param in environment.getattr(l_2_method, 'response_parameters'):
                    _loop_vars = {}
                    pass
                    yield ',\n          out_'
                    yield str(environment.getattr(l_3_param, 'name'))
                l_3_param = missing
                yield '));\n  loop.Run();\n}\n\n'
                if ((t_8(environment.getattr(l_2_method, 'response_parameters')) == 1) and (environment.getattr(l_2_method, 'result_response') == None)):
                    pass
                    l_2_response_kind = environment.getattr(environment.getitem(environment.getattr(l_2_method, 'response_parameters'), 0), 'kind')
                    _loop_vars['response_kind'] = l_2_response_kind
                    l_2_response_type = t_2((undefined(name='response_kind') if l_2_response_kind is missing else l_2_response_kind))
                    _loop_vars['response_type'] = l_2_response_type
                    yield str((undefined(name='response_type') if l_2_response_type is missing else l_2_response_type))
                    yield ' '
                    yield str(environment.getattr(l_1_interface, 'name'))
                    yield 'AsyncWaiter::'
                    yield str(environment.getattr(l_2_method, 'name'))
                    yield '(\n    '
                    yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_params'), '', environment.getattr(l_2_method, 'parameters'), _loop_vars=_loop_vars))
                    yield ') {\n  '
                    yield str((undefined(name='response_type') if l_2_response_type is missing else l_2_response_type))
                    yield ' async_wait_result'
                    yield str(('' if t_4((undefined(name='response_kind') if l_2_response_kind is missing else l_2_response_kind)) else '{mojo::internal::DefaultConstructTag()}'))
                    yield ';\n  '
                    yield str(environment.getattr(l_2_method, 'name'))
                    yield '('
                    for l_3_param in environment.getattr(l_2_method, 'parameters'):
                        _loop_vars = {}
                        pass
                        yield 'std::move('
                        yield str(environment.getattr(l_3_param, 'name'))
                        yield '),'
                    l_3_param = missing
                    yield '&async_wait_result);\n  return async_wait_result;\n}'
                yield '\n\n'
            l_2_method = l_2_response_kind = l_2_response_type = missing
            yield '\n\n'
        l_1_loop = l_1_interface = missing
        yield '\n\n'
        yield str(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
        yield '\n\n\n#if defined(__clang__)\n#pragma clang diagnostic pop\n#endif'

blocks = {}
debug_info = '5=79&6=81&14=94&16=96&22=100&25=103&28=106&36=110&46=114&52=118&53=120&55=122&56=124&58=126&62=129&63=133&66=137&69=138&70=141&71=144&72=147&78=155&79=158&80=160&85=164&86=167&90=171&91=174&92=177&93=179&97=184&103=186&104=189&105=192&110=196&111=199&120=204&122=205&124=209&127=213&128=217&129=223&130=226&131=229&132=232&134=236&136=238&138=242&139=244&147=251&148=255&150=257&153=261&154=271&155=275&157=277&158=279&159=282&160=285&162=290&167=294&168=298&170=303&171=307&173=312&174=316&179=322&180=326&185=329&186=331&187=333&188=335&189=341&190=343&191=347&192=349&193=353&204=362'