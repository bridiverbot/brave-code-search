from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'union_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_send_validation_macros = l_0_serialize = missing
    try:
        t_1 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_2 = environment.filters['get_container_validate_params_ctor_args']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'get_container_validate_params_ctor_args' found.")
    try:
        t_3 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_4 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_5 = environment.filters['is_any_handle_or_interface_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_or_interface_kind' found.")
    try:
        t_6 = environment.filters['is_array_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_array_kind' found.")
    try:
        t_7 = environment.filters['is_associated_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_associated_kind' found.")
    try:
        t_8 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_9 = environment.filters['is_map_kind']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_map_kind' found.")
    try:
        t_10 = environment.filters['is_nullable_kind']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_kind' found.")
    try:
        t_11 = environment.filters['is_object_kind']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'is_object_kind' found.")
    try:
        t_12 = environment.filters['is_union_kind']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'is_union_kind' found.")
    try:
        t_13 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_13(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    try:
        t_14 = environment.filters['unmapped_type_for_serializer']
    except KeyError:
        @internalcode
        def t_14(*unused):
            raise TemplateRuntimeError("No filter named 'unmapped_type_for_serializer' found.")
    pass
    l_0_send_validation_macros = context.vars['send_validation_macros'] = environment.get_template('send_validation_macros.tmpl', 'union_macros.tmpl')._get_default_module(context)
    context.exported_vars.discard('send_validation_macros')
    yield '\n\n'
    def macro(l_1_union, l_1_send_validation_compiler_setting):
        t_15 = []
        l_1_data_view = l_1_data_type = missing
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        if l_1_send_validation_compiler_setting is missing:
            l_1_send_validation_compiler_setting = undefined("parameter 'send_validation_compiler_setting' was not provided", name='send_validation_compiler_setting')
        pass
        l_1_data_view = str_join((t_3(l_1_union), 'DataView', ))
        l_1_data_type = t_3(l_1_union, internal=True)
        t_15.append(
            '\n    if (CallIsNullIfExists<Traits>(input)) {\n       if (inlined)\n        fragment->set_null();\n      return;\n    }\n\nif (!inlined)\n  fragment.Allocate();\n\n    // TODO(azani): Handle unknown and objects.\n    // Set the not-null flag.\nfragment->size = kUnionDataSize;\nfragment->tag = Traits::GetTag(input);\nswitch (fragment->tag) {',
        )
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            l_2_serialization_args = resolve('serialization_args')
            l_2_error_code = resolve('error_code')
            l_2_name = l_2_kind = l_2_serializer_type = missing
            _loop_vars = {}
            pass
            l_2_name = environment.getattr(l_2_field, 'name')
            _loop_vars['name'] = l_2_name
            l_2_kind = environment.getattr(l_2_field, 'kind')
            _loop_vars['kind'] = l_2_kind
            l_2_serializer_type = t_14((undefined(name='kind') if l_2_kind is missing else l_2_kind))
            _loop_vars['serializer_type'] = l_2_serializer_type
            t_15.extend((
                '\n  case ',
                str((undefined(name='data_view') if l_1_data_view is missing else l_1_data_view)),
                '::Tag::k',
                str(t_13(environment.getattr(l_2_field, 'name'))),
                ': {\n    decltype(Traits::',
                str((undefined(name='name') if l_2_name is missing else l_2_name)),
                '(input))\n    in_',
                str((undefined(name='name') if l_2_name is missing else l_2_name)),
                ' = Traits::',
                str((undefined(name='name') if l_2_name is missing else l_2_name)),
                '(input);',
            ))
            if t_11((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                pass
                t_15.extend((
                    '\n    mojo::internal::MessageFragment<\n      typename decltype(fragment->data.f_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ')::BaseType>\n    value_fragment(fragment.message());',
                ))
                if t_12((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    l_2_serialization_args = [('in_' + (undefined(name='name') if l_2_name is missing else l_2_name)), 'value_fragment', 'false']
                    _loop_vars['serialization_args'] = l_2_serialization_args
                    t_15.extend((
                        '\n  ',
                        str(context.call(environment.getattr((undefined(name='send_validation_macros') if l_0_send_validation_macros is missing else l_0_send_validation_macros), 'get_serialize_call'), l_1_send_validation_compiler_setting, (undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type), (undefined(name='serialization_args') if l_2_serialization_args is missing else l_2_serialization_args), _loop_vars=_loop_vars)),
                    ))
                elif (t_6((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_9((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    t_15.extend((
                        '\n        constexpr const mojo::internal::ContainerValidateParams& ',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '_validate_params =\n            ',
                        str(t_4(t_2((undefined(name='kind') if l_2_kind is missing else l_2_kind)), 6)),
                        ';',
                    ))
                    l_2_serialization_args = [('in_' + (undefined(name='name') if l_2_name is missing else l_2_name)), 'value_fragment', (('&' + (undefined(name='name') if l_2_name is missing else l_2_name)) + '_validate_params')]
                    _loop_vars['serialization_args'] = l_2_serialization_args
                    t_15.extend((
                        '\n        ',
                        str(context.call(environment.getattr((undefined(name='send_validation_macros') if l_0_send_validation_macros is missing else l_0_send_validation_macros), 'get_serialize_call'), l_1_send_validation_compiler_setting, (undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type), (undefined(name='serialization_args') if l_2_serialization_args is missing else l_2_serialization_args), _loop_vars=_loop_vars)),
                    ))
                else:
                    pass
                    l_2_serialization_args = [('in_' + (undefined(name='name') if l_2_name is missing else l_2_name)), 'value_fragment']
                    _loop_vars['serialization_args'] = l_2_serialization_args
                    t_15.extend((
                        '\n        ',
                        str(context.call(environment.getattr((undefined(name='send_validation_macros') if l_0_send_validation_macros is missing else l_0_send_validation_macros), 'get_serialize_call'), l_1_send_validation_compiler_setting, (undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type), (undefined(name='serialization_args') if l_2_serialization_args is missing else l_2_serialization_args), _loop_vars=_loop_vars)),
                    ))
                if (not t_10((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    t_15.extend((
                        '\n  ',
                        str(context.call(environment.getattr((undefined(name='send_validation_macros') if l_0_send_validation_macros is missing else l_0_send_validation_macros), 'get_validation_check'), l_1_send_validation_compiler_setting, 'value_fragment.is_null()', 'mojo::internal::VALIDATION_ERROR_UNEXPECTED_NULL_POINTER', t_1('null %s in %s union', (undefined(name='name') if l_2_name is missing else l_2_name), environment.getattr(l_1_union, 'name')), _loop_vars=_loop_vars)),
                    ))
                t_15.extend((
                    '\n    fragment->data.f_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    '.Set(\n      value_fragment.is_null() ? nullptr : value_fragment.data());',
                ))
            elif t_5((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                pass
                l_2_serialization_args = [('in_' + (undefined(name='name') if l_2_name is missing else l_2_name)), ('&fragment->data.f_' + (undefined(name='name') if l_2_name is missing else l_2_name)), '&fragment.message()']
                _loop_vars['serialization_args'] = l_2_serialization_args
                t_15.extend((
                    '\n        ',
                    str(context.call(environment.getattr((undefined(name='send_validation_macros') if l_0_send_validation_macros is missing else l_0_send_validation_macros), 'get_serialize_call'), l_1_send_validation_compiler_setting, (undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type), (undefined(name='serialization_args') if l_2_serialization_args is missing else l_2_serialization_args), _loop_vars=_loop_vars)),
                ))
                if (not t_10((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    l_2_error_code = ('mojo::internal::VALIDATION_ERROR_UNEXPECTED_INVALID_INTERFACE_ID' if t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)) else 'mojo::internal::VALIDATION_ERROR_UNEXPECTED_INVALID_HANDLE')
                    _loop_vars['error_code'] = l_2_error_code
                    t_15.extend((
                        '\n  ',
                        str(context.call(environment.getattr((undefined(name='send_validation_macros') if l_0_send_validation_macros is missing else l_0_send_validation_macros), 'get_validation_check'), l_1_send_validation_compiler_setting, t_1('!mojo::internal::IsHandleOrInterfaceValid(fragment->data.f_%s)', (undefined(name='name') if l_2_name is missing else l_2_name)), (undefined(name='error_code') if l_2_error_code is missing else l_2_error_code), t_1('null %s in %s union', (undefined(name='name') if l_2_name is missing else l_2_name), environment.getattr(l_1_union, 'name')), _loop_vars=_loop_vars)),
                    ))
            elif t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                pass
                l_2_serialization_args = [('in_' + (undefined(name='name') if l_2_name is missing else l_2_name)), ('&fragment->data.f_' + (undefined(name='name') if l_2_name is missing else l_2_name))]
                _loop_vars['serialization_args'] = l_2_serialization_args
                t_15.extend((
                    '\n        ',
                    str(context.call(environment.getattr((undefined(name='send_validation_macros') if l_0_send_validation_macros is missing else l_0_send_validation_macros), 'get_serialize_call'), l_1_send_validation_compiler_setting, (undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type), (undefined(name='serialization_args') if l_2_serialization_args is missing else l_2_serialization_args), _loop_vars=_loop_vars)),
                ))
            else:
                pass
                t_15.extend((
                    '\n    fragment->data.f_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ' = in_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ';',
                ))
            t_15.append(
                '\n    break;\n  }',
            )
        l_2_field = l_2_name = l_2_kind = l_2_serializer_type = l_2_serialization_args = l_2_error_code = missing
        t_15.append(
            '\n}',
        )
        return concat(t_15)
    context.exported_vars.add('serialize')
    context.vars['serialize'] = l_0_serialize = Macro(environment, macro, 'serialize', ('union', 'send_validation_compiler_setting'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=96&17=99&18=107&19=108&34=112&35=118&36=120&37=122&38=126&39=130&40=132&41=137&43=141&45=144&46=146&51=150&55=152&56=156&57=158&58=161&63=165&68=169&72=173&77=175&78=179&84=183&87=186&88=188&93=192&97=194&98=196&101=200&108=202&109=204&113=208&119=214'