from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module-data-view.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_variant = resolve('variant')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_imports = resolve('imports')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_all_enums = resolve('all_enums')
    l_0_interfaces = resolve('interfaces')
    l_0_namespace_begin = l_0_namespace_end = l_0_include_guard = l_0_header_guard = l_0_mojom_type_traits = l_0_module_prefix = l_0_enum_decl = missing
    try:
        t_1 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_2 = environment.filters['get_name_for_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'get_name_for_kind' found.")
    try:
        t_3 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_4 = environment.filters['is_native_only_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_native_only_kind' found.")
    try:
        t_5 = environment.filters['is_union_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_union_kind' found.")
    try:
        t_6 = environment.filters['join']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'join' found.")
    try:
        t_7 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    pass
    yield '// Copyright 2025 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.\n\n// This file defines XDataView for type traits and can be included in\n// _mojom_traits.h definitions but otherwise please use .mojom-forward.h,\n// .mojom-shared.h or .mojom.h.\n\n// IWYU pragma: private\n// IWYU pragma: friend "traits"'
    included_template = environment.get_template('cpp_macros.tmpl', 'module-data-view.h.tmpl')._get_default_module(context)
    l_0_namespace_begin = getattr(included_template, 'namespace_begin', missing)
    if l_0_namespace_begin is missing:
        l_0_namespace_begin = undefined(f"the template {included_template.__name__!r} (imported on line 12 in 'module-data-view.h.tmpl') does not export the requested name 'namespace_begin'", name='namespace_begin')
    l_0_namespace_end = getattr(included_template, 'namespace_end', missing)
    if l_0_namespace_end is missing:
        l_0_namespace_end = undefined(f"the template {included_template.__name__!r} (imported on line 12 in 'module-data-view.h.tmpl') does not export the requested name 'namespace_end'", name='namespace_end')
    l_0_include_guard = getattr(included_template, 'include_guard', missing)
    if l_0_include_guard is missing:
        l_0_include_guard = undefined(f"the template {included_template.__name__!r} (imported on line 12 in 'module-data-view.h.tmpl') does not export the requested name 'include_guard'", name='include_guard')
    context.vars.update({'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'include_guard': l_0_include_guard})
    context.exported_vars.difference_update(('namespace_begin', 'namespace_end', 'include_guard'))
    l_0_header_guard = context.call((undefined(name='include_guard') if l_0_include_guard is missing else l_0_include_guard), '', str_join((environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), '_data_view', )), (undefined(name='variant') if l_0_variant is missing else l_0_variant))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    def macro(l_1_kind):
        t_8 = []
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        t_8.extend((
            '\ntemplate <>\nstruct MojomTypeTraits<',
            str(t_3(l_1_kind)),
            'DataView> {\n  using Data = ',
            str(t_3(l_1_kind, internal=True)),
            ';',
        ))
        if t_5(l_1_kind):
            pass
            t_8.append(
                '\n  using DataAsArrayElement = Data;\n  static constexpr MojomTypeCategory category = MojomTypeCategory::kUnion;',
            )
        else:
            pass
            t_8.append(
                '\n  using DataAsArrayElement = Pointer<Data>;\n  static constexpr MojomTypeCategory category = MojomTypeCategory::kStruct;',
            )
        t_8.append(
            '\n};',
        )
        return concat(t_8)
    context.exported_vars.add('mojom_type_traits')
    context.vars['mojom_type_traits'] = l_0_mojom_type_traits = Macro(environment, macro, 'mojom_type_traits', ('kind',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n#ifndef '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n#include <stdint.h>\n\n#include <functional>\n#include <iosfwd>\n#include <type_traits>\n#include <utility>'
    if (t_7((undefined(name='structs') if l_0_structs is missing else l_0_structs)) or t_7((undefined(name='unions') if l_0_unions is missing else l_0_unions))):
        pass
        yield '\n#include "mojo/public/cpp/bindings/array_data_view.h"\n#include "mojo/public/cpp/bindings/string_data_view.h"\n#include "mojo/public/cpp/bindings/lib/serialization.h"'
    yield '\n\n#include "'
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-shared-internal.h"'
    for l_1_import in (undefined(name='imports') if l_0_imports is missing else l_0_imports):
        _loop_vars = {}
        pass
        yield '\n#include "'
        yield str(environment.getattr(l_1_import, 'path'))
        yield '-shared.h"'
    l_1_import = missing
    yield '\n\n'
    yield str(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        if t_4(l_1_struct):
            pass
            yield '\nusing '
            yield str(environment.getattr(l_1_struct, 'name'))
            yield 'DataView = mojo::native::NativeStructDataView;'
        else:
            pass
            yield '\nclass '
            yield str(environment.getattr(l_1_struct, 'name'))
            yield 'DataView;'
        yield '\n'
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        yield '\nclass '
        yield str(environment.getattr(l_1_union, 'name'))
        yield 'DataView;'
    l_1_union = missing
    yield '\n\n'
    yield str(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
    yield '\n\n\nnamespace mojo {\nnamespace internal {'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        if (not t_4(l_1_struct)):
            pass
            yield '\n'
            yield str(context.call((undefined(name='mojom_type_traits') if l_0_mojom_type_traits is missing else l_0_mojom_type_traits), l_1_struct, _loop_vars=_loop_vars))
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call((undefined(name='mojom_type_traits') if l_0_mojom_type_traits is missing else l_0_mojom_type_traits), l_1_union, _loop_vars=_loop_vars))
    l_1_union = missing
    yield '\n\n}  // namespace internal\n}  // namespace mojo\n\n'
    yield str(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
    l_0_module_prefix = t_1('%s', t_6(context.eval_ctx, (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), '.'))
    context.vars['module_prefix'] = l_0_module_prefix
    context.exported_vars.add('module_prefix')
    included_template = environment.get_template('enum_macros.tmpl', 'module-data-view.h.tmpl').make_module(context.get_all(), True, {'enum_decl': l_0_enum_decl, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'module_prefix': l_0_module_prefix, 'mojom_type_traits': l_0_mojom_type_traits, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})
    l_0_enum_decl = getattr(included_template, 'enum_decl', missing)
    if l_0_enum_decl is missing:
        l_0_enum_decl = undefined(f"the template {included_template.__name__!r} (imported on line 91 in 'module-data-view.h.tmpl') does not export the requested name 'enum_decl'", name='enum_decl')
    context.vars['enum_decl'] = l_0_enum_decl
    context.exported_vars.discard('enum_decl')
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        l_1_export_attribute = resolve('export_attribute')
        _loop_vars = {}
        pass
        if t_4(l_1_enum):
            pass
            yield '\nusing '
            yield str(t_2(l_1_enum, flatten_nested_kind=True))
            yield ' = mojo::NativeEnum;'
        else:
            pass
            yield '\n'
            yield str(context.call((undefined(name='enum_decl') if l_0_enum_decl is missing else l_0_enum_decl), l_1_enum, (undefined(name='export_attribute') if l_1_export_attribute is missing else l_1_export_attribute), _loop_vars=_loop_vars))
    l_1_enum = l_1_export_attribute = missing
    if (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        yield '\n// Interface base classes. They are used for type safety check.'
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        yield '\nclass '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'InterfaceBase {};\n\nusing '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'PtrDataView =\n    mojo::InterfacePtrDataView<'
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'InterfaceBase>;\nusing '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'RequestDataView =\n    mojo::InterfaceRequestDataView<'
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'InterfaceBase>;\nusing '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'AssociatedPtrInfoDataView =\n    mojo::AssociatedInterfacePtrInfoDataView<'
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'InterfaceBase>;\nusing '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'AssociatedRequestDataView =\n    mojo::AssociatedInterfaceRequestDataView<'
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'InterfaceBase>;'
    l_1_interface = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        if (not t_4(l_1_struct)):
            pass
            yield '\n'
            template = environment.get_template('struct_data_view_declaration.tmpl', 'module-data-view.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'enum_decl': l_0_enum_decl, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'module_prefix': l_0_module_prefix, 'mojom_type_traits': l_0_mojom_type_traits, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
                yield event
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('union_data_view_declaration.tmpl', 'module-data-view.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'union': l_1_union, 'enum_decl': l_0_enum_decl, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'module_prefix': l_0_module_prefix, 'mojom_type_traits': l_0_mojom_type_traits, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
            yield event
    l_1_union = missing
    yield '\n\n'
    yield str(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
    yield '\n\n#endif  // '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '12=63&14=75&16=78&18=85&19=87&20=90&30=107&31=109&40=111&46=115&47=117&48=121&51=125&54=126&55=129&56=132&58=137&63=141&64=145&67=149&73=151&74=154&75=157&79=159&80=163&86=166&88=167&91=170&92=176&93=180&94=183&96=188&101=190&104=193&105=197&107=199&108=201&109=203&110=205&111=207&112=209&113=211&114=213&119=216&120=219&121=222&126=226&127=230&130=235&132=237'