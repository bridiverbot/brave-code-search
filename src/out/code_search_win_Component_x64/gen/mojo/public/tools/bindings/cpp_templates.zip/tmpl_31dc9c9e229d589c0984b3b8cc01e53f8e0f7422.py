from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_direct_return_stub_bridge_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface = resolve('interface')
    l_0_interface_macros = l_0_class_scope = missing
    try:
        t_1 = environment.filters['cpp_wrapper_param_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_param_type' found.")
    try:
        t_2 = environment.filters['is_non_const_ref_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'is_non_const_ref_kind' found.")
    try:
        t_3 = environment.filters['should_use_cb_pattern']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'should_use_cb_pattern' found.")
    pass
    l_0_interface_macros = context.vars['interface_macros'] = environment.get_template('interface_macros.tmpl', 'interface_direct_return_stub_bridge_definition.tmpl')._get_default_module(context)
    context.exported_vars.discard('interface_macros')
    yield '\n\n'
    l_0_class_scope = (environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name') + 'Bridge')
    context.vars['class_scope'] = l_0_class_scope
    context.exported_vars.add('class_scope')
    yield '\n\n'
    yield str((undefined(name='class_scope') if l_0_class_scope is missing else l_0_class_scope))
    yield '::'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Bridge('
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'DirectReturnStub* stub)\n        : stub_(stub) {\n    CHECK(stub_);\n}\n\n'
    yield str((undefined(name='class_scope') if l_0_class_scope is missing else l_0_class_scope))
    yield '::~'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Bridge() = default;\n\n'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        _loop_vars = {}
        pass
        yield '\nvoid '
        yield str((undefined(name='class_scope') if l_0_class_scope is missing else l_0_class_scope))
        yield '::'
        yield str(environment.getattr(l_1_method, 'name'))
        yield '('
        yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_request_params'), '', l_1_method, _loop_vars=_loop_vars))
        yield ') {'
        if t_3(l_1_method):
            pass
            yield '\n\n    stub_->'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '('
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
                _loop_vars = {}
                pass
                if t_2(environment.getattr(l_2_param, 'kind')):
                    pass
                    yield 'const_cast<'
                    yield str(t_1(environment.getattr(l_2_param, 'kind')))
                    yield '>('
                    yield str(environment.getattr(l_2_param, 'name'))
                    yield ')'
                else:
                    pass
                    yield 'std::move('
                    yield str(environment.getattr(l_2_param, 'name'))
                    yield ')'
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    yield ', '
            l_2_loop = l_2_param = missing
            if (environment.getattr(l_1_method, 'response_parameters') != None):
                pass
                if environment.getattr(l_1_method, 'parameters'):
                    pass
                    yield ', '
                yield 'std::move(callback)'
            yield ');'
        else:
            pass
            yield '\n\n    std::move(callback).Run(stub_->'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '('
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
                _loop_vars = {}
                pass
                if t_2(environment.getattr(l_2_param, 'kind')):
                    pass
                    yield '\n      '
                    yield str(environment.getattr(l_2_param, 'name'))
                else:
                    pass
                    yield '\n      std::move('
                    yield str(environment.getattr(l_2_param, 'name'))
                    yield ')\n'
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    yield ', '
            l_2_loop = l_2_param = missing
        yield '\n    ));\n}\n'
    l_1_loop = l_1_method = missing

blocks = {}
debug_info = '1=31&3=34&5=38&10=44&12=49&13=53&14=59&16=62&17=65&18=68&19=71&21=78&22=80&24=84&25=86&32=94&33=97&34=100&35=103&37=107&39=109'