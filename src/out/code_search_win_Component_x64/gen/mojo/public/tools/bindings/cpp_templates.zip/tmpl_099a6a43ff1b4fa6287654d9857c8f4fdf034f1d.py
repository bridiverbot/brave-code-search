from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface = resolve('interface')
    l_0_module_prefix = resolve('module_prefix')
    l_0_kythe_annotation = resolve('kythe_annotation')
    l_0_export_attribute = resolve('export_attribute')
    l_0_module_namespace = resolve('module_namespace')
    l_0_sandbox_enum = resolve('sandbox_enum')
    l_0_interface_macros = l_0_interface_prefix = l_0_sync_method_ordinals = missing
    try:
        t_1 = environment.filters['append_space_if_nonempty']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'append_space_if_nonempty' found.")
    try:
        t_2 = environment.filters['cpp_wrapper_param_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_param_type' found.")
    try:
        t_3 = environment.filters['default']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'default' found.")
    try:
        t_4 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_5 = environment.filters['format_constant_declaration']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'format_constant_declaration' found.")
    try:
        t_6 = environment.filters['get_full_mojom_name_for_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'get_full_mojom_name_for_kind' found.")
    try:
        t_7 = environment.filters['get_name_for_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'get_name_for_kind' found.")
    try:
        t_8 = environment.filters['get_sync_method_ordinals']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'get_sync_method_ordinals' found.")
    try:
        t_9 = environment.filters['has_callbacks']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'has_callbacks' found.")
    try:
        t_10 = environment.filters['has_non_const_ref_param']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'has_non_const_ref_param' found.")
    try:
        t_11 = environment.filters['has_uninterruptable_methods']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'has_uninterruptable_methods' found.")
    try:
        t_12 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_13 = environment.filters['is_non_const_ref_kind']
    except KeyError:
        @internalcode
        def t_13(*unused):
            raise TemplateRuntimeError("No filter named 'is_non_const_ref_kind' found.")
    try:
        t_14 = environment.filters['join']
    except KeyError:
        @internalcode
        def t_14(*unused):
            raise TemplateRuntimeError("No filter named 'join' found.")
    try:
        t_15 = environment.filters['passes_associated_kinds']
    except KeyError:
        @internalcode
        def t_15(*unused):
            raise TemplateRuntimeError("No filter named 'passes_associated_kinds' found.")
    try:
        t_16 = environment.filters['replace']
    except KeyError:
        @internalcode
        def t_16(*unused):
            raise TemplateRuntimeError("No filter named 'replace' found.")
    try:
        t_17 = environment.filters['sort']
    except KeyError:
        @internalcode
        def t_17(*unused):
            raise TemplateRuntimeError("No filter named 'sort' found.")
    pass
    l_0_interface_macros = context.vars['interface_macros'] = environment.get_template('interface_macros.tmpl', 'interface_declaration.tmpl')._get_default_module(context)
    context.exported_vars.discard('interface_macros')
    yield '\nclass '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Proxy;\n\ntemplate <typename ImplRefTraits>\nclass '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub;\n\nclass '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'RequestValidator;'
    if t_9((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield '\nclass '
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'ResponseValidator;'
    l_0_interface_prefix = t_4('%s.%s', (undefined(name='module_prefix') if l_0_module_prefix is missing else l_0_module_prefix), environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    context.vars['interface_prefix'] = l_0_interface_prefix
    context.exported_vars.add('interface_prefix')
    yield '\n\n'
    yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), (undefined(name='interface_prefix') if l_0_interface_prefix is missing else l_0_interface_prefix)))
    yield '\nclass '
    yield str(t_1((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute)))
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '\n    : public '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'InterfaceBase {\n public:\n  using IPCStableHashFunction = uint32_t(*)();\n  static constexpr const char* Name_ = "'
    yield str((undefined(name='module_namespace') if l_0_module_namespace is missing else l_0_module_namespace))
    yield '.'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '";\n  static IPCStableHashFunction MessageToMethodInfo_(mojo::Message& message);\n  static const char* MessageToMethodName_(mojo::Message& message);'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'runtime_feature'):
        pass
        yield '\n  static bool RuntimeFeature_IsEnabled_(bool expected);'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'uuid'):
        pass
        yield '\n  static constexpr base::Token Uuid_{ '
        yield str(environment.getitem(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'uuid'), 0))
        yield 'ULL,\n                                      '
        yield str(environment.getitem(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'uuid'), 1))
        yield 'ULL };'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'service_sandbox'):
        pass
        l_0_sandbox_enum = t_4('%s', t_16(context.eval_ctx, context.call(environment.getattr(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'service_sandbox'), 'GetSpec')), '.', '::'))
        context.vars['sandbox_enum'] = l_0_sandbox_enum
        context.exported_vars.add('sandbox_enum')
        yield '\n  static constexpr auto kServiceSandbox = '
        yield str((undefined(name='sandbox_enum') if l_0_sandbox_enum is missing else l_0_sandbox_enum))
        yield ';'
    yield '\n  static constexpr uint32_t Version_ = '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'version'))
    yield ';\n  static constexpr bool PassesAssociatedKinds_ = '
    if t_15((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield 'true'
    else:
        pass
        yield 'false'
    yield ';'
    l_0_sync_method_ordinals = t_8((undefined(name='interface') if l_0_interface is missing else l_0_interface))
    context.vars['sync_method_ordinals'] = l_0_sync_method_ordinals
    context.exported_vars.add('sync_method_ordinals')
    if (undefined(name='sync_method_ordinals') if l_0_sync_method_ordinals is missing else l_0_sync_method_ordinals):
        pass
        yield '\n  static inline constexpr uint32_t kSyncMethodOrdinals[] = {\n    '
        yield str(t_12(t_14(context.eval_ctx, t_17(environment, (undefined(name='sync_method_ordinals') if l_0_sync_method_ordinals is missing else l_0_sync_method_ordinals)), ', \n'), 4))
        yield '\n  };'
    yield '\n  static constexpr bool HasUninterruptableMethods_ ='
    if t_11((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield ' true'
    else:
        pass
        yield ' false'
    yield ';\n\n  using Base_ = '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'InterfaceBase;\n  using Proxy_ = '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Proxy;\n\n  template <typename ImplRefTraits>\n  using Stub_ = '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub<ImplRefTraits>;\n\n  using RequestValidator_ = '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'RequestValidator;'
    if t_9((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield '\n  using ResponseValidator_ = '
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'ResponseValidator;'
    else:
        pass
        yield '\n  using ResponseValidator_ = mojo::PassThroughFilter;'
    yield '\n  enum MethodMinVersions : uint32_t {'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        _loop_vars = {}
        pass
        yield '\n    k'
        yield str(environment.getattr(l_1_method, 'name'))
        yield 'MinVersion = '
        yield str(t_3(environment.getattr(l_1_method, 'min_version'), 0, True))
        yield ','
    l_1_method = missing
    yield "\n  };\n\n// crbug.com/1340245 - this causes binary size bloat on Fuchsia, and we're OK\n// with not having this data in traces there.\n#if !BUILDFLAG(IS_FUCHSIA)"
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        _loop_vars = {}
        pass
        yield '\n  struct '
        yield str(environment.getattr(l_1_method, 'name'))
        yield '_Sym {\n    NOINLINE static uint32_t IPCStableHash();\n  };'
    l_1_method = missing
    yield '\n#endif // !BUILDFLAG(IS_FUCHSIA)'
    for l_1_enum in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'enums'):
        _loop_vars = {}
        pass
        yield '\n  '
        yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_6(l_1_enum), _loop_vars=_loop_vars))
        yield '\n  using '
        yield str(environment.getattr(l_1_enum, 'name'))
        yield ' = '
        yield str(t_7(l_1_enum, flatten_nested_kind=True))
        yield ';'
    l_1_enum = missing
    for l_1_constant in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'constants'):
        _loop_vars = {}
        pass
        yield '\n  '
        yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_4('%s.%s', (undefined(name='interface_prefix') if l_0_interface_prefix is missing else l_0_interface_prefix), environment.getattr(l_1_constant, 'name')), _loop_vars=_loop_vars))
        yield '\n  static '
        yield str(t_5(l_1_constant, nested=True))
        yield ';'
    l_1_constant = missing
    yield '\n  virtual ~'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '() = default;'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        l_1_for_blink = resolve('for_blink')
        _loop_vars = {}
        pass
        yield '\n'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            if environment.getattr(l_1_method, 'sync'):
                pass
                yield '\n  // Sync method. This signature is used by the client side; the service side\n  // should implement the signature with callback below.\n  '
                yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_4('%s.%s', (undefined(name='interface_prefix') if l_0_interface_prefix is missing else l_0_interface_prefix), environment.getattr(l_1_method, 'name')), _loop_vars=_loop_vars))
                yield '\n  virtual bool '
                yield str(environment.getattr(l_1_method, 'name'))
                yield '('
                yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_sync_method_params'), '', l_1_method, _loop_vars=_loop_vars))
                yield ');'
            if (environment.getattr(l_1_method, 'result_response') != None):
                pass
                yield '\n  using '
                yield str(environment.getattr(l_1_method, 'name'))
                yield 'Callback = '
                yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_result_callback'), l_1_method, _loop_vars=_loop_vars))
                yield ';\n  using '
                yield str(environment.getattr(l_1_method, 'name'))
                yield 'Result = '
                yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'result_response_to_expected'), environment.getattr(l_1_method, 'result_response'), _loop_vars=_loop_vars))
                yield ';'
            else:
                pass
                yield '\n  using '
                yield str(environment.getattr(l_1_method, 'name'))
                yield 'Callback = '
                yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_callback'), l_1_method, (undefined(name='for_blink') if l_1_for_blink is missing else l_1_for_blink), _loop_vars=_loop_vars))
                yield ';'
            yield '\n  using '
            yield str(environment.getattr(l_1_method, 'name'))
            yield 'MojoCallback = '
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_callback'), l_1_method, (undefined(name='for_blink') if l_1_for_blink is missing else l_1_for_blink), _loop_vars=_loop_vars))
            yield ';\n'
        yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_4('%s.%s', (undefined(name='interface_prefix') if l_0_interface_prefix is missing else l_0_interface_prefix), environment.getattr(l_1_method, 'name')), _loop_vars=_loop_vars))
        yield '\n  virtual void '
        yield str(environment.getattr(l_1_method, 'name'))
        yield '('
        yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_request_params'), '', l_1_method, _loop_vars=_loop_vars))
        yield ') = 0;'
        if t_10(l_1_method):
            pass
            yield '\n  // Default implementation for non-const ref params. This method can be\n  // implemented as a performance optimization for non-const ref types.\n  virtual void '
            yield str(environment.getattr(l_1_method, 'name'))
            yield '('
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_request_params'), '', l_1_method, allow_non_const_ref=True, _loop_vars=_loop_vars))
            yield ') {\n    '
            yield str(environment.getattr(l_1_method, 'name'))
            yield '('
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
                _loop_vars = {}
                pass
                if t_13(environment.getattr(l_2_param, 'kind')):
                    pass
                    yield 'const_cast<'
                    yield str(t_2(environment.getattr(l_2_param, 'kind')))
                    yield '>('
                    yield str(environment.getattr(l_2_param, 'name'))
                    yield ')'
                else:
                    pass
                    yield 'std::move('
                    yield str(environment.getattr(l_2_param, 'name'))
                    yield ')'
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    yield ', '
            l_2_loop = l_2_param = missing
            if (environment.getattr(l_1_method, 'response_parameters') != None):
                pass
                if environment.getattr(l_1_method, 'parameters'):
                    pass
                    yield ', '
                yield 'std::move(callback)'
            yield ');\n  }'
    l_1_loop = l_1_method = l_1_for_blink = missing
    yield '\n};'

blocks = {}
debug_info = '1=120&2=123&5=125&7=127&8=129&9=132&12=134&14=138&15=140&16=143&21=145&24=149&28=152&29=155&30=157&32=159&33=161&34=165&36=168&37=170&38=177&39=180&41=183&45=186&48=193&49=195&52=197&54=199&55=201&56=204&63=210&64=214&72=220&73=224&80=228&81=232&82=234&86=239&87=243&88=245&92=249&94=252&95=257&96=259&99=262&100=264&103=268&104=271&105=275&107=282&109=287&111=291&112=293&113=297&116=300&117=304&118=307&119=310&120=313&122=320&123=322&125=326&126=328'