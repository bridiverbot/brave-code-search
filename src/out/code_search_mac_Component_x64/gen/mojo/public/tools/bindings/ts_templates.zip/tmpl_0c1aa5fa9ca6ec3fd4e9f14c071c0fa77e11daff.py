from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'union_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    try:
        t_1 = environment.filters['spec_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'spec_type' found.")
    try:
        t_2 = environment.filters['to_union_field_tag_name']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'to_union_field_tag_name' found.")
    try:
        t_3 = environment.filters['ts_type_maybe_nullable']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'ts_type_maybe_nullable' found.")
    pass
    yield 'mojo.internal.Union(\n    '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield "Spec.$, '"
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield "',\n    {"
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield "\n      '"
        yield str(environment.getattr(l_1_field, 'name'))
        yield "': {\n        'ordinal': "
        yield str(environment.getattr(l_1_field, 'ordinal'))
        yield ",\n        'type': "
        yield str(t_1(environment.getattr(l_1_field, 'kind')))
        yield ','
        if environment.getattr(environment.getattr(l_1_field, 'kind'), 'is_nullable'):
            pass
            yield "\n        'nullable': true,"
        yield '\n      },'
    l_1_field = missing
    yield '\n    });\n\nexport declare interface '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield ' {'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n  '
        yield str(environment.getattr(l_1_field, 'name'))
        yield '?: '
        yield str(t_3(environment.getattr(l_1_field, 'kind')))
        yield ','
    l_1_field = missing
    yield '\n}\n\nexport enum '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'FieldTags {'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n  '
        yield str(t_2(environment.getattr(l_1_field, 'name')))
        yield ','
    l_1_field = missing
    yield '\n}\n\nexport function which'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '(u: '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '): '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'FieldTags {'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        l_1_field_access = missing
        _loop_vars = {}
        pass
        l_1_field_access = ('u.' + environment.getattr(l_1_field, 'name'))
        _loop_vars['field_access'] = l_1_field_access
        yield '\n  if ('
        yield str((undefined(name='field_access') if l_1_field_access is missing else l_1_field_access))
        yield ' !== null && '
        yield str((undefined(name='field_access') if l_1_field_access is missing else l_1_field_access))
        yield ' !== undefined) {\n    return '
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield 'FieldTags.'
        yield str(t_2(environment.getattr(l_1_field, 'name')))
        yield ';\n  }'
    l_1_field = l_1_field_access = missing
    if environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'extensible'):
        pass
        yield '\n  return '
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield 'FieldTags.'
        yield str(t_2(environment.getattr(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'default_field'), 'name')))
        yield ';'
    else:
        pass
        yield '\n  throw new Error("no union field has been set, this is an illegal state");'
    yield '\n}'

blocks = {}
debug_info = '2=31&4=35&5=39&6=41&7=43&8=45&15=51&16=53&17=57&21=63&22=65&23=69&27=73&30=79&31=83&32=86&33=90&37=95&38=98'