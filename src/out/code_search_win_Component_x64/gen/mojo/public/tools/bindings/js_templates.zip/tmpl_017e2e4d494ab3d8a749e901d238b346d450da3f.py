from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'lite/union_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_generate_closure_exports = resolve('generate_closure_exports')
    l_0_module = resolve('module')
    l_0_union = resolve('union')
    l_0_generate_fuzzing = resolve('generate_fuzzing')
    try:
        t_1 = environment.filters['lite_closure_type_with_nullability']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'lite_closure_type_with_nullability' found.")
    try:
        t_2 = environment.filters['lite_js_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'lite_js_type' found.")
    pass
    if (undefined(name='generate_closure_exports') if l_0_generate_closure_exports is missing else l_0_generate_closure_exports):
        pass
        yield "goog.provide('"
        yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield "');\n"
    yield '\n\nmojo.internal.Union(\n    '
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield "Spec.$, '"
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield "',\n    {"
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield "\n      '"
        yield str(environment.getattr(l_1_field, 'name'))
        yield "': {\n        'ordinal': "
        yield str(environment.getattr(l_1_field, 'ordinal'))
        yield ",\n        'type': "
        yield str(t_2(environment.getattr(l_1_field, 'kind')))
        yield ','
        if environment.getattr(environment.getattr(l_1_field, 'kind'), 'is_nullable'):
            pass
            yield "\n        'nullable': true,"
        yield '\n      },'
    l_1_field = missing
    yield '\n    });\n\n/**\n * @typedef { {'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n *   '
        yield str(environment.getattr(l_1_field, 'name'))
        yield ': ('
        yield str(t_1(environment.getattr(l_1_field, 'kind')))
        yield '|undefined),'
    l_1_field = missing
    yield '\n * } }\n */\n'
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield ';'
    if (undefined(name='generate_fuzzing') if l_0_generate_fuzzing is missing else l_0_generate_fuzzing):
        pass
        yield '\n/**\n * Fuzzing-only constructors, one per union variant. `new '
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '.foo(x)`\n * returns the plain object `{foo: x}`, which is how unions are represented in\n * these bindings. Fuzzers can then produce unions through typed constructor\n * calls instead of object literals that lack type information.\n * @const\n */\n'
        yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield ' = {'
        for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
            _loop_vars = {}
            pass
            yield "\n  '"
            yield str(environment.getattr(l_1_field, 'name'))
            yield "': function(value) {\n    return {'"
            yield str(environment.getattr(l_1_field, 'name'))
            yield "': value};\n  },"
        l_1_field = missing
        yield '\n};'

blocks = {}
debug_info = '1=27&2=30&6=35&8=41&9=45&10=47&11=49&12=51&21=57&22=61&26=67&29=71&31=74&37=76&38=80&39=84&40=86'