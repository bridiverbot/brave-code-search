from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_for_bindings_internals = resolve('for_bindings_internals')
    l_0_interfaces = resolve('interfaces')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_enums = resolve('enums')
    l_0_bindings_library_path = resolve('bindings_library_path')
    l_0_webui_factory = resolve('webui_factory')
    l_0_mojo_browser_proxy_import = resolve('mojo_browser_proxy_import')
    l_0_js_module_imports = resolve('js_module_imports')
    l_0_typemapped_structs = resolve('typemapped_structs')
    l_0_typemap_imports = resolve('typemap_imports')
    l_0_module = resolve('module')
    l_0_enum_def = missing
    try:
        t_1 = environment.filters['constant_value']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'constant_value' found.")
    try:
        t_2 = environment.filters['converter_import']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'converter_import' found.")
    try:
        t_3 = environment.filters['imports_for_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'imports_for_kind' found.")
    try:
        t_4 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_5 = environment.filters['sort']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'sort' found.")
    try:
        t_6 = environment.filters['ts_type_maybe_nullable']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'ts_type_maybe_nullable' found.")
    pass
    yield '// Copyright 2020 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.\n\n'
    if ((not (undefined(name='for_bindings_internals') if l_0_for_bindings_internals is missing else l_0_for_bindings_internals)) and ((((t_4((undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces)) > 0) or (t_4((undefined(name='structs') if l_0_structs is missing else l_0_structs)) > 0)) or (t_4((undefined(name='unions') if l_0_unions is missing else l_0_unions)) > 0)) or (t_4((undefined(name='enums') if l_0_enums is missing else l_0_enums)) > 0))):
        pass
        yield "import {mojo} from '"
        yield str((undefined(name='bindings_library_path') if l_0_bindings_library_path is missing else l_0_bindings_library_path))
        yield "';"
    if (undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory):
        pass
        if environment.getattr((undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory), 'has_callback_router'):
            pass
            yield "\nimport {MojoBrowserProxyFactory} from '"
            yield str((undefined(name='mojo_browser_proxy_import') if l_0_mojo_browser_proxy_import is missing else l_0_mojo_browser_proxy_import))
            yield "';\nimport type {MojoBrowserProxy} from '"
            yield str((undefined(name='mojo_browser_proxy_import') if l_0_mojo_browser_proxy_import is missing else l_0_mojo_browser_proxy_import))
            yield "';"
        else:
            pass
            yield "\nimport {MojoHandlerProxyFactory} from '"
            yield str((undefined(name='mojo_browser_proxy_import') if l_0_mojo_browser_proxy_import is missing else l_0_mojo_browser_proxy_import))
            yield "';\nimport type {MojoHandlerProxy} from '"
            yield str((undefined(name='mojo_browser_proxy_import') if l_0_mojo_browser_proxy_import is missing else l_0_mojo_browser_proxy_import))
            yield "';"
    yield '\n\n'
    l_1_loop = missing
    for (l_1_path, l_1_kinds), l_1_loop in LoopContext(t_5(environment, context.call(environment.getattr((undefined(name='js_module_imports') if l_0_js_module_imports is missing else l_0_js_module_imports), 'items'))), undefined):
        _loop_vars = {}
        pass
        yield 'import {'
        l_2_loop = missing
        for l_2_kind, l_2_loop in LoopContext(t_5(environment, l_1_kinds), undefined):
            _loop_vars = {}
            pass
            l_3_loop = missing
            for l_3_item, l_3_loop in LoopContext(t_3(l_2_kind), undefined):
                _loop_vars = {}
                pass
                yield '\n  '
                yield str(environment.getattr(l_3_item, 'name'))
                yield ' as '
                yield str(environment.getattr(l_3_item, 'alias'))
                if (not environment.getattr(l_3_loop, 'last')):
                    pass
                    yield ','
            l_3_loop = l_3_item = missing
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_kind = missing
        yield "\n} from '"
        yield str(l_1_path)
        yield "';\n"
    l_1_loop = l_1_path = l_1_kinds = missing
    if (t_4((undefined(name='typemapped_structs') if l_0_typemapped_structs is missing else l_0_typemapped_structs)) > 0):
        pass
        for l_1_struct in context.call(environment.getattr((undefined(name='typemapped_structs') if l_0_typemapped_structs is missing else l_0_typemapped_structs), 'keys')):
            l_1_converters_filename = resolve('converters_filename')
            _loop_vars = {}
            pass
            yield '\nimport {\n  '
            yield str(environment.getattr(l_1_struct, 'name'))
            yield 'DataView,\n  '
            yield str(environment.getattr(l_1_struct, 'name'))
            yield "TypeMapper,\n} from './"
            yield str((undefined(name='converters_filename') if l_1_converters_filename is missing else l_1_converters_filename))
            yield "';"
        l_1_struct = l_1_converters_filename = missing
    yield '\n\n'
    l_1_loop = missing
    for (l_1_path, l_1_types), l_1_loop in LoopContext(t_5(environment, context.call(environment.getattr((undefined(name='typemap_imports') if l_0_typemap_imports is missing else l_0_typemap_imports), 'items'))), undefined):
        _loop_vars = {}
        pass
        yield 'import type {'
        l_2_loop = missing
        for l_2_type, l_2_loop in LoopContext(t_5(environment, l_1_types), undefined):
            _loop_vars = {}
            pass
            yield '\n  '
            yield str(l_2_type)
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_type = missing
        yield "\n} from '"
        yield str(l_1_path)
        yield "';\n"
    l_1_loop = l_1_path = l_1_types = missing
    yield '\n\n'
    for l_1_typemap in context.call(environment.getattr((undefined(name='typemapped_structs') if l_0_typemapped_structs is missing else l_0_typemapped_structs), 'values')):
        _loop_vars = {}
        pass
        yield 'import { '
        yield str(environment.getattr(l_1_typemap, 'converter'))
        yield " } from './"
        yield str(t_2(l_1_typemap))
        yield "';\n"
    l_1_typemap = missing
    for l_1_constant in environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'constants'):
        _loop_vars = {}
        pass
        yield '\nexport const '
        yield str(environment.getattr(l_1_constant, 'name'))
        yield ': '
        yield str(t_6(environment.getattr(l_1_constant, 'kind')))
        yield ' = '
        yield str(t_1(l_1_constant))
        yield ';\n\n'
    l_1_constant = missing
    included_template = environment.get_template('enum_definition.tmpl', 'module_definition.tmpl').make_module(context.get_all(), True, {'enum_def': l_0_enum_def})
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined(f"the template {included_template.__name__!r} (imported on line 61 in 'module_definition.tmpl') does not export the requested name 'enum_def'", name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    for l_1_enum in (undefined(name='enums') if l_0_enums is missing else l_0_enums):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), l_1_enum, _loop_vars=_loop_vars))
        yield '\n'
    l_1_enum = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('interface_definition.tmpl', 'module_definition.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'interface': l_1_interface, 'enum_def': l_0_enum_def})):
            yield event
    l_1_interface = missing
    yield '\n'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        yield '\nexport const '
        yield str(environment.getattr(l_1_struct, 'name'))
        yield 'Spec: { $: mojo.internal.MojomType } =\n    { $: {} as unknown as mojo.internal.MojomType };\n'
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        yield '\nexport const '
        yield str(environment.getattr(l_1_union, 'name'))
        yield 'Spec: { $: mojo.internal.MojomType } =\n    { $: {} as unknown as mojo.internal.MojomType };\n'
    l_1_union = missing
    yield '\n'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        template = environment.get_template('struct_definition.tmpl', 'module_definition.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'enum_def': l_0_enum_def})):
            yield event
        yield '\n'
    l_1_struct = missing
    yield '\n'
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        template = environment.get_template('union_definition.tmpl', 'module_definition.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'union': l_1_union, 'enum_def': l_0_enum_def})):
            yield event
        yield '\n'
    l_1_union = missing
    if (undefined(name='webui_factory') if l_0_webui_factory is missing else l_0_webui_factory):
        pass
        template = environment.get_template('webui_browser_proxy_definition.tmpl', 'module_definition.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_def': l_0_enum_def})):
            yield event

blocks = {}
debug_info = '5=61&8=64&10=66&11=68&12=71&13=73&15=78&16=80&20=84&22=89&23=93&24=97&25=100&27=104&29=109&32=112&33=114&35=119&36=121&37=123&41=128&43=133&44=137&45=138&47=143&50=147&51=151&55=156&56=160&61=167&62=173&63=177&67=180&68=184&72=189&73=193&76=196&77=200&82=204&83=207&87=213&88=216&91=221&93=223'