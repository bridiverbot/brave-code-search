from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'enum_serialization_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_enum = resolve('enum')
    l_0_mojom_type = missing
    try:
        t_1 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    pass
    l_0_mojom_type = t_1((undefined(name='enum') if l_0_enum is missing else l_0_enum), flatten_nested_kind=True)
    context.vars['mojom_type'] = l_0_mojom_type
    context.exported_vars.add('mojom_type')
    yield '\n\nnamespace internal {\n\ntemplate <typename MaybeConstUserType>\nstruct Serializer<'
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield ', MaybeConstUserType> {\n  using UserType = typename std::remove_const<MaybeConstUserType>::type;\n  using Traits = EnumTraits<'
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield ', UserType>;\n\n  static void Serialize(UserType input, int32_t* output) {\n    *output = static_cast<int32_t>(Traits::ToMojom(input));\n  }\n\n  static bool Deserialize(int32_t input, UserType* output) {\n    auto known_value = ::mojo::internal::ToKnownEnumValueHelper(\n        static_cast<'
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '>(input));\n    if constexpr (requires {\n                    {\n                      Traits::FromMojom(known_value)\n                    } -> std::same_as<UserType>;\n                  }) {\n      static_assert(std::same_as<'
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield ', UserType> ||\n                        HasInfallibleConversion('
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '()),\n                    "'
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield ' does not have an infallible conversion, "\n                    "use an optional return type.");\n      *output = Traits::FromMojom(known_value);\n      return true;\n    } else {\n      static_assert(\n          requires {\n            {\n              Traits::FromMojom(known_value)\n            } -> std::same_as<std::optional<UserType>>;\n          }, "FromMojom must return by value or optional.");\n      std::optional<UserType> from_mojom = Traits::FromMojom(known_value);\n      if (from_mojom) {\n        *output = *from_mojom;\n      }\n      return from_mojom.has_value();\n    }\n  }\n};\n\n}  // namespace internal'

blocks = {}
debug_info = '1=19&7=23&9=25&17=27&23=29&24=31&25=33'