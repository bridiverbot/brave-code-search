from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface.java.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface_imports = resolve('interface_imports')
    l_0_interface = resolve('interface')
    l_0_interface_def = missing
    pass
    included_template = environment.get_template('interface_definition.tmpl', 'interface.java.tmpl')._get_default_module(context)
    l_0_interface_def = getattr(included_template, 'interface_def', missing)
    if l_0_interface_def is missing:
        l_0_interface_def = undefined(f"the template {included_template.__name__!r} (imported on line 1 in 'interface.java.tmpl') does not export the requested name 'interface_def'", name='interface_def')
    context.vars['interface_def'] = l_0_interface_def
    context.exported_vars.discard('interface_def')
    yield '\n'
    template = environment.get_template('header.java.tmpl', 'interface.java.tmpl')
    for event in template.root_render_func(template.new_context(context.get_all(), True, {'interface_def': l_0_interface_def})):
        yield event
    yield '\n'
    for l_1_import in (undefined(name='interface_imports') if l_0_interface_imports is missing else l_0_interface_imports):
        _loop_vars = {}
        pass
        yield 'import '
        yield str(l_1_import)
        yield ';'
    l_1_import = missing
    yield '\n\n'
    yield str(context.call((undefined(name='interface_def') if l_0_interface_def is missing else l_0_interface_def), (undefined(name='interface') if l_0_interface is missing else l_0_interface)))

blocks = {}
debug_info = '1=14&2=21&3=25&4=29&7=33'